import unittest

import numpy as np

from scripts.graph_predictor import forward, initialize, loss_gradient


class PredictorTests(unittest.TestCase):
    def setUp(self):
        rng = np.random.default_rng(20)
        self.x = rng.normal(size=(4, 3, 7))
        self.graphs = rng.normal(size=(4, 3, 3))
        self.graphs[:, np.arange(3), np.arange(3)] = 0
        self.loc = np.full((4, 3), -0.1)
        self.labels = rng.uniform(-0.8, 0.5, size=(4, 3))
        self.theta = initialize(91, 0.6)

    def test_full_and_a0_all_parameter_gradients(self):
        for model in ["FULL", "A0"]:
            _, analytic = loss_gradient(self.theta, self.x, self.x, self.graphs, self.loc, self.labels, model)
            numerical = np.empty(92)
            for p in range(92):
                left, right = self.theta.copy(), self.theta.copy()
                left[p] -= 1e-5
                right[p] += 1e-5
                left_loss, _ = loss_gradient(left, self.x, self.x, self.graphs, self.loc, self.labels, model)
                right_loss, _ = loss_gradient(right, self.x, self.x, self.graphs, self.loc, self.labels, model)
                numerical[p] = (right_loss - left_loss) / 2e-5
            np.testing.assert_allclose(analytic, numerical, atol=2e-6, rtol=2e-4)

    def test_shared_network_is_equivariant_to_joint_node_relabeling(self):
        order = [2, 0, 1]
        scale, df, _ = forward(self.theta, self.x, self.x, self.graphs, "FULL")
        reordered, reordered_df, _ = forward(
            self.theta, self.x[:, order], self.x[:, order], self.graphs[:, order][:, :, order], "FULL",
        )
        np.testing.assert_allclose(reordered, scale[:, order], atol=1e-14)
        self.assertEqual(df, reordered_df)


if __name__ == "__main__":
    unittest.main()
