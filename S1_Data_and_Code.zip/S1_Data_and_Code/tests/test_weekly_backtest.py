import unittest

import numpy as np
import pandas as pd
from numpy.testing import assert_allclose, assert_array_equal

from scripts.baselines import backtest


class WeeklyBacktestTests(unittest.TestCase):
    def test_midweek_initialization_holding_drift_and_next_week_cost_once(self):
        dates = pd.bdate_range("2020-01-01", periods=8)
        returns = pd.DataFrame({"A": [0, 0, .2, 0, 0, .04, 0, 0],
                                "B": [0, 0, 0, .1, 0, 0, 0, 0]}, index=dates)
        calls = []

        def strategy(day, knownweights):
            calls.append((day, knownweights.copy()))
            return np.array([.25, .75])

        ledger = backtest(returns, "FULL", dates[2], dates[-1], rates=[.01, .01],
                          strategy=strategy, trading_frequency="weekly")
        self.assertEqual([day for day, _ in calls], [3])
        assert_allclose(calls[0][1], [12 / 23, 11 / 23])
        assert_array_equal(ledger.target_date, dates[2:])
        assert_array_equal(ledger.trade_executed, [True, False, False, True, False, False])
        assert_array_equal(ledger.execution_date, dates[[1, 1, 1, 4, 4, 4]])
        # Thursday buys 50/50 from cash. Tuesday sells A and buys B after
        # Friday/Monday drift. Each execution fee appears in just one return.
        costs = np.array([.01 / 1.01, 0, 0, (.01 * 25 / 46) / 1.005, 0, 0])
        gross = np.array([.1, 1 / 22, 0, .01, 0, 0])
        net = (1 - costs) * (1 + gross) - 1
        assert_allclose(ledger.cost, costs, rtol=0, atol=1e-14)
        assert_allclose(ledger.gross_return, gross, rtol=0, atol=1e-14)
        assert_allclose(ledger.net_return, net, rtol=0, atol=1e-14)
        assert_allclose(ledger.wealth, np.cumprod(1 + net), rtol=0, atol=1e-14)
        assert_allclose(ledger.loc[[1, 2], ["target_A", "target_B"]],
                        [[6 / 11, 5 / 11], [12 / 23, 11 / 23]])
        assert_array_equal(ledger.loc[~ledger.trade_executed, ["trade_A", "trade_B"]],
                           np.zeros((4, 2)))

    def test_first_observed_weekday_can_be_tuesday_and_initial_cash_can_remain(self):
        dates = pd.to_datetime(["2020-01-02", "2020-01-03", "2020-01-06", "2020-01-07",
                                "2020-01-08", "2020-01-10", "2020-01-14", "2020-01-15",
                                "2020-01-16"])
        returns = pd.DataFrame(np.zeros((len(dates), 2)), index=dates, columns=["A", "B"])
        calls = []

        def strategy(day, knownweights):
            calls.append(day)
            return np.array([.2, .3])

        ledger = backtest(returns, "FULL", dates[2], dates[-1], rates=[.01, .01],
                          strategy=strategy, trading_frequency="weekly",
                          initial_target=[.2, .3])
        self.assertEqual(calls, [2, 6])
        assert_allclose(ledger.iloc[0][["target_A", "target_B"]].to_numpy(dtype=float), [.2, .3])
        self.assertAlmostEqual(ledger.cost.iloc[0], .005 / 1.005)
        assert_array_equal(ledger.loc[ledger.trade_executed, "signal_date"], dates[[0, 2, 6]])


if __name__ == "__main__":
    unittest.main()
