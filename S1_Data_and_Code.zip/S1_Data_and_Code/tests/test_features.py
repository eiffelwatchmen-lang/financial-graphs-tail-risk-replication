import unittest

import numpy as np
import pandas as pd

from scripts.prepare_features import price_features


class FeatureTests(unittest.TestCase):
    def test_future_prices_do_not_change_past_features(self):
        dates = pd.bdate_range("2020-01-01", periods=85)
        values = 100 * np.cumprod(1 + 0.01 * np.sin(np.arange(85)))
        prices = pd.DataFrame({"A": values}, index=dates)
        changed = prices.copy()
        changed.iloc[71:] *= 2
        pd.testing.assert_frame_equal(
            price_features(prices).loc[:dates[70]],
            price_features(changed).loc[:dates[70]],
        )
        self.assertEqual(price_features(prices).index[0], dates[60])


if __name__ == "__main__":
    unittest.main()
