import unittest

import numpy as np
from scipy.integrate import quad

from scripts.tail_distribution import cdf, logpdf, lower_tail_es, nll_grad, ppf


class TruncatedStudentTests(unittest.TestCase):
    # Includes substantial truncation: boundary at the location and above it.
    PARAMETERS = [(0.002, 0.03, 7.0), (-0.8, 0.7, 3.2), (-1.5, 0.2, 12.0)]

    def test_density_integrates_to_one(self):
        for loc, scale, df in self.PARAMETERS:
            with self.subTest(loc=loc, scale=scale, df=df):
                mass, _ = quad(lambda x: np.exp(logpdf(x, loc, scale, df)), -1, np.inf)
                self.assertAlmostEqual(mass, 1.0, places=9)
        self.assertEqual(logpdf(-1.01, 0.0, 1.0, 5.0), -np.inf)
        self.assertEqual(cdf(-1.01, 0.0, 1.0, 5.0), 0.0)

    def test_cdf_inverse_with_scenario_asset_broadcasting(self):
        loc, scale, df = np.array(self.PARAMETERS).T
        probabilities = np.array([1e-5, 0.001, 0.05, 0.5, 0.95, 1 - 1e-5])[:, None]
        quantiles = ppf(probabilities, loc, scale, df)
        self.assertEqual(quantiles.shape, (6, 3))
        self.assertTrue(np.all(quantiles > -1))
        np.testing.assert_allclose(cdf(quantiles, loc, scale, df),
                                   np.broadcast_to(probabilities, (6, 3)), atol=2e-11)
        np.testing.assert_allclose(ppf(0.0, loc, scale, df), -1.0, atol=2e-11)

    def test_lower_tail_es_matches_density_integral(self):
        for loc, scale, df in self.PARAMETERS:
            for alpha in (0.01, 0.05, 0.4):
                with self.subTest(loc=loc, alpha=alpha):
                    quantile = ppf(alpha, loc, scale, df)
                    moment, _ = quad(
                        lambda x: x * np.exp(logpdf(x, loc, scale, df)), -1, quantile,
                        epsabs=1e-12,
                    )
                    actual = lower_tail_es(alpha, loc, scale, df)
                    self.assertAlmostEqual(actual, moment / alpha, places=9)
                    self.assertGreater(actual, -1.0)
                    self.assertLess(actual, quantile)

    def test_scale_and_df_gradients_against_centered_differences(self):
        for loc, scale, df in self.PARAMETERS:
            y = ppf(np.array([0.001, 0.05, 0.5, 0.99]), loc, scale, df)
            nll, dscale, ddf = nll_grad(y, loc, scale, df)
            np.testing.assert_allclose(nll, -logpdf(y, loc, scale, df), atol=1e-13)
            hs = scale * 1e-5
            finite_scale = (-logpdf(y, loc, scale + hs, df)
                            + logpdf(y, loc, scale - hs, df)) / (2 * hs)
            hd = 2e-5
            finite_df = (-logpdf(y, loc, scale, df + hd)
                         + logpdf(y, loc, scale, df - hd)) / (2 * hd)
            with self.subTest(loc=loc, scale=scale, df=df):
                np.testing.assert_allclose(dscale, finite_scale, rtol=2e-7, atol=2e-8)
                np.testing.assert_allclose(ddf, finite_df, rtol=2e-6, atol=2e-9)


if __name__ == "__main__":
    unittest.main()
