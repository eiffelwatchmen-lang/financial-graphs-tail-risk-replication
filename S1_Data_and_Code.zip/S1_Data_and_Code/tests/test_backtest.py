import unittest

import numpy as np
import pandas as pd

from scripts.baselines import backtest, self_financing_cost, tail_es


class BacktestTests(unittest.TestCase):
    def test_fractional_tail_mass(self):
        # Four equally likely losses, with exactly the worst 1.5 observations.
        self.assertAlmostEqual(tail_es([-2, 1, 2, 3], alpha=0.375), 8 / 3)
        self.assertAlmostEqual(tail_es([-2, 1, 2, 3], alpha=0.05), 3)

    def test_cash_purchase_has_analytic_self_financing_cost(self):
        weighted_rate = 0.4 * 0.001 + 0.6 * 0.002
        cost = self_financing_cost([0, 0], [0.4, 0.6], [0.001, 0.002])
        self.assertAlmostEqual(cost, weighted_rate / (1 + weighted_rate), places=13)

    def test_drifted_rebalance_has_analytic_self_financing_cost(self):
        # Equal holdings after +10% / -10% returns become 55% / 45%.
        # Rebalancing to 40% / 60% gives z = .0045 - .008 z.
        cost = self_financing_cost([0.55, 0.45], [0.4, 0.6], [0.01, 0.02])
        self.assertAlmostEqual(cost, 0.0045 / 1.008, places=13)

    def test_two_period_lag_uses_signal_information_and_execution_drift(self):
        dates = pd.bdate_range("2020-01-01", periods=28)
        day = np.arange(len(dates))
        returns = pd.DataFrame({
            "A": 0.005 * np.sin(day + 0.2),
            "B": 0.015 * np.cos(day + 0.4),
            "C": 0.025 * np.sin(day * 0.7 + 0.6),
        }, index=dates)
        options = dict(model="M1", start=dates[22], end=dates[25], rates=[0, 0, 0])
        original = backtest(returns, **options)
        changed = returns.copy()
        changed.loc[dates[22]] = [0.4, -0.25, 0.15]
        later_price_change = backtest(changed, **options)

        first, second = original.iloc[0], original.iloc[1]
        self.assertEqual(first.signal_date, dates[20])
        self.assertEqual(first.execution_date, dates[21])
        self.assertEqual(first.target_date, dates[22])
        targets = [f"target_{asset}" for asset in returns.columns]
        pretrade = [f"pretrade_{asset}" for asset in returns.columns]
        np.testing.assert_allclose(first[targets].to_numpy(dtype=float), np.full(3, 1 / 3))
        # A price revealed at execution changes realized drift but not the signal.
        np.testing.assert_allclose(second[targets].to_numpy(dtype=float),
                                   later_price_change.iloc[1][targets].to_numpy(dtype=float))
        self.assertFalse(np.allclose(second[pretrade].to_numpy(dtype=float),
                                     later_price_change.iloc[1][pretrade].to_numpy(dtype=float)))
        np.testing.assert_allclose(second[pretrade].to_numpy(dtype=float),
                                   (1 + returns.iloc[22].to_numpy())
                                   / (3 + returns.iloc[22].sum()))
        self.assertAlmostEqual(first.gross_return, returns.iloc[22].mean())

        known_change = returns.copy()
        known_change.loc[dates[21], "A"] = 0.3
        known_signal_change = backtest(known_change, **options)
        self.assertFalse(np.allclose(second[targets].to_numpy(dtype=float),
                                     known_signal_change.iloc[1][targets].to_numpy(dtype=float)))

    def test_callback_receives_signal_day_post_execution_holdings(self):
        dates = pd.bdate_range("2020-01-01", periods=6)
        returns = pd.DataFrame({"A": [0.1] * 6, "B": [-0.1] * 6}, index=dates)
        calls = []

        def strategy(day, knownweights):
            calls.append((day, knownweights.copy()))
            return np.array([0.6, 0.4]) if day % 2 else np.array([0.4, 0.6])

        records = backtest(returns, "FULL", dates[2], dates[5],
                           rates=[0.01, 0.02], strategy=strategy)
        self.assertEqual([day for day, _ in calls], [1, 2, 3])
        np.testing.assert_allclose([weights for _, weights in calls],
                                   [[0.5, 0.5], [0.6, 0.4], [0.4, 0.6]])
        np.testing.assert_allclose(records.loc[1, ["pretrade_A", "pretrade_B"]]
                                   .to_numpy(dtype=float), [0.55, 0.45])
        # At date 2 the callback sees the just-executed target, after this drift.
        np.testing.assert_allclose(records.loc[2, ["signal_A", "signal_B"]]
                                   .to_numpy(dtype=float), calls[1][1])
        np.testing.assert_allclose(records[["target_A", "target_B"]],
                                   [[0.5, 0.5], [0.6, 0.4], [0.4, 0.6], [0.6, 0.4]])


if __name__ == "__main__":
    unittest.main()
