import unittest

import numpy as np
import pandas as pd

from scripts.run_graph_development import scenarios_at


class ReplayTimingTests(unittest.TestCase):
    def test_copula_cannot_use_unmatured_forecast_errors(self):
        rng = np.random.default_rng(300)
        dates = pd.bdate_range("2018-01-01", periods=310)
        forecast = {"signal_indices": np.arange(310), "pit": rng.uniform(0.02, 0.98, (310, 3)),
                    "location": np.zeros((310, 3)), "scales": np.full((310, 3), 0.02),
                    "df": np.full(310, 8.0)}
        config = {"seed": 20261012, "timing": {"target_lag": 2},
                  "copula": {"pit_samples": 252, "scenarios": 128}}
        original = scenarios_at(300, dates, forecast, config)
        forecast["pit"][299:] = rng.uniform(0.001, 0.999, (11, 3))
        np.testing.assert_array_equal(original, scenarios_at(300, dates, forecast, config))
        forecast["pit"][298] = [0.001, 0.999, 0.001]
        self.assertFalse(np.allclose(original, scenarios_at(300, dates, forecast, config)))


if __name__ == "__main__":
    unittest.main()
