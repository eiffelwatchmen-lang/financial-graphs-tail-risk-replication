import unittest

import numpy as np
import pandas as pd

from scripts.run_risk_matching import ewma_covariances


class RiskMatchingTests(unittest.TestCase):
    def test_signal_covariance_uses_only_realized_returns(self):
        values = np.tile([0.01, 0.02], (65, 1))
        values[0] = np.nan
        values[61] = [-0.02, 0.01]
        original = ewma_covariances(pd.DataFrame(values))
        expected = 0.94 * np.array([[0.0001, 0.0002], [0.0002, 0.0004]])
        expected += 0.06 * np.array([[0.0004, -0.0002], [-0.0002, 0.0001]])
        np.testing.assert_allclose(original[61], expected, atol=1e-18)
        values[62:] = [0.5, -0.4]
        changed = ewma_covariances(pd.DataFrame(values))
        np.testing.assert_array_equal(original[:62], changed[:62])


if __name__ == "__main__":
    unittest.main()
