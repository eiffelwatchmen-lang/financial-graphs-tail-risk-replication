import unittest

import numpy as np
import pandas as pd
from numpy.testing import assert_allclose, assert_array_equal

from scripts.baselines import backtest


class DelayedBacktestTests(unittest.TestCase):
    def test_two_day_execution_queue_cash_holdings_and_hand_calculated_costs(self):
        dates = pd.bdate_range("2020-01-01", periods=6)
        returns = pd.DataFrame({"A": [0, 0.2, 0.4, 0.1, 0.05, -0.03],
                                "B": [0, -0.1, -0.2, -0.1, -0.02, 0.04]}, index=dates)
        calls = []

        def strategy(day, knownweights):
            calls.append((day, knownweights.copy()))
            return np.array([0.4, 0.6]) if day == 1 else np.array([0.6, 0.4])

        ledger = backtest(returns, "FULL", dates[3], dates[5], rates=[0.01, 0.02],
                          strategy=strategy, execution_lag=2)
        assert_array_equal(ledger.signal_date, dates[:3])
        assert_array_equal(ledger.execution_date, dates[2:5])
        assert_array_equal(ledger.target_date, dates[3:6])
        self.assertEqual([day for day, _ in calls], [1, 2])
        # Day 1 still holds cash while the first order waits; its new signal
        # adds a second queued order. Day 2 executes only the initial 50/50.
        assert_allclose([weights for _, weights in calls], [[0, 0], [0.5, 0.5]])
        assert_allclose(ledger[["signal_A", "signal_B"]], [[0, 0], [0, 0], [0.5, 0.5]])
        assert_allclose(ledger[["target_A", "target_B"]], [[0.5, 0.5], [0.4, 0.6], [0.6, 0.4]])
        assert_allclose(ledger[["pretrade_A", "pretrade_B"]],
                        [[0, 0], [0.55, 0.45], [5 / 12, 7 / 12]])
        # Initial purchase: c=.015(1-c). Then sell A/buy B gives
        # c=.0045-.008c; the final buy A/sell B gives c=.0055+.002c.
        expected_costs = np.array([0.015 / 1.015, 0.0045 / 1.008, 0.0055 / 0.998])
        expected_gross = np.array([0, 0.008, -0.002])
        expected_net = (1 - expected_costs) * (1 + expected_gross) - 1
        assert_allclose(ledger.cost, expected_costs, rtol=0, atol=1e-13)
        assert_allclose(ledger.gross_return, expected_gross, rtol=0, atol=1e-15)
        assert_allclose(ledger.net_return, expected_net, rtol=0, atol=1e-13)
        assert_allclose(ledger.wealth, np.cumprod(1 + expected_net), rtol=0, atol=1e-13)

    def test_unknown_execution_day_return_changes_drift_not_queued_targets(self):
        dates = pd.bdate_range("2020-01-01", periods=7)
        returns = pd.DataFrame({"A": [0.01, -0.02, 0.03, 0.04, -0.01, 0.02, 0.01],
                                "B": [-0.01, 0.01, -0.02, 0.01, 0.02, -0.01, 0]}, index=dates)

        def replay(observed):
            def strategy(day, knownweights):
                weight_a = 0.5 + 0.1 * np.tanh(observed.iloc[day, 0])
                return np.array([weight_a, 1 - weight_a])

            return backtest(observed, "FULL", dates[3], dates[6], rates=[0.01, 0.02],
                            strategy=strategy, execution_lag=2)

        original = replay(returns)
        changed = returns.copy()
        changed.loc[dates[3]] = [0.4, -0.25]
        modified = replay(changed)
        target_columns = ["target_A", "target_B"]
        assert_allclose(original.loc[:2, target_columns], modified.loc[:2, target_columns])
        self.assertFalse(np.allclose(original.loc[3, target_columns].to_numpy(dtype=float),
                                     modified.loc[3, target_columns].to_numpy(dtype=float)))
        self.assertFalse(np.allclose(original.loc[1, ["pretrade_A", "pretrade_B"]].to_numpy(dtype=float),
                                     modified.loc[1, ["pretrade_A", "pretrade_B"]].to_numpy(dtype=float)))
        self.assertNotAlmostEqual(original.loc[1, "cost"], modified.loc[1, "cost"], places=10)


if __name__ == "__main__":
    unittest.main()
