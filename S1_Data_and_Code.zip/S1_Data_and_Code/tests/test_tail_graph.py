import copy
import json
import unittest
from pathlib import Path

import numpy as np

from scripts.tail_graph import (
    fit_month, quantile_regression, raw_to_standardized,
    standardized_to_raw, stationary_bootstrap_indices,
)


ROOT = Path(__file__).resolve().parents[1]


class TailGraphTests(unittest.TestCase):
    def test_direction_and_sign_recovered_without_future_targets(self):
        config = json.loads((ROOT / "configs/protocol.json").read_text(encoding="utf-8"))
        config = copy.deepcopy(config)
        config["graph"]["bootstrap_repetitions"] = 8
        rng = np.random.default_rng(52)
        n = 330
        features = rng.normal(size=(n, 3, 7))
        features[:, :, 3] = rng.uniform(0.8, 1.2, (n, 3))
        features[:, :, 6] = rng.exponential(size=(n, 3))
        targets = rng.normal(scale=0.04, size=(n - 2, 3))
        targets[:, 0] += (
            1.4 * features[:-2, 1, 6] - 0.9 * features[:-2, 2, 6]
        )
        returns = np.zeros((n, 3))
        returns[2:] = -targets * features[:-2, :, 3]
        fitted = fit_month(features, returns, 319, None, 0.02, 0.005, config, 19)
        self.assertGreater(fitted["adjacency"][0, 1], 0.9)
        self.assertLess(fitted["adjacency"][0, 2], -0.5)
        self.assertLess(abs(fitted["adjacency"][1, 0]), 0.05)
        np.testing.assert_array_equal(np.diag(fitted["adjacency"]), 0)
        self.assertEqual(fitted["target_indices"][-1], 319)
        changed_features, changed_returns = features.copy(), returns.copy()
        changed_features[320:] *= 100
        changed_returns[320:] -= 100
        unchanged = fit_month(
            changed_features, changed_returns, 319, None, 0.02, 0.005, config, 19,
        )
        np.testing.assert_array_equal(fitted["adjacency"], unchanged["adjacency"])

    def test_scaler_change_preserves_previous_predictions(self):
        coefficients = np.array([0.7, 2.0, -0.3])
        old_mean, old_scale = np.array([3.0, 8.0]), np.array([0.5, 4.0])
        new_mean, new_scale = np.array([-1.0, 4.0]), np.array([3.0, 0.25])
        raw = standardized_to_raw(coefficients, old_mean, old_scale)
        converted = raw_to_standardized(raw, new_mean, new_scale)
        observations = np.array([[1.0, 9.0], [-2.0, 5.0], [6.0, -1.0]])
        old_prediction = coefficients[0] + (observations - old_mean) / old_scale @ coefficients[1:]
        new_prediction = converted[0] + (observations - new_mean) / new_scale @ converted[1:]
        np.testing.assert_allclose(new_prediction, old_prediction, atol=1e-12)

    def test_stationary_bootstrap_keeps_joint_rows_and_block_length(self):
        n = 200
        rows = stationary_bootstrap_indices(n, 100, 20, np.random.default_rng(7))
        joint = np.column_stack((np.arange(n), 2 * np.arange(n) + 3))
        sampled = joint[rows]
        np.testing.assert_array_equal(sampled[:, :, 1], 2 * sampled[:, :, 0] + 3)
        restart_rate = np.mean(rows[:, 1:] != (rows[:, :-1] + 1) % n)
        self.assertGreater(restart_rate, 0.04)
        self.assertLess(restart_rate, 0.06)
        self.assertLess(abs(rows.mean() - (n - 1) / 2), 4)

    def test_temporal_penalty_shrinks_slopes_but_leaves_intercept_free(self):
        x = np.linspace(-1, 1, 301)
        design = np.column_stack((np.ones(len(x)), x))
        target = 4 + 2 * x
        fitted = quantile_regression(design, target, 0.5, 0, 1, np.zeros(2))
        self.assertAlmostEqual(fitted[0], 4, places=8)
        self.assertAlmostEqual(fitted[1], 0, places=8)


if __name__ == "__main__":
    unittest.main()
