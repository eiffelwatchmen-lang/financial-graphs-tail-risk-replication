import unittest
from unittest.mock import patch

import numpy as np

from scripts.statistical_inference import (
    holm_adjust, paired_j_bootstrap, paired_mean_bootstrap,
)


class StatisticalInferenceTests(unittest.TestCase):
    def test_constant_paired_gain_and_identical_strategy(self):
        base = 0.01 * np.sin(np.arange(121))
        returns = np.column_stack((base + 0.002, base, base))
        result = paired_j_bootstrap(returns, [(0, 1), (1, 2)], repetitions=300, seed=17)
        np.testing.assert_allclose(result["point_difference"], [0.0021, 0], atol=1e-15)
        np.testing.assert_allclose(result["ci_lower"], [0.0021, 0], atol=1e-15)
        np.testing.assert_allclose(result["ci_upper"], [0.0021, 0], atol=1e-15)
        np.testing.assert_allclose(result["p_value"], [1 / 301, 1])
        np.testing.assert_allclose(result["mean_difference"], [0.002, 0], atol=1e-15)
        np.testing.assert_allclose(result["loss_es_difference"], [-0.002, 0], atol=1e-15)
        mean_result = paired_mean_bootstrap(returns, [(0, 1), (1, 2)], repetitions=300, seed=17)
        np.testing.assert_allclose(mean_result["point_difference"], [0.002, 0], atol=1e-15)
        np.testing.assert_allclose(mean_result["ci_lower"], [0.002, 0], atol=1e-15)
        np.testing.assert_allclose(mean_result["p_value"], [1 / 301, 1])

    def test_each_resample_recalculates_fractional_tail_and_centered_p(self):
        returns = np.column_stack(([-0.125, -0.0625, 0, 0.03125, 0.0625], np.zeros(5)))
        rows = np.array([[1, 1, 2, 3, 4], [2, 2, 2, 2, 2], [0, 0, 4, 4, 4]])
        with patch("scripts.statistical_inference.stationary_bootstrap_indices", return_value=rows):
            result = paired_j_bootstrap(returns, [(0, 1)], alpha=0.3, repetitions=3)
        # Original ES integrates one worst loss plus half the next loss.
        np.testing.assert_allclose(result["loss_es"], [5 / 48, 0], atol=1e-15)
        # The middle draw contains no loss. Tail membership changes in each draw.
        np.testing.assert_allclose(
            result["bootstrap_differences"][:, 0], [-0.009375, 0, -0.01875], atol=1e-15,
        )
        self.assertAlmostEqual(result["point_difference"][0], -0.01875 - 0.05 * 5 / 48)
        self.assertEqual(result["p_value"][0], 0.5)
        self.assertAlmostEqual(result["ci_lower"][0], -0.01828125)
        self.assertAlmostEqual(result["ci_upper"][0], -0.00046875)

    def test_holm_known_adjustments_keep_original_order(self):
        np.testing.assert_allclose(holm_adjust([0.04, 0.01]), [0.04, 0.02])
        np.testing.assert_allclose(holm_adjust([0.04, 0.01, 0.03]), [0.06, 0.03, 0.06])
        np.testing.assert_allclose(holm_adjust([0.9, 0.7, 0.8]), [1, 1, 1])


if __name__ == "__main__":
    unittest.main()
