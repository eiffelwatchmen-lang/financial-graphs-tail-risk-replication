import unittest

import numpy as np
from numpy.testing import assert_allclose, assert_array_equal
from scipy.stats import t

from scripts.baselines import historical_cvar
from scripts.joint_risk import (
    copula_base_random,
    equal_weight_var_es,
    fz_score,
    joint_scenarios,
    pit_correlation,
    solve_mean_cvar,
)


class JointRiskTests(unittest.TestCase):
    def test_correlation_uses_latest_252_and_shrinkage(self):
        rng = np.random.default_rng(4)
        scores = rng.standard_t(5, size=(252, 3))
        scores[:, 1] = 0.6 * scores[:, 0] + 0.4 * scores[:, 1]
        pits = t.cdf(scores, df=5)
        expected = 0.8 * np.corrcoef(t.ppf(np.clip(pits, 1e-4, 0.9999), 5),
                                    rowvar=False) + 0.2 * np.eye(3)
        history = np.vstack((np.full((30, 3), 0.5), pits))
        result = pit_correlation(history)
        assert_allclose(result, expected, atol=1e-14)
        self.assertGreaterEqual(np.linalg.eigvalsh(result).min(), 0.2 - 1e-14)

    def test_shared_random_draws_and_joint_margins(self):
        first = copula_base_random(20261012, scenario_count=2000)
        second = copula_base_random(20261012, scenario_count=2000)
        for left, right in zip(first, second):
            assert_array_equal(left, right)
        pits = np.random.default_rng(8).uniform(0.01, 0.99, size=(252, 3))
        loc = np.array([0.001, 0.002, 0.003])
        scale = np.array([0.01, 0.02, 0.03])
        scenarios = joint_scenarios(pits, loc, scale, 8, first)
        assert_array_equal(scenarios, joint_scenarios(pits, loc, scale, 8, second))
        self.assertEqual(scenarios.shape, (2000, 3))
        self.assertGreater(scenarios.min(), -1)
        for before, after in zip(first, second):
            assert_array_equal(before, after)

    def test_equal_weight_tail_fraction(self):
        values = np.arange(-5, 5, dtype=float) / 100
        scenarios = np.column_stack((values - 0.01, values + 0.01))
        q, es = equal_weight_var_es(scenarios, alpha=0.25)
        self.assertAlmostEqual(q, -0.03)
        self.assertAlmostEqual(es, (-0.05 - 0.04 - 0.03 * 0.5) / 2.5)

    def test_fz_percentage_units_and_positive_es(self):
        y, q, e = np.array([-0.04, 0.04]), np.array([-0.02, 0.03]), np.array([-0.03, 0.02])
        # Percentage-point inputs are (-4,-2,-3) and (4,3,2).
        expected = np.array([
            (-3 + 2 + (-2 + 4) / 0.05) / (1 + np.exp(3)) - np.log1p(np.exp(-3)),
            (2 - 3) / (1 + np.exp(-2)) - np.log1p(np.exp(2)),
        ])
        assert_allclose(fz_score(y, q, e), expected, atol=1e-14)

    def test_ten_thousand_constant_scenarios_known_solution(self):
        means = np.array([0.03, 0.02, 0.01])
        scenarios = np.tile(means, (10000, 1))
        weights = solve_mean_cvar(scenarios, means, np.full(3, 1 / 3), np.zeros(3))
        assert_allclose(weights, [0.6, 0.4, 0], atol=1e-9)

    def test_sparse_lp_matches_existing_small_problem_with_costs(self):
        rng = np.random.default_rng(10)
        scenarios = rng.normal(size=(60, 3)) * [0.01, 0.02, 0.05]
        means = np.array([0.002, 0.001, 0.004])
        previous = np.array([0.2, 0.3, 0.5])
        rates = np.array([0.0005, 0.0005, 0.002])
        expected = historical_cvar(scenarios, means, previous, rates)
        assert_allclose(solve_mean_cvar(scenarios, means, previous, rates),
                        expected, atol=1e-9)


if __name__ == "__main__":
    unittest.main()
