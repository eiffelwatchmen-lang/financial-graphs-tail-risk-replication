import unittest

import numpy as np
from numpy.testing import assert_allclose

from scripts.dcc import dcc_nll_gradient, fit_dcc, forecast_correlation, normalize


class DCCTests(unittest.TestCase):
    def test_analytic_gradient_matches_finite_difference(self):
        rng = np.random.default_rng(120)
        correlation = np.array([[1, 0.5, -0.2], [0.5, 1, 0.1], [-0.2, 0.1, 1]])
        z = rng.multivariate_normal(np.zeros(3), correlation, size=90)
        qbar = z.T @ z / len(z)
        params = np.array([0.08, 0.86])
        _, analytical = dcc_nll_gradient(params, z, qbar)
        step = 1e-6
        numerical = np.empty(2)
        for parameter in range(2):
            offset = np.zeros(2)
            offset[parameter] = step
            upper, _ = dcc_nll_gradient(params + offset, z, qbar)
            lower, _ = dcc_nll_gradient(params - offset, z, qbar)
            numerical[parameter] = (upper - lower) / (2 * step)
        assert_allclose(analytical, numerical, rtol=1e-6, atol=1e-8)

    def test_two_step_formula_unit_diagonal_and_positive_definiteness(self):
        params = np.array([0.1, 0.8])
        qbar = np.array([[4.0, 0.8], [0.8, 1.0]])
        q_last = np.array([[2.0, -0.3], [-0.3, 1.5]])
        z_last = np.array([1.5, -0.4])
        q1, r2 = forecast_correlation(params, qbar, q_last, z_last)
        expected_q1 = 0.1 * qbar + 0.1 * np.outer(z_last, z_last) + 0.8 * q_last
        expected_r2 = 0.1 * normalize(qbar) + 0.9 * normalize(expected_q1)
        assert_allclose(q1, expected_q1, atol=1e-15)
        assert_allclose(r2, expected_r2, atol=1e-15)
        assert_allclose(np.diag(r2), np.ones(2), atol=1e-15)
        self.assertGreater(np.linalg.eigvalsh(r2).min(), 0)
        assert_allclose(normalize(np.stack([qbar, q_last])),
                        np.stack([normalize(qbar), normalize(q_last)]))

    def test_fit_and_last_state_match_explicit_recursion(self):
        rng = np.random.default_rng(403)
        long_run = np.array([[1, 0.35], [0.35, 1]])
        q = long_run.copy()
        z = np.empty((400, 2))
        for day in range(len(z)):
            z[day] = rng.multivariate_normal(np.zeros(2), normalize(q))
            q = 0.05 * long_run + 0.1 * np.outer(z[day], z[day]) + 0.85 * q
        fitted = fit_dcc(z)
        a, b = fitted["params"]
        self.assertGreaterEqual(a, 0)
        self.assertGreaterEqual(b, 0)
        self.assertLessEqual(a + b, 0.999 + 1e-12)
        assert_allclose(fitted["qbar"], z.T @ z / len(z), atol=1e-15)
        initial_nll, _ = dcc_nll_gradient([0.03, 0.95], z, fitted["qbar"])
        self.assertLessEqual(fitted["nll"], initial_nll + 1e-9)
        q = fitted["qbar"].copy()
        for innovation in z[:-1]:
            q = ((1 - a - b) * fitted["qbar"] + a * np.outer(innovation, innovation)
                 + b * q)
        assert_allclose(fitted["q_last"], q, rtol=1e-13, atol=1e-13)


if __name__ == "__main__":
    unittest.main()
