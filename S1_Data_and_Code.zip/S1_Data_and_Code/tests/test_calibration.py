import unittest
from unittest.mock import patch

import numpy as np
from scipy.stats import chi2

from scripts.calibration import joint_unconditional_calibration, var_coverage_independence


class CalibrationTests(unittest.TestCase):
    def test_likelihood_ratio_formulas_and_inclusive_hits(self):
        hits = np.array([0, 0, 1, 1, 0, 1, 0, 0, 0, 1])
        y = np.where(hits, -0.01, 0.01)
        y[2] = 0
        result = var_coverage_independence(y, np.zeros(10), alpha=0.25)
        expected_uc = 2 * (6 * np.log(0.6) + 4 * np.log(0.4)
                           - 6 * np.log(0.75) - 4 * np.log(0.25))
        expected_ind = 2 * (6 * np.log(0.5) + 2 * np.log(2 / 3) + np.log(1 / 3)
                            - 5 * np.log(5 / 9) - 4 * np.log(4 / 9))
        np.testing.assert_array_equal(result["transitions"], [[3, 3], [2, 1]])
        self.assertEqual(result["hit_count"], 4)
        self.assertAlmostEqual(result["lr_uc"], expected_uc, places=12)
        self.assertAlmostEqual(result["lr_ind"], expected_ind, places=12)
        self.assertAlmostEqual(result["p_uc"], chi2.sf(expected_uc, 1), places=12)
        self.assertAlmostEqual(result["p_ind"], chi2.sf(expected_ind, 1), places=12)

    def test_known_exact_zero_joint_moments(self):
        y = np.array([-0.02, 0.01, 0.02, -0.01, 0.01, 0.03, 0.02, 0.04])
        result = joint_unconditional_calibration(
            y, np.zeros(8), np.full(8, -0.015), alpha=0.25, repetitions=300, seed=7,
        )
        np.testing.assert_array_equal(result["mean_moments"], [0, 0])
        self.assertEqual(result["statistic"], 0)
        self.assertEqual(result["p_value"], 1)

    def test_joint_wald_uses_bootstrap_mean_covariance_and_observed_center(self):
        y = np.array([-0.02, -0.01, 0.01, 0.02])
        rows = np.array([[0, 0, 0, 0], [1, 1, 1, 1], [2, 2, 2, 2], [0, 1, 2, 3]])
        with patch("scripts.calibration.stationary_bootstrap_indices", return_value=rows):
            result = joint_unconditional_calibration(
                y, np.zeros(4), np.full(4, -0.005), alpha=0.5, repetitions=4,
            )
        np.testing.assert_allclose(result["mean_moments"], [0, 1])
        np.testing.assert_allclose(result["bootstrap_mean_covariance"], np.array([[11, 33], [33, 131]]) / 48)
        self.assertAlmostEqual(result["statistic"], 1.5)
        np.testing.assert_allclose(result["bootstrap_statistics"], [57 / 22, 57 / 22, 12 / 11, 0])
        self.assertEqual(result["p_value"], 0.6)


if __name__ == "__main__":
    unittest.main()
