import unittest

import numpy as np
import pandas as pd
from numpy.testing import assert_array_equal

from scripts.graph_ablations import nonidentity_permutations, transform_graphs


class GraphAblationTests(unittest.TestCase):
    def test_static_freezes_forward_only_and_records_actual_estimation_date(self):
        dates = pd.to_datetime(["2018-12-28", "2018-12-31", "2019-01-02",
                                "2020-12-30", "2020-12-31", "2021-01-04"])
        graph = np.array([[0.0, 1.0], [-2.0, 0.0]])
        original = np.array([1, 1, 2, 3, 3, 4])[:, None, None] * graph
        archive = {"adjacency": original.copy(), "graph_cutoff": np.array([0, 0, 2, 3, 3, 5])}
        transformed, cutoffs = transform_graphs(
            archive, dates, "A1", ["2018-12-31", "2020-12-31", "2022-12-31"],
        )
        assert_array_equal(transformed, np.array([1, 1, 1, 1, 3, 3])[:, None, None] * graph)
        assert_array_equal(cutoffs, [0, 0, 0, 0, 3, 3])
        assert_array_equal(archive["adjacency"], original)
        development_only, _ = transform_graphs(archive, dates, "A1", ["2018-12-31"])
        assert_array_equal(transformed[:4], development_only[:4])

    def test_symmetrization_preserves_signed_average(self):
        graph = np.array([[0.0, 2.0, -3.0], [-4.0, 0.0, 6.0], [1.0, 2.0, 0.0]])
        archive = {"adjacency": graph[None], "graph_cutoff": np.array([0])}
        transformed, cutoffs = transform_graphs(archive, ["2020-01-31"], "A2", [])
        expected = np.array([[0.0, -1.0, -1.0], [-1.0, 0.0, 4.0], [-1.0, 4.0, 0.0]])
        assert_array_equal(transformed[0], expected)
        assert_array_equal(cutoffs, archive["graph_cutoff"])

    def test_unshrunk_point_edges_use_cross_coefficients_and_original_update_dates(self):
        coefficients = np.full((2, 3, 6), 999.0)
        coefficients[0, :, 4:] = [[2.0, -0.5], [5e-7, -3.0], [4.0, 1e-6]]
        coefficients[1, :, 4:] = [[-1.0, 0.0], [2.0, 3.0], [-4.0, 5.0]]
        archive = {
            "adjacency": np.zeros((5, 3, 3)),
            "graph_cutoff": np.array([-1, 1, 1, 3, 3]),
            "update_indices": np.array([1, 3]),
            "coefficients_standardized": coefficients,
        }
        # The stabilized archive is zero; A3 must recover the saved point edges.
        transformed, cutoffs = transform_graphs(archive, pd.bdate_range("2020-01-01", periods=5), "A3", [])
        first = np.array([[0.0, 2.0, -0.5], [0.0, 0.0, -3.0], [4.0, 0.0, 0.0]])
        second = np.array([[0.0, -1.0, 0.0], [2.0, 0.0, 3.0], [-4.0, 5.0, 0.0]])
        assert_array_equal(transformed, np.stack([np.zeros((3, 3)), first, first, second, second]))
        assert_array_equal(cutoffs, archive["graph_cutoff"])

    def test_node_permutation_moves_both_axes_and_is_enumerated_once(self):
        graph = np.array([[0.0, 1.0, 2.0], [3.0, 0.0, 4.0], [5.0, 6.0, 0.0]])
        archive = {"adjacency": graph[None], "graph_cutoff": np.array([0])}
        transformed, cutoffs = transform_graphs(archive, ["2020-01-31"], "A4", [], permutation=(2, 0, 1))
        assert_array_equal(transformed[0], [[0, 5, 6], [2, 0, 1], [4, 3, 0]])
        assert_array_equal(np.sort(transformed.ravel()), np.sort(graph.ravel()))
        assert_array_equal(cutoffs, archive["graph_cutoff"])
        for assets, expected_count in [(3, 5), (4, 23)]:
            orders = nonidentity_permutations(assets)
            self.assertEqual(len(orders), expected_count)
            self.assertEqual(len(set(orders)), expected_count)
            self.assertNotIn(tuple(range(assets)), orders)


if __name__ == "__main__":
    unittest.main()
