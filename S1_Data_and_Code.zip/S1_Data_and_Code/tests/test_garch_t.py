import unittest

import numpy as np
from scipy.stats import t

from scripts.garch_t import (
    filter_variance, fit_garch, forecast_variance, mean_nll_gradient,
)


class GarchTTests(unittest.TestCase):
    def test_likelihood_and_analytic_score(self):
        residuals = np.random.default_rng(16).standard_t(7, 180) * np.sqrt(5 / 7)
        params = np.array([0.04, 0.12, 0.82, 7.0])
        initial_variance = np.mean(residuals ** 2)
        nll, gradient = mean_nll_gradient(params, residuals, initial_variance)
        variance = filter_variance(residuals, params, initial_variance)
        reference = -t.logpdf(residuals, df=7, scale=np.sqrt(variance * 5 / 7)).mean()
        self.assertAlmostEqual(nll, reference, places=12)
        numerical = np.zeros(4)
        for index in range(4):
            step = np.zeros(4)
            step[index] = 1e-6
            numerical[index] = (
                mean_nll_gradient(params + step, residuals, initial_variance)[0]
                - mean_nll_gradient(params - step, residuals, initial_variance)[0]
            ) / (2e-6)
        np.testing.assert_allclose(gradient, numerical, rtol=2e-6, atol=1e-8)

    def test_two_step_forecast_is_one_period_variance(self):
        params = np.array([0.00002, 0.10, 0.85, 8.0])
        h1, h2 = forecast_variance(params, 0.0004, -0.03)
        self.assertAlmostEqual(h1, 0.00045, places=12)
        self.assertAlmostEqual(h2, 0.0004475, places=12)
        filtered = filter_variance(np.array([-0.03, 0.01, -0.02]), params, 0.0004)
        np.testing.assert_allclose(filtered, [0.0004, 0.00045, 0.0004125], atol=1e-15)

    def test_simulated_fit_recovers_dynamics_and_units(self):
        rng = np.random.default_rng(294)
        noise = rng.standard_t(7, 3500) * np.sqrt(5 / 7)
        residuals = np.empty(len(noise))
        variance = 0.0004
        for index, shock in enumerate(noise):
            residuals[index] = np.sqrt(variance) * shock
            variance = 0.00002 + 0.10 * residuals[index] ** 2 + 0.85 * variance
        residuals = residuals[500:]
        fitted = fit_garch(residuals)
        omega, alpha, beta, df = fitted["params"]
        self.assertLess(abs(alpha - 0.10), 0.05)
        self.assertLess(abs(beta - 0.85), 0.08)
        self.assertLess(abs(df - 7), 2.5)
        self.assertGreater(omega, 0)
        self.assertLessEqual(alpha + beta, 0.999)
        self.assertTrue(np.all(fitted["variance"] > 0))
        percentage_fit = fit_garch(100 * residuals)
        np.testing.assert_allclose(percentage_fit["params"][1:], fitted["params"][1:], rtol=1e-6)
        np.testing.assert_allclose(percentage_fit["variance"], 10000 * fitted["variance"], rtol=1e-6)
        self.assertAlmostEqual(
            percentage_fit["nll"] - fitted["nll"], len(residuals) * np.log(100), places=6,
        )


if __name__ == "__main__":
    unittest.main()
