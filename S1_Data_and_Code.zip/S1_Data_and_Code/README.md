# Data and code for cross-asset risk transmission and portfolio decisions

Author: Die Hu (2026).

This package contains the analysis implementation, frozen protocol, unit tests,
model archives, portfolio ledgers, and numerical results supporting the study.
Extract all six accompanying ZIP files into the same parent directory; they
populate one common `S1_Data_and_Code` directory. The archives contain:

- S1_Data_and_Code.zip: code, tests, protocols, licensed source data, main results, and tables.
- S2_Development_and_Figures.zip: development archives and figure exports.
- S3_Allocation_and_Tail_Sensitivity.zip: allocation, tail, weekly, no-gold, and risk-cap analyses.
- S4_Graph_and_Delay_Sensitivity.zip: graph-setting and extra-delay analyses.
- S5_Seed13_14_Sensitivity.zip: seed design and summaries, plus seeds 20261013 and 20261014.
- S6_Seed15_16_Sensitivity.zip: seeds 20261015 and 20261016.

Run all commands from this directory. The analysis uses Python 3.12 and CPU
execution. `run.py` starts each command with one numerical-library thread.

## Installation and quick verification

```sh
python -m pip install -r requirements.txt
python run.py -m unittest discover -s tests -v
python run.py -m scripts.verify_results
```

The 44 unit tests cover distribution identities and gradients, graph fitting,
shared-network gradients, scenario construction, optimization, transaction-cost
accounting, signal and execution timing, weekly holdings, statistical inference,
and risk matching. The lightweight result verification recomputes primary J
values from archived net returns, checks portfolio accounting and paired dates,
and compares equivalent graph histories directly. It requires no downloads or
model training. `verification_results.json` records these checks.

## Data sources and preparation

The RepOD source workbook and its original README are supplied under their
respective third-party terms. Dataset authors: Piotr Fiszeder and Radoslaw
Pietrzyk. Dataset: *USO_GLD_SPY_BTC_base*, DOI
https://doi.org/10.18150/AN5NET, version 2.0, released 16 August 2026. The study
uses the repository's original Excel file (file 81381) and the USO, GLD, and BTC
close-price series. The Spy sheet is excluded under the recorded protocol.
The Excel file is CC BY 4.0; the repository README specifies CC0 for that file.
See `THIRD_PARTY_NOTICES.txt` and `data/manifest.json` for source attribution.

Japanese ETF source files, asset prices, asset returns, and node features are
obtained directly from Nomura Asset Management and are not distributed here.
The official files are at:

- https://www.nomura-am.co.jp/fund/etf/history/ETF_1306.csv
- https://www.nomura-am.co.jp/fund/etf/history/ETF_1343.csv
- https://www.nomura-am.co.jp/fund/etf/history/ETF_2510.csv
- https://www.nomura-am.co.jp/fund/etf/history/ETF_1328.csv

The study uses dividend-included per-share NAV and common observed dates
through the protocol cutoff of 31 December 2025; the last common observed
date is 30 December 2025. The recorded download vintage is in the manifest.
The source provider maintains the online files; later revisions are identified
by the download record produced by the downloader.

```sh
python run.py -m scripts.prepare_data
python run.py -m scripts.prepare_features
```

The downloader retains existing files and saves new files under `data/raw`.
Preparation writes `data/processed/{repod,japan}`. It applies no date filling,
winsorization, or additional price adjustment. The included Japanese model
outputs, PITs, and portfolio ledgers are research-generated analysis outputs.
Their inclusion does not extend rights in the provider's underlying data.

## Reproduce the main analysis

`configs/frozen_protocol.json` is the complete main protocol. Its actual
recording time is 13 October 2026 at 04:42:54.747030 UTC; the historical
selection-information cutoff is 31 December 2020. These are distinct dates.
The six-candidate development comparison is retained in
`outputs/development_graph`. The first evaluated main-study targets are
5 January 2021 (RepOD, 876 observations) and 6 January 2021 (Japan, 1221
observations). A signal at s is executed at s+1 and forecasts the single-period
return ending at s+2. Only matured historical labels and PIT vectors are used.

After data preparation, run:

```sh
python run.py -m scripts.run_confirmation --panel repod --stage all
python run.py -m scripts.run_confirmation --panel japan --stage all
python run.py -m scripts.report_confirmation --stage full
```

The original development grid and descriptive summaries can be rebuilt with:

```sh
python run.py -m scripts.run_baselines
python run.py -m scripts.score_historical_development
python run.py -m scripts.run_graph_development --stage grid
python run.py -m scripts.run_graph_development --stage portfolios --lambda1 0.08 --lambda2 0.005
python run.py -m scripts.run_m4_development --stage all
python run.py -m scripts.report_development_stress
```

These commands replay and replace the corresponding output files. Use a
separate extracted copy when retaining the supplied archived results.
The main endpoint is J = mean(net return) - 0.05 ES_0.05(loss), expressed in
daily basis points. ES uses exactly the specified tail mass, including a
fractional boundary observation. Main inference uses 5000 paired stationary
bootstrap draws with mean block length 20 and seed 20261012. Two-sided centered
p values use the plus-one correction. The two primary comparisons form one
Holm family; secondary decision, prediction, and calibration families are
defined separately within each panel. Source-equivalent graph variants retain
their labels and share one numerical result and one hypothesis.

## Supplementary analyses

Branch protocols and implementation-recording times accompany their results.
Supplementary settings retain the main selected graph penalties and are not
used to reselect them. The following commands reproduce the supplied branches:

```sh
python run.py -m scripts.report_sensitivity
python run.py -m scripts.run_allocation_batch --workers 2
python run.py -m scripts.report_allocation_sensitivity
python run.py -m scripts.run_delay_sensitivity --panel repod --stage all
python run.py -m scripts.run_delay_sensitivity --panel japan --stage all
python run.py -m scripts.report_delay_sensitivity
python run.py -m scripts.run_tail_execution_sensitivity --all
python run.py -m scripts.report_tail_execution_sensitivity
python run.py -m scripts.run_no_gold_sensitivity --stage all
python run.py -m scripts.report_no_gold_sensitivity
python run.py -m scripts.run_risk_matching
python run.py -m scripts.run_graph_sensitivity --panel repod --stage all
python run.py -m scripts.run_graph_sensitivity --panel japan --stage all
python run.py -m scripts.run_graph_sensitivity --stage report
python run.py -m scripts.run_seed_sensitivity --stage run --workers 2
```

The delay branch rebuilds the forecast horizon at s+3 and executes at s+2.
The 2022 subperiod slices continuous realized paths. The seed analysis reports
the full range across seeds 20261012 through 20261016, without an additional
significance test. Every supplementary multiplicity family is recorded in its
branch output and the supplementary table source fields.

## Figures, tables, and file organization

`outputs/confirmation/figures` contains the archived figure exports and their
underlying numerical values. The portable plotting scripts use the bundled
DejaVu Sans font; archived publication figures retain their original typography.

```sh
python run.py -m scripts.make_main_manuscript_tables
python run.py -m scripts.make_supplementary_tables
python run.py -m scripts.plot_confirmation_figures --stage all
python run.py -m scripts.plot_graph_structure
python run.py -m scripts.plot_remaining_sensitivity
python run.py -m scripts.plot_study_design
```

`outputs/manuscript_tables` contains numerical table parts. Archived filenames
use their analysis-stage numbering: `table_3*` supplies manuscript Table 2
(RepOD), `table_4*` supplies Table 3 (Japan), and `table_2*` supplies Table 4
(prediction and calibration). `table_1*` and `table5*` supply Tables 1 and 5.
Table S1 contains 39 labels, Table S2 contains ten seed-panel records and two
panel ranges, Table S3 contains seven 2020 development descriptions, and Table
S4 contains six development candidates. See `DATA_DICTIONARY.txt` for units,
date conventions, array axes, costs, and source aliases.

The original analysis code is provided under the MIT License. Original
research-generated numerical outputs are provided under CC BY 4.0, subject
to the third-party source qualifications in `THIRD_PARTY_NOTICES.txt`.
