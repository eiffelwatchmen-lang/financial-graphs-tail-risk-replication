"""Run an analysis module using the package's CPU execution settings."""
import argparse
import os
import runpy
import sys

os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"
parser = argparse.ArgumentParser()
parser.add_argument("-m", dest="module", required=True)
parser.add_argument("arguments", nargs=argparse.REMAINDER)
args = parser.parse_args()
sys.argv = [args.module, *args.arguments]
runpy.run_module(args.module, run_name="__main__")
