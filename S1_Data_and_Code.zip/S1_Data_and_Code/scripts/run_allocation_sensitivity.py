"""Reoptimize portfolios under one changed cost or risk-preference setting."""
import argparse
import json
from pathlib import Path
import time
import numpy as np
import pandas as pd
from scripts.baselines import backtest, summarize
from scripts.joint_risk import solve_mean_cvar
from scripts.run_graph_development import load_panel, scenarios_at
ROOT = Path(__file__).resolve().parents[1]
COST_MULTIPLIERS = {'cost_0': 0.0, 'cost_0p5': 0.5, 'cost_2': 2.0, 'cost_4': 4.0}
KAPPAS = {'kappa_0p02': 0.02, 'kappa_0p10': 0.1, 'kappa_0p20': 0.2}

def run_sensitivity(config, panel_name, model, setting, *, target_count=None, output_directory=None):
    """Replay from cash on the original target dates using frozen forecasts.

    target_count and output_directory allow a short isolated smoke run; the CLI
    always uses the full confirmation window and the setting's own directory.
    """
    portfolio = config['portfolio']
    if setting in COST_MULTIPLIERS:
        multiplier = COST_MULTIPLIERS[setting]
        kappa = portfolio['kappa']
    else:
        multiplier = 1.0
        kappa = KAPPAS[setting]
    rates = multiplier * np.asarray(config['panels'][panel_name]['cost_rates'])
    alpha, cap = (portfolio['tail_probability'], portfolio['weight_cap'])
    graph_directory = ROOT / 'outputs/confirmation' / panel_name / 'graph'
    forecast_path = graph_directory / f'{model}_forecasts.npz'
    forecast = np.load(forecast_path)
    scores = pd.read_csv(graph_directory / f'{model}_scores.csv', parse_dates=['target_date'])
    if target_count is not None:
        scores = scores.iloc[:target_count]
    dates, returns, _, _, _ = load_panel(config, panel_name, 'test')
    start, end = (scores.target_date.min(), scores.target_date.max())
    directory = ROOT / 'outputs/confirmation/allocation_sensitivity' / setting / panel_name if output_directory is None else Path(output_directory)
    directory.mkdir(parents=True, exist_ok=True)
    settings = {'setting': setting, 'panel': panel_name, 'scope': 'confirmation_sensitivity' if target_count is None else 'smoke', 'cost_multiplier': multiplier, 'cost_rates': rates.tolist(), 'kappa': kappa, 'alpha': alpha, 'weight_cap': cap, 'scenario_count': config['copula']['scenarios'], 'seed': config['seed'], 'frozen_protocol_source': (ROOT / 'configs/frozen_protocol.json').relative_to(ROOT).as_posix(), 'frozen_forecast_directory': graph_directory.relative_to(ROOT).as_posix(), 'forecast_sources': {name: (graph_directory / f'{name}_forecasts.npz').relative_to(ROOT).as_posix() for name in ['FULL', 'A0']}, 'first_target': str(start.date()), 'last_target': str(end.date()), 'observations': len(scores), 'distribution_retrained': False, 'allocation_reoptimized': True, 'costs_recomputed_per_trade': True, 'initialization': 'fresh_equal_weight_purchase_from_cash', 'random_draws': 'Same signal-date seed, 10000 joint scenarios and frozen marginal/copula inputs as the main experiment.', 'kappa_use': 'Both mean-CVaR optimization and J evaluation.'}
    (directory / 'settings.json').write_text(json.dumps(settings, ensure_ascii=False, indent=2), encoding='utf-8')
    begin = time.perf_counter()
    count = 0

    def strategy(signal, knownweights):
        nonlocal count
        scenarios = scenarios_at(signal, dates, forecast, config)
        weights = solve_mean_cvar(scenarios, forecast['location'][signal], knownweights, rates, alpha, kappa, cap)
        count += 1
        if count % 100 == 0:
            print(f'{setting} {panel_name} {model}: optimized {count}/{len(scores) - 1} signals, {time.perf_counter() - begin:.1f}s', flush=True)
        return weights
    ledger = backtest(returns, model, start, end, rates=rates, cap=cap, alpha=alpha, kappa=kappa, strategy=strategy)
    ledger.to_csv(directory / f'{model}_ledger.csv', index=False)
    result = summarize(ledger, kappa, alpha)
    result.update({'setting': setting, 'panel': panel_name, 'cost_rates': rates.tolist(), 'cost_multiplier': multiplier, 'kappa': kappa, 'alpha': alpha, 'frozen_forecast_source': forecast_path.relative_to(ROOT).as_posix(), 'optimized_signals': count, 'elapsed_seconds': time.perf_counter() - begin})
    (directory / f'{model}_summary.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f"{setting} {panel_name} {model}: {len(ledger)} targets, J={result['J_daily_bp']:.8f} bp/day", flush=True)
    return (ledger, result)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--panel', choices=['repod', 'japan'], required=True)
    parser.add_argument('--model', choices=['FULL', 'A0'], required=True)
    parser.add_argument('--setting', choices=[*COST_MULTIPLIERS, *KAPPAS], required=True)
    args = parser.parse_args()
    config = json.loads((ROOT / 'configs/frozen_protocol.json').read_text(encoding='utf-8'))
    run_sensitivity(config, args.panel, args.model, args.setting)
if __name__ == '__main__':
    main()
