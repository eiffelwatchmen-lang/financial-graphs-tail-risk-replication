"""Paired stationary-bootstrap inference for decision and prediction scores.

Complete date rows are resampled jointly across strategies. The stationary
bootstrap uses geometric blocks (Politis and Romano, 1994); Holm adjustment
follows the sequential Bonferroni procedure (Holm, 1979).
"""
import numpy as np
from scripts.tail_graph import stationary_bootstrap_indices

def _j_components(net_returns, alpha, kappa):
    """Compute means and exact empirical tail integrals on the date axis."""
    means = net_returns.mean(axis=-2)
    losses = np.sort(-net_returns, axis=-2)[..., ::-1, :]
    mass = alpha * net_returns.shape[-2]
    whole = int(np.floor(mass))
    fraction = mass - whole
    tail_sum = losses[..., :whole, :].sum(axis=-2)
    if fraction > 0:
        tail_sum += fraction * losses[..., whole, :]
    loss_es = tail_sum / mass
    return (means, loss_es, means - kappa * loss_es)

def _summarize_differences(point, bootstrap):
    interval = np.quantile(bootstrap, [0.025, 0.975], axis=0)
    exceedances = np.count_nonzero(np.abs(bootstrap - point) >= np.abs(point), axis=0)
    return {'point_difference': point, 'ci_lower': interval[0], 'ci_upper': interval[1], 'p_value': (1 + exceedances) / (len(bootstrap) + 1), 'bootstrap_differences': bootstrap}

def paired_j_bootstrap(net_returns, pairs, alpha=0.05, kappa=0.05, repetitions=5000, block_length=20, seed=20261012):
    """Infer paired J differences in decimal return units, left minus right.

    Each bootstrap draw re-estimates both the mean and ES from its resampled
    returns. The interval is an unadjusted 95% percentile interval; alpha is
    the ES tail probability. The two-sided p value centers bootstrap
    differences at the observed difference and uses the (count+1)/(B+1) rule.
    """
    net_returns = np.asarray(net_returns, dtype=float)
    pairs = np.asarray(pairs, dtype=int)
    left, right = (pairs[:, 0], pairs[:, 1])
    means, loss_es, values = _j_components(net_returns, alpha, kappa)
    point = values[left] - values[right]
    rng = np.random.default_rng(seed)
    bootstrap = np.empty((repetitions, len(pairs)))
    for start in range(0, repetitions, 256):
        stop = min(start + 256, repetitions)
        rows = stationary_bootstrap_indices(len(net_returns), stop - start, block_length, rng)
        _, _, sampled_values = _j_components(net_returns[rows], alpha, kappa)
        bootstrap[start:stop] = sampled_values[:, left] - sampled_values[:, right]
    result = _summarize_differences(point, bootstrap)
    es_difference = loss_es[left] - loss_es[right]
    result.update(pairs=pairs, mean_net_return=means, loss_es=loss_es, J=values, mean_difference=means[left] - means[right], loss_es_difference=es_difference, es_contribution=-kappa * es_difference)
    return result

def paired_mean_bootstrap(values, pairs, repetitions=5000, block_length=20, seed=20261012):
    """Paired mean-score differences, using the same centered bootstrap test."""
    values = np.asarray(values, dtype=float)
    pairs = np.asarray(pairs, dtype=int)
    left, right = (pairs[:, 0], pairs[:, 1])
    means = values.mean(axis=0)
    point = means[left] - means[right]
    rng = np.random.default_rng(seed)
    bootstrap = np.empty((repetitions, len(pairs)))
    for start in range(0, repetitions, 256):
        stop = min(start + 256, repetitions)
        rows = stationary_bootstrap_indices(len(values), stop - start, block_length, rng)
        sampled_means = values[rows].mean(axis=1)
        bootstrap[start:stop] = sampled_means[:, left] - sampled_means[:, right]
    result = _summarize_differences(point, bootstrap)
    result.update(pairs=pairs, means=means)
    return result

def holm_adjust(p_values):
    """Return Holm-adjusted p values in their original comparison order."""
    p_values = np.asarray(p_values, dtype=float)
    order = np.argsort(p_values)
    adjusted_ordered = np.minimum(1, np.maximum.accumulate((len(p_values) - np.arange(len(p_values))) * p_values[order]))
    adjusted = np.empty_like(p_values)
    adjusted[order] = adjusted_ordered
    return adjusted
