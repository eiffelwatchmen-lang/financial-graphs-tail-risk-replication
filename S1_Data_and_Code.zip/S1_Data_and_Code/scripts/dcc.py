"""DCC(1,1) Gaussian correlation estimation and two-step correlation forecast."""
import numpy as np
from scipy.optimize import minimize
from scipy.signal import lfilter

def normalize(q):
    """Convert one covariance-like Q matrix or a batch to correlations."""
    scale = np.sqrt(np.diagonal(q, axis1=-2, axis2=-1))
    return q / (scale[..., :, None] * scale[..., None, :])

def _dcc_path(params, z, qbar):
    a, b = params
    innovations = np.empty((len(z), z.shape[1], z.shape[1]))
    innovations[0] = qbar
    innovations[1:] = (1 - a - b) * qbar + a * z[:-1, :, None] * z[:-1, None, :]
    return lfilter([1.0], [1.0, -b], innovations, axis=0)

def dcc_nll_gradient(params, z, qbar):
    """Mean Gaussian correlation pseudo-likelihood and analytic a/b gradient."""
    a, b = params
    q = _dcc_path(params, z, qbar)
    derivative_inputs = np.zeros((len(z), 2, z.shape[1], z.shape[1]))
    derivative_inputs[1:, 0] = z[:-1, :, None] * z[:-1, None, :] - qbar
    derivative_inputs[1:, 1] = q[:-1] - qbar
    dq = lfilter([1.0], [1.0, -b], derivative_inputs, axis=0)
    diagonal = np.diagonal(q, axis1=-2, axis2=-1)
    scale = np.sqrt(diagonal)
    denominator = scale[:, :, None] * scale[:, None, :]
    correlation = q / denominator
    relative_diagonal_derivative = np.diagonal(dq, axis1=-2, axis2=-1) / diagonal[:, None, :]
    dr = dq / denominator[:, None, :, :] - 0.5 * correlation[:, None, :, :] * (relative_diagonal_derivative[:, :, :, None] + relative_diagonal_derivative[:, :, None, :])
    precision = np.linalg.inv(correlation)
    weighted_z = np.einsum('tij,tj->ti', precision, z)
    _, logdet = np.linalg.slogdet(correlation)
    nll = 0.5 * np.mean(logdet + np.einsum('ti,ti->t', z, weighted_z))
    score_matrix = precision - weighted_z[:, :, None] * weighted_z[:, None, :]
    gradient = 0.5 * np.einsum('tij,tpij->p', score_matrix, dr) / len(z)
    return (float(nll), gradient)

def fit_dcc(z):
    """Fit DCC to known standardized residuals, with Q0 = mean(z z').

    q_last is the Q for the last supplied observation, before incorporating
    that observation's innovation. This convention matches daily state updates.
    """
    z = np.asarray(z, dtype=float)
    qbar = z.T @ z / len(z)
    result = minimize(dcc_nll_gradient, x0=[0.03, 0.95], args=(z, qbar), jac=True, method='SLSQP', bounds=[(0.0, 0.999), (0.0, 0.999)], constraints={'type': 'ineq', 'fun': lambda params: 0.999 - params.sum(), 'jac': lambda params: -np.ones(2)}, options={'ftol': 1e-09, 'maxiter': 150})
    if not result.success:
        raise RuntimeError(f'DCC estimation failed: {result.message}')
    return {'params': result.x, 'qbar': qbar, 'q_last': _dcc_path(result.x, z, qbar)[-1], 'nll': float(result.fun), 'iterations': int(result.nit)}

def forecast_correlation(params, qbar, q_last, z_last):
    """Return exact next Q and the Engle–Sheppard two-step R approximation.

    Q1 includes the latest observed innovation. R2 forecasts the correlation
    of the second future single-period return, not a two-period aggregate.
    """
    a, b = params
    q1 = (1 - a - b) * qbar + a * np.outer(z_last, z_last) + b * q_last
    r1 = normalize(q1)
    rbar = normalize(qbar)
    r2 = (1 - a - b) * rbar + (a + b) * r1
    return (q1, r2)
