"""Run the 28 predefined allocation sensitivity paths on local CPU workers."""
import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime, timezone
import json
import os
os.environ['OPENBLAS_NUM_THREADS'] = '1'
os.environ['OMP_NUM_THREADS'] = '1'
from scripts.run_allocation_sensitivity import COST_MULTIPLIERS, KAPPAS, ROOT, run_sensitivity

def run_job(config, panel, model, setting):
    return run_sensitivity(config, panel, model, setting)[1]

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--workers', type=int, default=6)
    args = parser.parse_args()
    config = json.loads((ROOT / 'configs/frozen_protocol.json').read_text(encoding='utf-8'))
    settings = [*COST_MULTIPLIERS, *KAPPAS]
    jobs = [(panel, model, setting) for setting in settings for panel in ('repod', 'japan') for model in ('FULL', 'A0')]
    directory = ROOT / 'outputs/confirmation/allocation_sensitivity'
    directory.mkdir(parents=True, exist_ok=True)
    design = {'recorded_at_utc': datetime.now(timezone.utc).isoformat(), 'scope': 'Prespecified sensitivity values; implementation recorded after the main analysis, before full sensitivity runs.', 'models': ['FULL', 'A0'], 'panels': ['repod', 'japan'], 'cost_multipliers': COST_MULTIPLIERS, 'risk_preferences': KAPPAS, 'one_factor_at_a_time': True, 'paths': len(jobs), 'cpu_workers': args.workers, 'distribution_forecasts': 'Reuse frozen main-model archives and signal-date scenario seeds.', 'allocation': 'Reoptimize each path; exact self-financing costs and holdings recomputed.', 'inference': 'Paired stationary bootstrap B=5000, L=20; one separate Holm family of 14 sensitivity comparisons.', 'primary_analysis_changed': False}
    (directory / 'design.json').write_text(json.dumps(design, ensure_ascii=False, indent=2), encoding='utf-8')
    results = []
    with ProcessPoolExecutor(max_workers=args.workers) as executor:
        futures = [executor.submit(run_job, config, *job) for job in jobs]
        for future in as_completed(futures):
            result = future.result()
            results.append(result)
            (directory / 'completed_runs.json').write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding='utf-8')
            print(f"Completed {len(results)}/{len(jobs)}: {result['setting']} {result['panel']} {result['model']}", flush=True)
if __name__ == '__main__':
    main()
