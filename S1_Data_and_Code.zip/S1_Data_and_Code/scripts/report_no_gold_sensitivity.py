"""Summarize the completed three-fund external sensitivity."""
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scripts.statistical_inference import paired_j_bootstrap
ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / 'outputs/confirmation/no_gold_sensitivity'

def main():
    config = json.loads((OUTPUT / 'design.json').read_text(encoding='utf-8'))['protocol']
    directory = OUTPUT / 'japan/graph'
    ledgers = [pd.read_csv(directory / f'{model}_ledger.csv', parse_dates=['target_date']) for model in ['FULL', 'A0']]
    pd.testing.assert_series_equal(ledgers[0].target_date, ledgers[1].target_date)
    inference = paired_j_bootstrap(np.column_stack([ledger.net_return for ledger in ledgers]), [(0, 1)], alpha=config['portfolio']['tail_probability'], kappa=config['portfolio']['kappa'], repetitions=config['inference']['bootstrap_repetitions'], block_length=config['inference']['block_length'], seed=config['seed'])
    updates = pd.read_csv(directory / 'graph_updates.csv')
    prediction = pd.read_csv(directory / 'prediction_summary.csv').set_index('model')
    row = {'panel': 'japan_no_gold', 'assets': '1306,1343,2510', 'removed_asset': '1328', 'observations': len(ledgers[0]), 'first_target': ledgers[0].target_date.iloc[0].date(), 'last_target': ledgers[0].target_date.iloc[-1].date(), 'FULL_J_daily_bp': 10000 * inference['J'][0], 'A0_J_daily_bp': 10000 * inference['J'][1], 'delta_J_daily_bp': 10000 * inference['point_difference'][0], 'delta_J_ci95_lower_bp': 10000 * inference['ci_lower'][0], 'delta_J_ci95_upper_bp': 10000 * inference['ci_upper'][0], 'p_raw': inference['p_value'][0], 'supplementary_family_size': 1, 'FULL_mean_FZ': prediction.loc['FULL', 'mean_fz'], 'A0_mean_FZ': prediction.loc['A0', 'mean_fz'], 'graph_updates': len(updates), 'updates_with_edges': int((updates.edges > 0).sum()), 'max_edges': int(updates.edges.max())}
    table = pd.DataFrame([row])
    table.to_csv(OUTPUT / 'comparison_summary.csv', index=False)
    original = pd.read_csv(ROOT / 'outputs/confirmation/primary_comparison.csv').query("panel == 'japan'")
    report = ['外部去黄金补充分析', '移除1328，保留1306、1343、2510及原四资产共同日历。完整重估历史图、FULL/A0边际预测和成熟PIT依赖，再从现金等权建仓进行配置。固定原超参数、成本和主要终点，不重新选参。', table.to_string(index=False, float_format=lambda x: f'{x:.6f}'), '此单项补充比较采用5000次配对平稳区块bootstrap、平均区块20、种子20261012；每次重新估计均值及分数边界ES95。报告未校正95%百分位区间和中心化双侧p。单项检验无需额外Holm调整，不并入原主要检验族。', '原日本四资产结果作为描述性参考：\n' + original[['observations', 'delta_J_daily_bp', 'delta_J_ci95_lower_bp', 'delta_J_ci95_upper_bp', 'p_holm_two_panels']].to_string(index=False, float_format=lambda x: f'{x:.6f}'), 'FZ仅比较同一三资产等权实现序列上的FULL与A0；三资产与四资产FZ对应不同实现收益，不能据其绝对值排序推断去黄金的效果。']
    (OUTPUT / 'report.txt').write_text('\n\n'.join(report) + '\n', encoding='utf-8')
    print(table.to_string(index=False), flush=True)
if __name__ == '__main__':
    main()
