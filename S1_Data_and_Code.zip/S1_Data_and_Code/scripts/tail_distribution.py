"""Student t return distribution conditional on returns exceeding -1.

``loc`` is the fixed historical location supplied by the forecasting model; it
is not the conditional mean after truncation. Inputs follow NumPy broadcasting.
The experiment uses positive scales, df in [3, 30], and observations above -1.
"""
import numpy as np
from scipy.special import digamma
from scipy.stats import t as student_t
DF_DIFFERENCE_STEP = 0.0001

def logpdf(x, loc, scale, df):
    """Log density with support (-1, infinity)."""
    x = np.asarray(x)
    z = (x - loc) / scale
    a = (-1 - np.asarray(loc)) / scale
    value = student_t.logpdf(z, df) - np.log(scale) - student_t.logsf(a, df)
    return np.where(x > -1, value, -np.inf)

def cdf(x, loc, scale, df):
    """Conditional CDF, using survival probabilities near the lower bound."""
    x = np.asarray(x)
    z = (x - loc) / scale
    a = (-1 - np.asarray(loc)) / scale
    value = -np.expm1(student_t.logsf(z, df) - student_t.logsf(a, df))
    return np.where(x > -1, value, 0.0)

def ppf(u, loc, scale, df):
    """Conditional quantile; u may be a scenario-by-asset array."""
    a = (-1 - np.asarray(loc)) / scale
    survival = (1 - np.asarray(u)) * np.exp(student_t.logsf(a, df))
    return loc + scale * student_t.isf(survival, df)

def lower_tail_es(alpha, loc, scale, df):
    """Mean return below the alpha quantile, for 0 < alpha < 1 and df > 1.

    This is return ES, not positive loss ES. The first-moment antiderivative
    integrates over the retained interval from a to the conditional quantile.
    """
    a = (-1 - np.asarray(loc)) / scale
    log_z = student_t.logsf(a, df)
    q = student_t.isf((1 - np.asarray(alpha)) * np.exp(log_z), df)
    left = np.exp(np.log1p(a * a / df) + student_t.logpdf(a, df) - log_z)
    right = np.exp(np.log1p(q * q / df) + student_t.logpdf(q, df) - log_z)
    moment = df / (df - 1) * (left - right) / alpha
    return loc + scale * moment

def nll_grad(y, loc, scale, df):
    """Return elementwise (NLL, dNLL/dscale, dNLL/ddf), for y > -1.

    The scale derivative and ordinary t density's df derivative are analytic.
    Only d(log survival(a, df))/ddf uses a central difference, with a fixed
    step of 1e-4. Aggregate the returned df contributions for a shared df.
    """
    z = (np.asarray(y) - loc) / scale
    a = (-1 - np.asarray(loc)) / scale
    log_z = student_t.logsf(a, df)
    nll = -student_t.logpdf(z, df) + np.log(scale) + log_z
    hazard_a = np.exp(student_t.logpdf(a, df) - log_z)
    dscale = (1 - (df + 1) * z * z / (df + z * z) + a * hazard_a) / scale
    dlog_density = 0.5 * (digamma((df + 1) / 2) - digamma(df / 2) - 1 / df) - 0.5 * np.log1p(z * z / df) + (df + 1) * z * z / (2 * df * (df + z * z))
    h = DF_DIFFERENCE_STEP
    dlog_z = (student_t.logsf(a, df + h) - student_t.logsf(a, df - h)) / (2 * h)
    ddf = -dlog_density + dlog_z
    return (nll, dscale, ddf)
