"""Extract manuscript tables from archived reports without recomputing inference."""
import json
from pathlib import Path
from shutil import copyfile
import pandas as pd
ROOT = Path(__file__).resolve().parents[1]
CONFIRMATION = ROOT / 'outputs/confirmation'
OUTPUT = ROOT / 'outputs/manuscript_tables'
PANELS = ('repod', 'japan')

def ablation_table():
    rows = []
    for panel in PANELS:
        directory = CONFIRMATION / panel / 'ablations'
        summary = pd.read_csv(directory / 'summary.csv', float_precision='round_trip')
        for variant in ['A1', 'A2', 'A3', 'A4']:
            group = summary.loc[summary.variant.eq(variant)]
            equivalence = [json.loads((directory / model / 'equivalence.json').read_text(encoding='utf-8')) for model in group.model]
            sources = group[['source_model', 'source_directory']].drop_duplicates()
            rows.append({'panel': panel, 'variant': variant, 'enumerated_labels': len(group), 'model_labels': ';'.join(group.model), 'independently_fitted_variants': int(group.separate_run.sum()), 'distinct_result_sources': len(sources), 'all_full_history_adjacencies_equivalent': all((row['adjacency_exact_equal'] for row in equivalence)), 'all_results_reference_primary_FULL': all((row['source_model'] == 'FULL' and row['source_directory'] == (CONFIRMATION / panel / 'graph').relative_to(ROOT).as_posix() for row in equivalence)), 'source_models': ';'.join(sources.source_model), 'source_directories': ';'.join(sources.source_directory), 'evidence_role': 'Identical-input aliases do not provide independent evidence.', 'observations': int(group.observations.iloc[0]), 'first_target': group.first_target.iloc[0], 'last_target': group.last_target.iloc[0], 'J_daily_bp_min': group.J_daily_bp.min(), 'J_daily_bp_max': group.J_daily_bp.max(), 'mean_FZ_min': group.mean_fz.min(), 'mean_FZ_max': group.mean_fz.max(), 'mean_graph_edges_min': group.mean_graph_edges.min(), 'mean_graph_edges_max': group.mean_graph_edges.max(), 'source_csv': (directory / 'summary.csv').relative_to(ROOT).as_posix(), 'equivalence_records': ';'.join(((directory / model / 'equivalence.json').relative_to(ROOT).as_posix() for model in group.model))})
    table = pd.DataFrame(rows)
    table.to_csv(OUTPUT / 'table5_graph_ablations.csv', index=False)
    return table

def comparison_rows(relative_source, category, config):
    """Normalize the existing report columns; empty p fields stay empty."""
    source = CONFIRMATION / relative_source
    raw = pd.read_csv(source, float_precision='round_trip')
    frame = raw.rename(columns={'tail_probability': 'alpha', 'ci95_lower_bp': 'delta_J_ci95_lower_bp', 'ci95_upper_bp': 'delta_J_ci95_upper_bp', 'delta_loss_ES95_daily_bp': 'delta_loss_es_daily_bp'}).copy()
    frame['category'] = category
    if 'alpha' not in frame:
        frame['alpha'] = config['portfolio']['tail_probability']
    if 'kappa' not in frame:
        frame['kappa'] = config['portfolio']['kappa']
    if 'block_length' not in frame:
        frame['block_length'] = config['inference']['block_length']
    frame['bootstrap_repetitions'] = config['inference']['bootstrap_repetitions']
    frame['source_csv'] = source.relative_to(ROOT).as_posix()
    frame['original_reference_directory'] = frame.panel.map(lambda panel: (CONFIRMATION / panel / 'graph').relative_to(ROOT).as_posix())
    frame['source_relation'] = 'new_strategy_path'
    frame['alias_of'] = ''
    frame['p_adjusted'] = pd.NA
    frame['adjusted_p_role'] = 'not_applicable'
    frame['source_adjusted_p_column'] = ''
    return frame

def set_adjustment(frame, column, family, size, role='within_supplementary_family'):
    frame['p_adjusted'] = frame[column]
    frame['family'] = family
    frame['family_size'] = size
    frame['adjusted_p_role'] = role
    frame['source_adjusted_p_column'] = column

def set_pair_sources(frame, directories):
    frame['FULL_result_source'] = [f'{directory}/FULL_ledger.csv' for directory in directories]
    frame['A0_result_source'] = [f'{directory}/A0_ledger.csv' for directory in directories]

def sensitivity_table(config):
    tables = []
    primary = comparison_rows('primary_comparison.csv', 'primary_reference', config)
    primary['setting'] = 'original_main'
    primary['source_relation'] = 'original_primary_reference'
    set_pair_sources(primary, primary.original_reference_directory)
    set_adjustment(primary, 'p_holm_two_panels', 'primary_two_panels', 2, 'original_primary_reference')
    tables.append(primary)
    allocation = comparison_rows('allocation_sensitivity/comparison_summary.csv', 'allocation', config)
    set_pair_sources(allocation, [(CONFIRMATION / 'allocation_sensitivity' / row.setting / row.panel).relative_to(ROOT).as_posix() for row in allocation.itertuples(index=False)])
    set_adjustment(allocation, 'p_holm_14_sensitivity', 'allocation_cost_and_kappa_14', allocation.Holm_family_size)
    allocation['source_relation'] = 'frozen_forecasts_reused; allocation_and_costs_recomputed'
    tables.append(allocation)
    delay = comparison_rows('delay_sensitivity/comparison_summary.csv', 'execution_delay', config)
    delay['setting'] = 'execution_lag_2_target_lag_3'
    set_pair_sources(delay, delay.delayed_source_directory)
    set_adjustment(delay, 'p_holm_two_panels_supplementary', 'extra_execution_delay_two_panels', 2)
    tables.append(delay)
    tail = comparison_rows('tail_execution_sensitivity/comparison_summary.csv', 'tail_or_frequency', config)
    set_pair_sources(tail, [(CONFIRMATION / 'tail_execution_sensitivity' / row.setting / row.panel).relative_to(ROOT).as_posix() for row in tail.itertuples(index=False)])
    set_adjustment(tail, 'p_holm_supplementary_family', tail.Holm_family, tail.Holm_family_size)
    tail['source_relation'] = 'frozen_forecasts_reused; allocation_and_costs_recomputed'
    tables.append(tail)
    risk = comparison_rows('risk_matching/comparison_summary.csv', 'risk_cap', config)
    risk['setting'] = 'ex_ante_EWMA_risk_cap'
    set_pair_sources(risk, [(CONFIRMATION / 'risk_matching' / panel).relative_to(ROOT).as_posix() for panel in risk.panel])
    set_adjustment(risk, 'p_holm_two_panels_supplementary', 'risk_cap_two_panels', 2)
    risk_models = pd.read_csv(CONFIRMATION / 'risk_matching/portfolio_summary.csv', float_precision='round_trip')
    inactive = risk_models.groupby('panel').fraction_scaled.max().eq(0)
    risk['source_relation'] = risk.panel.map(lambda panel: 'risk_cap_inactive_on_primary_targets' if inactive[panel] else 'risk_capped_primary_targets_and_recomputed_costs')
    tables.append(risk)
    no_gold = comparison_rows('no_gold_sensitivity/comparison_summary.csv', 'reduced_universe', config)
    no_gold['panel'] = 'japan'
    no_gold['setting'] = 'remove_gold_1328'
    no_gold['original_reference_directory'] = (CONFIRMATION / 'japan/graph').relative_to(ROOT).as_posix()
    set_pair_sources(no_gold, [(CONFIRMATION / 'no_gold_sensitivity/japan/graph').relative_to(ROOT).as_posix()])
    no_gold['family'], no_gold['family_size'] = ('no_gold_single_comparison', no_gold.supplementary_family_size)
    no_gold['adjusted_p_role'] = 'single_comparison_no_adjustment'
    tables.append(no_gold)
    graph = comparison_rows('graph_sensitivity/comparison_summary.csv', 'graph', config)
    graph['FULL_result_source'] = graph.FULL_source_directory + '/FULL_ledger.csv'
    graph['A0_result_source'] = graph.A0_source_directory + '/A0_ledger.csv'
    for index, row in graph.iterrows():
        member = row.in_supplementary_Holm_family
        column = 'p_holm_supplementary' if member else 'p_holm_primary_reference'
        graph.loc[index, 'p_adjusted'] = row[column]
        graph.loc[index, 'family'] = 'graph_new_distinct_sources_or_dates' if member else 'primary_two_panels'
        graph.loc[index, 'family_size'] = row.distinct_supplementary_hypotheses if member else 2
        graph.loc[index, 'adjusted_p_role'] = 'within_supplementary_family' if member else 'original_primary_reference'
        graph.loc[index, 'source_adjusted_p_column'] = column
        graph.loc[index, 'source_relation'] = 'same_primary_path_new_date_subset' if member and row.adjacency_exact_equal_entire_history else 'exact_primary_comparison_alias' if not member else 'new_graph_strategy_path'
        graph.loc[index, 'alias_of'] = '' if member else 'original_main/' + row.panel
    tables.append(graph)
    blocks = comparison_rows('sensitivity/block_lengths.csv', 'bootstrap_block_length', config)
    blocks['setting'] = blocks.block_length.map(lambda value: f'block_{value}')
    set_pair_sources(blocks, blocks.original_reference_directory)
    set_adjustment(blocks, 'p_holm_two_panels_sensitivity', blocks.setting + '_two_panels', 2)
    blocks['source_relation'] = 'same_primary_returns; changed_inference_block_length'
    tables.append(blocks)
    year = comparison_rows('sensitivity/year_2022.csv', 'descriptive_subperiod', config)
    year['setting'] = 'year_2022'
    set_pair_sources(year, year.original_reference_directory)
    year['family'] = 'descriptive_2022_no_hypothesis_family'
    year['family_size'] = 0
    year['source_relation'] = 'continuous_primary_path_slice; descriptive_interval_only'
    year['adjusted_p_role'] = 'no_p_values_in_original_report'
    tables.append(year)
    columns = ['category', 'setting', 'panel', 'family', 'family_size', 'alpha', 'kappa', 'observations', 'first_target', 'last_target', 'FULL_J_daily_bp', 'A0_J_daily_bp', 'delta_J_daily_bp', 'delta_J_ci95_lower_bp', 'delta_J_ci95_upper_bp', 'delta_mean_net_daily_bp', 'delta_loss_es_daily_bp', 'p_raw', 'p_adjusted', 'adjusted_p_role', 'bootstrap_repetitions', 'block_length', 'cost_multiplier', 'execution_lag', 'target_lag', 'trading_frequency', 'annual_target_volatility', 'assets', 'source_relation', 'alias_of', 'FULL_result_source', 'A0_result_source', 'original_reference_directory', 'source_csv', 'source_adjusted_p_column']
    table = pd.concat(tables, ignore_index=True).reindex(columns=columns)
    table.to_csv(OUTPUT / 'tableS1_sensitivity.csv', index=False)
    return table

def main():
    OUTPUT.mkdir(parents=True, exist_ok=True)
    config = json.loads((ROOT / 'configs/frozen_protocol.json').read_text(encoding='utf-8'))
    ablations = ablation_table()
    sensitivity = sensitivity_table(config)
    copyfile(CONFIRMATION / 'seed_sensitivity/comparison_summary.csv', OUTPUT / 'tableS2_seed_stability.csv')
    copyfile(CONFIRMATION / 'seed_sensitivity/stability_ranges.csv', OUTPUT / 'tableS2_seed_ranges.csv')
    copyfile(ROOT / 'outputs/development/2020_stress_description.csv', OUTPUT / 'tableS3_development_2020.csv')
    copyfile(ROOT / 'outputs/development_graph/candidate_decision_comparison.csv', OUTPUT / 'tableS4_development_candidates.csv')
    notes = 'Supplementary table notes\n\nAll tables are extracted from existing machine-readable reports and source mappings. No model is refitted, no bootstrap is rerun and no multiplicity correction is recalculated by this extraction script. Full numeric precision is retained in the CSV exports. Model and date source paths are included for reproducibility.\n\nTable 5. Graph ablations. Each row aggregates one variant within one panel. A1, A2 and A3 each have one label per panel. A4 enumerates all nonidentity node permutations: 5 for RepOD and 23 for Japan. The complete model-label list, number of separate fits, number of distinct result sources and exact historical adjacency-equivalence records are retained. All currently reported variants reference the corresponding primary FULL source because their entire graph-input histories are identical. These labels are not independent replications. J and FZ minima/maxima are simple ranges of already reported values. No additional p values are attached to these aliases. A1 freezes the available graph forward from the prespecified cutoff; A2 symmetrizes signed adjacency; A3 removes stability weighting; A4 permutes adjacency rows and columns without permuting asset features.\n\nTable S1. FULL minus A0 decision comparisons. The table contains 37 supplementary labels and two explicitly identified original-primary reference rows. J, effects and confidence intervals use daily basis points. J is mean net return minus kappa times empirical loss ES at the displayed alpha. Tail-probability rows use their own alpha for both allocation and evaluation; different kappa values define different decision objectives. Alpha=0.05 otherwise. Confidence intervals are unadjusted 95% percentile intervals from the archived paired stationary-bootstrap analysis, with 5,000 replicates, seed 20261012 and the displayed mean block length. Every bootstrap analysis re-estimates mean and exact fractional-tail ES. Effects and intervals are copied, not recomputed here.\n\nMultiplicity remains exactly as archived: the 14 cost/kappa comparisons form one Holm family; extra execution delay forms a two-panel family; tail probabilities form a four-comparison family; weekly trading forms a separate two-panel family; the risk cap forms a two-panel family. Block length 10 and block length 40 each retain their own two-panel sensitivity family. The single no-gold comparison has no additional adjustment; its adjusted-p cell is empty, not zero. No p value was reported for the descriptive 2022 subperiod, so both p columns remain empty for those rows.\n\nGraph-setting labels preserve the existing source-based mapping. The five labels with unchanged primary paths and dates directly reference the original two-panel primary p values and Holm values; they do not enter a new family. Only the Japanese 756-observation-window evaluation introduces a new date subset, with 1,141 dates from 2021-05-07 through 2025-12-30. It retains the continuous original portfolio path without reinitialization and belongs to the archived one-comparison supplementary family. The source_relation, alias_of and adjusted_p_role columns distinguish source reuse, a new date subset and primary-reference inference. The original primary Holm family is never expanded or recalculated. Multiple rows referencing the same return source do not constitute additional independent evidence.\n\nThe Japanese risk cap is inactive on the primary targets; its separate archived risk-cap family is retained, while this source relationship is stated explicitly. Japanese cost_4 produces equal-weight targets at numerical solver precision but continues daily rebalancing and incurs costs; its minute floating-point FULL-A0 difference is not a substantive effect. The no-gold row uses the original four-asset Japanese calendar but a newly estimated three-asset strategy. The extra-delay rows rebuild forecasts and mature PIT history for execution at s+2 and a single-period return at s+3; they are not delayed trades from the original forecasts. Weekly rows include every daily holding return and charge costs only when trades execute.\n\nTable S2. Random-seed stability. The seed-level table and panel-level range table are exact copies of seed_sensitivity/comparison_summary.csv and seed_sensitivity/stability_ranges.csv. All five seeds (20261012-20261016) are retained for both panels, including the original seed, without selecting a preferred run. The 10 seed-panel rows share the original target dates within each panel: 876 RepOD dates from 2021-01-05 through 2024-06-28, and 1,221 Japanese dates from 2021-01-06 through 2025-12-30. Each additional seed reruns graph stability sampling, predictor training, mature PIT dependence, scenarios and allocation with unchanged settings; FULL and A0 share signal-date base random draws within each seed. All archived monthly and evaluated graphs remain empty across all seeds. The two panel-level rows contain descriptive minimum-to-maximum ranges, not sampling confidence intervals. Seeds are algorithmic repetitions, not independent market samples. No additional p values, hypothesis tests or multiplicity adjustments are introduced, and the original primary inference remains unchanged. Values and source paths retain their original stored precision.\n\nTable S3. Development-period description. This file is an exact copy of outputs/development/2020_stress_description.csv. It describes seven archived strategies over 253 RepOD dates in 2020, which belongs to the historical development period. It is not an additional confirmation sample and adds no significance tests. Portfolio holdings and costs retain their original continuous development paths.\n\nTable S4. Development-candidate diagnostics. This file is an exact copy of outputs/development_graph/candidate_decision_comparison.csv and retains all six prespecified penalty candidates. The original selection used development-period FZ, with lower scores preferred; portfolio J did not replace that criterion. Comparisons of nonempty-graph candidates against the selected empty-graph FULL and A0 are development descriptions, not new confirmation tests. The two candidates with lambda1=0.08 have identical forecasts and portfolio results: lambda2=0.02 references the lambda2=0.005 source, as recorded by the archived alias columns. They do not provide independent replications. The table adds no statistical tests, and no candidate is reselected using J.\n\nThe supplementary settings were listed in the original experimental plan; detailed implementations recorded after the primary results were known retain that status. The actual protocol-freeze timestamp in 2026 is distinct from the historical information cutoff of 2020-12-31. These tables do not change either primary conclusion or hyperparameter selection.\n\nReproduction: python run.py -m scripts.make_supplementary_tables\n'
    (OUTPUT / 'supplementary_table_notes.txt').write_text(notes, encoding='utf-8')
    print(f'Table 5: {len(ablations)} rows; {ablations.enumerated_labels.sum()} variant labels')
    print(f'Table S1: {len(sensitivity)} rows')
    print(sensitivity.groupby('category', sort=False).size().to_string())
    print('Table S2: direct copies of 10 seed-panel rows and 2 panel-level range rows')
    print('Table S3: direct copy of the seven-model 2020 development description')
    print('Table S4: direct copy of six development-candidate diagnostics')
if __name__ == '__main__':
    main()
