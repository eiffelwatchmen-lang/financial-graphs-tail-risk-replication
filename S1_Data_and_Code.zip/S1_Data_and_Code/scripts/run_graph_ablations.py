"""Run graph ablations, reusing results only for exactly identical histories."""
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scripts.graph_ablations import nonidentity_permutations, transform_graphs
from scripts.run_graph_development import candidate_directory, load_panel, replay_forecasts, run_portfolios, score_forecasts
ROOT = Path(__file__).resolve().parents[1]

def run_ablations(config, base_directory, output_directory, panel_name='repod', phase='validation'):
    """Return a summary with each variant's result source and graph provenance.

    Equivalent variants reference their source forecast/ledger files through
    equivalence.json. Their own graph_cutoff remains in their own graphs.npz.
    """
    base_directory = Path(base_directory).resolve()
    output_directory = Path(output_directory).resolve()
    output_directory.mkdir(parents=True, exist_ok=True)
    dates, _, _, _, _ = load_panel(config, panel_name, phase)
    archive = np.load(base_directory / 'graphs.npz')
    base_settings = json.loads((base_directory / 'settings.json').read_text(encoding='utf-8'))
    first_graph = int(np.flatnonzero(archive['graph_cutoff'] >= 0)[0])
    static_cutoffs = config['ablations']['A1']['validation_cutoffs'] if phase == 'validation' else config['ablations']['A1']['test_cutoffs'][panel_name]
    asset_count = archive['adjacency'].shape[1]
    variants = [('A1', 'A1', None), ('A2', 'A2', None), ('A3', 'A3', None)]
    variants += [('A4_p' + ''.join(map(str, order)), 'A4', order) for order in nonidentity_permutations(asset_count)]
    representatives = [{'model': 'FULL', 'directory': base_directory, 'adjacency': archive['adjacency'], 'first_graph': first_graph}]
    rows = []
    for model, variant, permutation in variants:
        directory = output_directory / model
        directory.mkdir(parents=True, exist_ok=True)
        adjacency, cutoff_index = transform_graphs(archive, dates, variant, static_cutoffs, permutation=permutation, zero_tolerance=config['graph']['zero_tolerance'], own_control_count=len(config['graph']['own_controls']))
        current_first = int(np.flatnonzero(cutoff_index >= 0)[0])
        np.savez_compressed(directory / 'graphs.npz', adjacency=adjacency, graph_cutoff=cutoff_index, update_indices=archive['update_indices'])
        settings = {'lambda1': base_settings['lambda1'], 'lambda2': base_settings['lambda2'], 'panel': panel_name, 'phase': phase, 'model': model, 'protocol': config}
        (directory / 'settings.json').write_text(json.dumps(settings, ensure_ascii=False, indent=2), encoding='utf-8')
        metadata = {'model': model, 'variant': variant, 'panel': panel_name, 'phase': phase, 'source_graph_archive': (base_directory / 'graphs.npz').relative_to(ROOT).as_posix(), 'adjacency_orientation': 'target_by_source', 'static_cutoffs': static_cutoffs if variant == 'A1' else [], 'permutation': list(permutation) if permutation is not None else None, 'features_permuted': False, 'first_valid_graph_index': current_first, 'first_valid_graph_date': str(dates[current_first].date()), 'estimation_date_source': "This directory's graphs.npz graph_cutoff indexes the shared price-date axis; reused forecast CSV graph_fit_date describes its source model only.", 'training_update_schedule': 'Same monthly update_indices as FULL, including for the static graph variant.'}
        (directory / 'graph_metadata.json').write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding='utf-8')
        equivalent = None
        for representative in representatives:
            if current_first == representative['first_graph'] and np.array_equal(adjacency, representative['adjacency']):
                equivalent = representative
                break
        separate_run = equivalent is None
        if separate_run:
            replay_forecasts(config, directory, models=[model], panel_name=panel_name, phase=phase)
            score_forecasts(config, directory, models=[model], panel_name=panel_name, phase=phase)
            run_portfolios(config, directory, models=[model], panel_name=panel_name, phase=phase)
            source = {'model': model, 'directory': directory, 'adjacency': adjacency, 'first_graph': current_first}
            representatives.append(source)
        else:
            source = equivalent
        equivalence = {'model': model, 'equivalent': not separate_run, 'separate_run': separate_run, 'source_model': source['model'], 'source_directory': source['directory'].relative_to(ROOT).as_posix(), 'comparison': 'Exact equality of the entire historical adjacency array and first valid graph index; shared features, monthly training schedule, seed and training budget.', 'adjacency_exact_equal': not separate_run, 'first_valid_graph_index': current_first, 'result_use': 'Read source_model forecast, scores and ledger files from source_directory; identical graph inputs do not constitute repeated independent evidence.'}
        (directory / 'equivalence.json').write_text(json.dumps(equivalence, ensure_ascii=False, indent=2), encoding='utf-8')
        portfolio = pd.read_csv(source['directory'] / 'portfolio_summary.csv').set_index('model').loc[source['model']]
        prediction = pd.read_csv(source['directory'] / 'prediction_summary.csv').set_index('model').loc[source['model']]
        scores = pd.read_csv(source['directory'] / f"{source['model']}_scores.csv", parse_dates=['signal_date'])
        scored_indices = dates.get_indexer(scores.signal_date)
        row = portfolio.drop(labels='elapsed_seconds').to_dict()
        row.update({'model': model, 'variant': variant, 'permutation': ''.join(map(str, permutation)) if permutation is not None else '', 'mean_fz': float(prediction.mean_fz), 'var_breach_fraction': float(prediction.var_coverage), 'mean_graph_edges': float(np.count_nonzero(adjacency[scored_indices], axis=(1, 2)).mean()), 'separate_run': separate_run, 'source_model': source['model'], 'source_directory': source['directory'].relative_to(ROOT).as_posix(), 'first_valid_graph_index': current_first})
        rows.append(row)
        print(f"{model}: {('new fit' if separate_run else 'reuse ' + source['model'])}, J={row['J_daily_bp']:.6f}, FZ={row['mean_fz']:.8f}", flush=True)
    summary = pd.DataFrame(rows)
    summary.to_csv(output_directory / 'summary.csv', index=False)
    table = summary[['model', 'observations', 'J_daily_bp', 'mean_fz', 'mean_graph_edges', 'separate_run', 'source_model']].to_string(index=False, float_format=lambda value: f'{value:.8f}')
    run_count = int(summary.separate_run.sum())
    a4 = summary.loc[summary.variant == 'A4']
    phase_label = '开发期' if phase == 'validation' else '确认期'
    evaluation_note = '本次仅运行所选开发配置，未启动确认期评价。' if phase == 'validation' else '本次按确认阶段调用运行；消融属于既定主要比较之外的机制分析。'
    report = f"图机制消融报告：{panel_name} {phase_label}\n\n已处理 A1、A2、A3 及 A4 的全部 {len(a4)} 个非恒等节点置换，共 {len(summary)} 项设置。与 FULL 或已运行代表模型逐项比较整段历史邻接矩阵和首次有效图时点后，{len(summary) - run_count} 项输入完全相同并引用既有结果，{run_count} 项单独完成重新训练、评分和组合回测。原图惩罚为 lambda1={base_settings['lambda1']:g}、lambda2={base_settings['lambda2']:g}，本步骤不重新选参。\n\nJ 的单位为每日基点，越高越好；FZ 使用同一等权毛收益参考组合，越低越好。separate_run=False 表示该行引用 source_model 已有结果，没有独立重跑。\n{table}\n\nA1 按预定日期 {', '.join(static_cutoffs)} 仅向后冻结；截止前继续使用当时的历史动态图。每一段冻结均从原动态图取对应快照，并保存真正的图估计截止索引，不把冻结日期当作未经执行的重新估计日期。静态图下仍沿用 FULL 的月度预测器训练日程。\nA2 对带符号邻接矩阵作 (A+A')/2；A3 从原标准化回归系数的跨资产项重建不含稳定性权重的点估计，并保留原非零阈值；A4 同时置换矩阵行列，保持权重集合，资产特征不置换。{asset_count} 个节点共枚举 {len(a4)} 个非恒等排列，不制造额外随机重复。\n\nA4 的 J 范围为 [{a4.J_daily_bp.min():.8f}, {a4.J_daily_bp.max():.8f}]，FZ 范围为 [{a4.mean_fz.min():.8f}, {a4.mean_fz.max():.8f}]。范围相同的重复输入不增加独立证据。输入完全相同时，同一网络、特征、训练日期、种子及预算决定相同预测和配置；结果引用关系写入各目录 equivalence.json。各消融自身的 graph_fit_date 应由其 graphs.npz 中 graph_cutoff 读取，不能照抄被引用模型预测 CSV 中的图日期。\n\n本报告保留所有预设消融和置换结果。若当前图使变换后的输入完全相同，则当前样本不能区分相应机制；后续动态重估产生不同图时，仍须按同一规则重新训练并评价对应变换。{evaluation_note}\n默认开发复现命令：python run.py -m scripts.run_graph_ablations\n"
    (output_directory / 'report.txt').write_text(report, encoding='utf-8')
    return summary

def main():
    config = json.loads((ROOT / 'configs/protocol.json').read_text(encoding='utf-8'))
    base = candidate_directory(config['graph']['selected_lambda1'], config['graph']['selected_lambda2'])
    run_ablations(config, base, ROOT / 'outputs/development_ablations')
if __name__ == '__main__':
    main()
