"""Run development-period baselines; confirmation periods are not scored here."""
import json
from pathlib import Path
import time
import pandas as pd
from scripts.baselines import backtest, summarize
ROOT = Path(__file__).resolve().parents[1]

def main():
    config = json.loads((ROOT / 'configs/protocol.json').read_text(encoding='utf-8'))
    panel = config['panels']['repod']
    portfolio = config['portfolio']
    returns = pd.read_csv(ROOT / 'data/processed/repod/returns.csv', index_col='date', parse_dates=True)
    returns = returns.loc[:panel['validation_end'], panel['assets']]
    readiness = json.loads((ROOT / 'outputs/readiness_summary.json').read_text(encoding='utf-8'))
    start = max(panel['validation_start'], readiness['repod']['earliest_target_by_sample_count'])
    directory = ROOT / 'outputs/development'
    directory.mkdir(parents=True, exist_ok=True)
    summaries = []
    for model in ['M0', 'M1', 'M2', 'M3']:
        begin = time.perf_counter()
        records = backtest(returns, model, start, panel['validation_end'], rates=panel['cost_rates'], cap=portfolio['weight_cap'], alpha=portfolio['tail_probability'], kappa=portfolio['kappa'], shrink=portfolio['m2_diagonal_shrinkage'])
        records.to_csv(directory / f'{model}_ledger.csv', index=False)
        summary = summarize(records, portfolio['kappa'], portfolio['tail_probability'])
        summary['elapsed_seconds'] = time.perf_counter() - begin
        summaries.append(summary)
        print(f"{model}: {len(records)} development observations, {summary['elapsed_seconds']:.2f} seconds", flush=True)
    result = pd.DataFrame(summaries)
    result.to_csv(directory / 'baseline_summary.csv', index=False)
    print(result[['model', 'net_mean_daily_bp', 'loss_es95_daily_bp', 'J_daily_bp']].to_string(index=False))
if __name__ == '__main__':
    main()
