"""Recompute archived numerical identities without fitting models."""
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scripts.baselines import summarize
from scripts.joint_risk import fz_score

ROOT = Path(__file__).resolve().parents[1]


def main():
    config = json.loads((ROOT / "configs/frozen_protocol.json").read_text(encoding="utf-8"))
    primary = pd.read_csv(ROOT / "outputs/confirmation/primary_comparison.csv").set_index("panel")
    rows = []
    alias_count = 0
    for panel in ("repod", "japan"):
        folder = ROOT / "outputs/confirmation" / panel
        rates = np.array(config["panels"][panel]["cost_rates"])
        assets = config["panels"][panel]["assets"]
        reference = pd.read_csv(folder / "graph/FULL_ledger.csv").target_date
        assert len(reference) == config["confirmation"]["expected_observations"][panel]
        assert reference.iloc[0] == config["confirmation"]["expected_first_targets"][panel]
        values = {}
        for model in ("FULL", "A0", "M0", "M1", "M2", "M3", "M4"):
            group = "graph" if model in ("FULL", "A0") else "m4" if model == "M4" else "baselines"
            directory = folder / group
            ledger = pd.read_csv(directory / f"{model}_ledger.csv", parse_dates=["signal_date", "execution_date", "target_date"])
            np.testing.assert_array_equal(ledger.target_date.dt.strftime("%Y-%m-%d"), reference)
            net = (1-ledger.cost.to_numpy())*(1+ledger.gross_return.to_numpy())-1
            np.testing.assert_allclose(net, ledger.net_return, rtol=1e-11, atol=2e-15)
            np.testing.assert_allclose(np.cumprod(1+net), ledger.wealth, rtol=1e-11, atol=1e-13)
            trades = ledger[[f"trade_{asset}" for asset in assets]].to_numpy()
            target = ledger[[f"target_{asset}" for asset in assets]].to_numpy()
            pretrade = ledger[[f"pretrade_{asset}" for asset in assets]].to_numpy()
            np.testing.assert_allclose(trades, (1-ledger.cost.to_numpy()[:,None])*target-pretrade, rtol=1e-10, atol=2e-15)
            np.testing.assert_allclose(np.abs(trades) @ rates, ledger.cost, rtol=1e-10, atol=2e-15)
            np.testing.assert_allclose(np.abs(trades).sum(axis=1), ledger.turnover, rtol=1e-10, atol=2e-15)
            actual = summarize(ledger, config["portfolio"]["kappa"], config["portfolio"]["tail_probability"])
            archived = pd.read_csv(directory / "portfolio_summary.csv").set_index("model").loc[model]
            for key in ("J_daily_bp", "net_mean_daily_bp", "loss_es95_daily_bp", "total_cost_per_initial_wealth", "terminal_wealth"):
                np.testing.assert_allclose(actual[key], archived[key], rtol=1e-10, atol=1e-10)
            values[model] = actual["J_daily_bp"]
            if model in ("FULL", "A0", "M3", "M4"):
                scores = pd.read_csv(directory / f"{model}_scores.csv")
                np.testing.assert_array_equal(scores.target_date, reference)
                recomputed = fz_score(scores.equal_weight_gross_return.to_numpy(), scores.var05_return.to_numpy(), scores.es05_return.to_numpy(), .05)
                np.testing.assert_allclose(recomputed, scores.fz, rtol=1e-10, atol=1e-10)
            rows.append({"panel": panel, "model": model, "observations": len(ledger), "J_daily_bp": actual["J_daily_bp"], "accounting_and_dates": "passed"})
        for model in ("FULL", "A0"):
            np.testing.assert_allclose(values[model], primary.loc[panel, f"{model}_J_daily_bp"], atol=1e-10)
        np.testing.assert_allclose(values["FULL"]-values["A0"], primary.loc[panel, "delta_J_daily_bp"], atol=1e-10)
        original = np.load(folder / "graph/graphs.npz")
        aliases = pd.read_csv(folder / "ablations/summary.csv")
        for row in aliases.itertuples(index=False):
            alternative = np.load(folder / "ablations" / row.model / "graphs.npz")
            np.testing.assert_array_equal(alternative["adjacency"], original["adjacency"])
            np.testing.assert_array_equal(alternative["update_indices"], original["update_indices"])
            np.testing.assert_allclose(row.J_daily_bp, values["FULL"], atol=1e-10)
            alias_count += 1
    for filename, count in {"tableS1_sensitivity.csv":39, "tableS2_seed_stability.csv":10, "tableS2_seed_ranges.csv":2, "tableS3_development_2020.csv":7, "tableS4_development_candidates.csv":6}.items():
        assert len(pd.read_csv(ROOT / "outputs/manuscript_tables" / filename)) == count
    result = {"primary_ledgers": rows, "equivalent_graph_histories_checked": alias_count, "supplementary_table_row_counts": "passed"}
    (ROOT / "verification_results.json").write_text(json.dumps(result, indent=2)+"\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
