"""The shared 92-parameter FULL/A0 scale network and CPU Adam training."""
import numpy as np
from scipy.special import expit
from scripts.tail_distribution import nll_grad

def initialize(seed, initial_scale, initial_df=8.0):
    rng = np.random.default_rng(seed)
    theta = np.empty(92)
    theta[:64] = rng.uniform(-1 / np.sqrt(7), 1 / np.sqrt(7), 64)
    theta[64:90] = rng.uniform(-1 / np.sqrt(26), 1 / np.sqrt(26), 26)
    theta[90] = np.log(np.expm1(initial_scale))
    theta[91] = np.log((initial_df - 3) / (30 - initial_df))
    return theta

def forward(theta, standardized_features, raw_features, graphs, model):
    x = standardized_features
    hidden = np.tanh(x @ theta[:56].reshape(7, 8) + theta[56:64])
    if model == 'FULL':
        positive = np.maximum(graphs, 0)
        negative = np.maximum(-graphs, 0)
        strengths = np.stack((positive.sum(axis=2), negative.sum(axis=2)), axis=2)
        positive = positive / (strengths[:, :, 0, None] + 1e-08)
        negative = negative / (strengths[:, :, 1, None] + 1e-08)
        message_positive = positive @ hidden
        message_negative = negative @ hidden
    else:
        message_positive = np.tanh(hidden)
        message_negative = hidden ** 2
        strengths = raw_features[:, :, [3, 6]]
        positive = negative = None
    context = np.concatenate((hidden, message_positive, message_negative, strengths), axis=2)
    logits = context @ theta[64:90] + theta[90]
    scale = np.logaddexp(0, logits) + 1e-08
    df_fraction = expit(theta[91])
    df = 3 + 27 * df_fraction
    cache = (hidden, context, logits, positive, negative, message_positive, df_fraction)
    return (scale, df, cache)

def loss_gradient(theta, standardized_features, raw_features, graphs, loc, labels, model):
    scale, df, cache = forward(theta, standardized_features, raw_features, graphs, model)
    losses, dscale, ddf = nll_grad(labels, loc, scale, df)
    hidden, context, logits, positive, negative, message_positive, df_fraction = cache
    dlogits = dscale * expit(logits) / labels.size
    gradient = np.zeros(92)
    gradient[64:90] = np.einsum('bnc,bn->c', context, dlogits)
    gradient[90] = dlogits.sum()
    gradient[91] = ddf.mean() * 27 * df_fraction * (1 - df_fraction)
    dcontext = dlogits[:, :, None] * theta[None, None, 64:90]
    dhidden = dcontext[:, :, :8].copy()
    if model == 'FULL':
        dhidden += np.swapaxes(positive, 1, 2) @ dcontext[:, :, 8:16]
        dhidden += np.swapaxes(negative, 1, 2) @ dcontext[:, :, 16:24]
    else:
        dhidden += (1 - message_positive ** 2) * dcontext[:, :, 8:16]
        dhidden += 2 * hidden * dcontext[:, :, 16:24]
    dencoded = dhidden * (1 - hidden ** 2)
    gradient[:56] = np.einsum('bnf,bnh->fh', standardized_features, dencoded).ravel()
    gradient[56:64] = dencoded.sum(axis=(0, 1))
    return (float(losses.mean()), gradient)

def train(features, graphs, loc, labels, model, config, seed):
    """A batch contains dates and all assets; standardization uses training rows."""
    mean = features.mean(axis=(0, 1))
    spread = np.maximum(features.std(axis=(0, 1)), 1e-08)
    standardized = (features - mean) / spread
    initial_scale = max(float(np.std(labels - loc)) * np.sqrt(6 / 8), 1e-08)
    theta = initialize(seed, initial_scale)
    first_moment = np.zeros(92)
    second_moment = np.zeros(92)
    rng = np.random.default_rng(seed)
    step = 0
    for epoch in range(config['epochs']):
        order = rng.permutation(len(features))
        for offset in range(0, len(order), config['batch_size']):
            batch = order[offset:offset + config['batch_size']]
            _, gradient = loss_gradient(theta, standardized[batch], features[batch], graphs[batch], loc[batch], labels[batch], model)
            norm = np.linalg.norm(gradient)
            if norm > config['gradient_clip_norm']:
                gradient *= config['gradient_clip_norm'] / norm
            gradient += config['weight_decay'] * theta
            step += 1
            first_moment = 0.9 * first_moment + 0.1 * gradient
            second_moment = 0.999 * second_moment + 0.001 * gradient ** 2
            corrected_m = first_moment / (1 - 0.9 ** step)
            corrected_v = second_moment / (1 - 0.999 ** step)
            theta -= config['learning_rate'] * corrected_m / (np.sqrt(corrected_v) + 1e-08)
    final_loss, _ = loss_gradient(theta, standardized, features, graphs, loc, labels, model)
    return {'theta': theta, 'feature_mean': mean, 'feature_scale': spread, 'training_nll': final_loss, 'training_samples': len(features), 'optimizer_steps': step}

def predict(fitted, features, graphs, model):
    raw = np.asarray(features)
    scale, df, _ = forward(fitted['theta'], (raw - fitted['feature_mean']) / fitted['feature_scale'], raw, graphs, model)
    return (scale, df)
