"""Score M3's existing empirical joint distribution on development dates."""
import json
from pathlib import Path
import pandas as pd
from scripts.joint_risk import equal_weight_var_es, fz_score
from scripts.run_graph_development import load_development
ROOT = Path(__file__).resolve().parents[1]

def main():
    config = json.loads((ROOT / 'configs/protocol.json').read_text(encoding='utf-8'))
    dates, returns, _, _, _ = load_development(config)
    directory = ROOT / 'outputs/development'
    ledger = pd.read_csv(directory / 'M3_ledger.csv', parse_dates=['signal_date', 'target_date'])
    window = config['portfolio']['m3_history_window']
    alpha = config['portfolio']['tail_probability']
    rows = []
    for record in ledger.itertuples():
        signal = dates.get_loc(record.signal_date)
        scenarios = returns.iloc[signal - window + 1:signal + 1].to_numpy()
        q, es = equal_weight_var_es(scenarios, alpha)
        y = float(returns.loc[record.target_date].mean())
        rows.append({'signal_date': record.signal_date, 'target_date': record.target_date, 'last_scenario_date': dates[signal], 'historical_scenarios': len(scenarios), 'equal_weight_gross_return': y, 'var05_return': q, 'es05_return': es, 'fz': float(fz_score(y, q, es, alpha)), 'var_breach': int(y <= q)})
    scores = pd.DataFrame(rows)
    scores.to_csv(directory / 'M3_scores.csv', index=False)
    summary = {'model': 'M3', 'observations': len(scores), 'mean_fz': scores.fz.mean(), 'var_coverage': scores.var_breach.mean()}
    pd.DataFrame([summary]).to_csv(directory / 'M3_prediction_summary.csv', index=False)
    print(f"M3: {len(scores)} development targets, mean FZ={summary['mean_fz']:.8f}")
if __name__ == '__main__':
    main()
