"""Report frozen confirmation results, preserving paired dates and source aliases."""
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scripts.baselines import summarize
from scripts.calibration import joint_unconditional_calibration, var_coverage_independence
from scripts.statistical_inference import holm_adjust, paired_j_bootstrap, paired_mean_bootstrap
ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / 'outputs/confirmation'
PANELS = ('repod', 'japan')

def bootstrap_options(config):
    return {'repetitions': config['inference']['bootstrap_repetitions'], 'block_length': config['inference']['block_length'], 'seed': config['seed']}

def read_records(directory, model, kind, reference_dates=None):
    path = directory / f'{model}_{kind}.csv'
    frame = pd.read_csv(path, parse_dates=['signal_date', 'target_date'])
    frame = frame.sort_values('target_date').reset_index(drop=True)
    if frame.target_date.duplicated().any():
        raise ValueError(f'Repeated target dates prevent paired comparison: {path}')
    if reference_dates is not None and (not frame.target_date.equals(reference_dates)):
        raise ValueError(f'Target dates differ from the common comparison sample: {path}')
    return frame

def primary_comparison(config):
    rows = []
    kappa = config['portfolio']['kappa']
    alpha = config['portfolio']['tail_probability']
    options = bootstrap_options(config)
    for panel in PANELS:
        directory = OUTPUT / panel / 'graph'
        full = read_records(directory, 'FULL', 'ledger')
        reference_dates = full.target_date
        a0 = read_records(directory, 'A0', 'ledger', reference_dates)
        full_scores = read_records(directory, 'FULL', 'scores', reference_dates)
        a0_scores = read_records(directory, 'A0', 'scores', reference_dates)
        returns = np.column_stack((full.net_return, a0.net_return))
        result = paired_j_bootstrap(returns, [(0, 1)], alpha=alpha, kappa=kappa, **options)
        mean_result = paired_mean_bootstrap(returns, [(0, 1)], **options)
        es_draws = (mean_result['bootstrap_differences'] - result['bootstrap_differences']) / kappa
        es_interval = np.quantile(es_draws[:, 0], [0.025, 0.975])
        rows.append({'panel': panel, 'comparison': 'FULL-A0', 'observations': len(full), 'first_signal': str(full.signal_date.iloc[0].date()), 'first_target': str(reference_dates.iloc[0].date()), 'last_target': str(reference_dates.iloc[-1].date()), 'nominal_test_start': config['panels'][panel]['test_start'], 'FULL_J_daily_bp': 10000 * result['J'][0], 'A0_J_daily_bp': 10000 * result['J'][1], 'delta_J_daily_bp': 10000 * result['point_difference'][0], 'delta_J_ci95_lower_bp': 10000 * result['ci_lower'][0], 'delta_J_ci95_upper_bp': 10000 * result['ci_upper'][0], 'p_raw': result['p_value'][0], 'delta_mean_net_daily_bp': 10000 * result['mean_difference'][0], 'delta_mean_ci95_lower_bp': 10000 * mean_result['ci_lower'][0], 'delta_mean_ci95_upper_bp': 10000 * mean_result['ci_upper'][0], 'delta_loss_ES95_daily_bp': 10000 * result['loss_es_difference'][0], 'delta_ES_ci95_lower_bp': 10000 * es_interval[0], 'delta_ES_ci95_upper_bp': 10000 * es_interval[1], 'ES_contribution_to_delta_J_bp': 10000 * result['es_contribution'][0], 'FULL_mean_FZ': full_scores.fz.mean(), 'A0_mean_FZ': a0_scores.fz.mean(), 'delta_mean_FZ_descriptive': full_scores.fz.mean() - a0_scores.fz.mean(), 'mean_graph_edges': full_scores.graph_edges.mean(), 'graph_nonempty_signal_fraction': full_scores.graph_edges.gt(0).mean(), 'min_graph_edges': full_scores.graph_edges.min(), 'max_graph_edges': full_scores.graph_edges.max()})
    table = pd.DataFrame(rows)
    table['p_holm_two_panels'] = holm_adjust(table.p_raw.to_numpy())
    table['supports_panel_improvement'] = table.delta_J_daily_bp.gt(0) & table.p_holm_two_panels.lt(0.05)
    table.to_csv(OUTPUT / 'primary_comparison.csv', index=False)
    return table

def model_sources(panel_directory):
    sources = {}
    for model in ['FULL', 'A0', 'M0', 'M1', 'M2', 'M3', 'M4']:
        folder = 'graph' if model in ['FULL', 'A0'] else 'm4' if model == 'M4' else 'baselines'
        sources[model] = {'source_model': model, 'source_directory': (panel_directory / folder).resolve(), 'separate_run': True, 'variant': ''}
    ablations = pd.read_csv(panel_directory / 'ablations/summary.csv')
    for row in ablations.itertuples(index=False):
        sources[row.model] = {'source_model': row.source_model, 'source_directory': Path(row.source_directory).resolve(), 'separate_run': bool(row.separate_run), 'variant': row.variant}
    for source in sources.values():
        source['key'] = (source['source_directory'].relative_to(ROOT).as_posix(), source['source_model'])
    return sources

def provenance(model, source, full_key):
    return {'model': model, 'variant': source['variant'], 'source_model': source['source_model'], 'source_directory': source['source_directory'].relative_to(ROOT).as_posix(), 'separate_run': source['separate_run'], 'same_as_FULL_source': source['key'] == full_key}

def adjust_source_family(table, p_column, adjusted_column, exclude_full=False):
    """One hypothesis per actual source; exact self-comparisons have p=1."""
    included = ~table.same_as_FULL_source if exclude_full else pd.Series(True, index=table.index)
    representatives = table.loc[included].drop_duplicates(['source_directory', 'source_model'])
    adjusted = holm_adjust(representatives[p_column].to_numpy())
    mapping = {(row.source_directory, row.source_model): value for row, value in zip(representatives.itertuples(index=False), adjusted)}
    table[adjusted_column] = [mapping[row.source_directory, row.source_model] if member else 1.0 for row, member in zip(table.itertuples(index=False), included)]
    table['in_Holm_family'] = included.to_numpy()
    table['distinct_hypotheses_in_family'] = len(representatives)
    return table

def full_panel_report(config, panel):
    directory = OUTPUT / panel
    sources = model_sources(directory)
    full_key = sources['FULL']['key']
    unique_keys = list(dict.fromkeys((source['key'] for source in sources.values())))
    reference = read_records(directory / 'graph', 'FULL', 'ledger')
    ledgers = {key: read_records(Path(key[0]), key[1], 'ledger', reference.target_date) for key in unique_keys}
    scored_models = [model for model in sources if model not in ['M0', 'M1', 'M2']]
    scored_keys = list(dict.fromkeys((sources[model]['key'] for model in scored_models)))
    scores = {key: read_records(Path(key[0]), key[1], 'scores', reference.target_date) for key in scored_keys}
    alpha, kappa = (config['portfolio']['tail_probability'], config['portfolio']['kappa'])
    options = bootstrap_options(config)
    strategy_rows = []
    for model, source in sources.items():
        key = source['key']
        row = summarize(ledgers[key], kappa, alpha)
        row.update(provenance(model, source, full_key))
        row['mean_FZ'] = scores[key].fz.mean() if model in scored_models else np.nan
        row['VaR_breach_fraction'] = scores[key].var_breach.mean() if model in scored_models else np.nan
        strategy_rows.append(row)
    strategies = pd.DataFrame(strategy_rows)
    strategies.to_csv(directory / 'strategy_summary.csv', index=False)
    variant_models = [model for model in sources if sources[model]['variant']]
    decision_models = ['M0', 'M1', 'M2', 'M3', 'M4', *variant_models]
    returns = np.column_stack([ledgers[key].net_return for key in unique_keys])
    pairs = [(unique_keys.index(full_key), unique_keys.index(sources[model]['key'])) for model in decision_models]
    decision = paired_j_bootstrap(returns, pairs, alpha=alpha, kappa=kappa, **options)
    decision_rows = []
    for index, model in enumerate(decision_models):
        row = provenance(model, sources[model], full_key)
        row.update({'comparison': f'FULL-{model}', 'observations': len(reference), 'delta_J_daily_bp': 10000 * decision['point_difference'][index], 'delta_J_ci95_lower_bp': 10000 * decision['ci_lower'][index], 'delta_J_ci95_upper_bp': 10000 * decision['ci_upper'][index], 'delta_mean_net_daily_bp': 10000 * decision['mean_difference'][index], 'delta_loss_ES95_daily_bp': 10000 * decision['loss_es_difference'][index], 'p_raw': decision['p_value'][index]})
        decision_rows.append(row)
    decisions = adjust_source_family(pd.DataFrame(decision_rows), 'p_raw', 'p_holm_decision', exclude_full=True)
    decisions.to_csv(directory / 'decision_secondary.csv', index=False)
    fz_models = ['A0', 'M3', 'M4', *variant_models]
    fz_values = np.column_stack([scores[key].fz for key in scored_keys])
    pairs = [(scored_keys.index(full_key), scored_keys.index(sources[model]['key'])) for model in fz_models]
    fz_result = paired_mean_bootstrap(fz_values, pairs, **options)
    fz_rows = []
    for index, model in enumerate(fz_models):
        row = provenance(model, sources[model], full_key)
        row.update({'comparison': f'FULL-{model}', 'observations': len(reference), 'delta_mean_FZ': fz_result['point_difference'][index], 'delta_FZ_ci95_lower': fz_result['ci_lower'][index], 'delta_FZ_ci95_upper': fz_result['ci_upper'][index], 'p_raw': fz_result['p_value'][index]})
        fz_rows.append(row)
    fz = adjust_source_family(pd.DataFrame(fz_rows), 'p_raw', 'p_holm_FZ', exclude_full=True)
    fz.to_csv(directory / 'FZ_comparison.csv', index=False)
    calibration_cache = {}
    for key in scored_keys:
        frame = scores[key]
        y, q, e = (frame.equal_weight_gross_return, frame.var05_return, frame.es05_return)
        var = var_coverage_independence(y, q, alpha)
        joint = joint_unconditional_calibration(y, q, e, alpha=alpha, **options)
        calibration_cache[key] = {'observations': len(frame), 'hit_count': var['hit_count'], 'hit_rate': var['hit_rate'], 'lr_uc': var['lr_uc'], 'p_uc_raw': var['p_uc'], 'lr_ind': var['lr_ind'], 'p_ind_raw': var['p_ind'], 'n00': var['transitions'][0, 0], 'n01': var['transitions'][0, 1], 'n10': var['transitions'][1, 0], 'n11': var['transitions'][1, 1], 'mean_hit_moment': joint['mean_moments'][0], 'mean_ES_moment_percentage_points': joint['mean_moments'][1], 'bootstrap_mean_cov11': joint['bootstrap_mean_covariance'][0, 0], 'bootstrap_mean_cov12': joint['bootstrap_mean_covariance'][0, 1], 'bootstrap_mean_cov22': joint['bootstrap_mean_covariance'][1, 1], 'joint_W': joint['statistic'], 'p_joint_raw': joint['p_value']}
    calibration = pd.DataFrame([{**provenance(model, sources[model], full_key), **calibration_cache[sources[model]['key']]} for model in scored_models])
    calibration = adjust_source_family(calibration, 'p_joint_raw', 'p_joint_holm')
    calibration.to_csv(directory / 'calibration.csv', index=False)
    return {'strategies': strategies, 'decisions': decisions, 'FZ': fz, 'calibration': calibration}

def write_report(config, primary, panel_results, stage):
    confirmation = config['confirmation']
    supports_overall = bool(primary.supports_panel_improvement.all())
    overall = '两个面板均得到正的 FULL−A0 ΔJ，且两项主要检验经 Holm 校正均小于 0.05；结果支持预设的跨面板总体决策改善结论。' if supports_overall else '结果未同时满足两个面板 ΔJ 均为正且两项主要检验经 Holm 校正均小于 0.05；本次实验不支持预设的跨面板总体决策改善结论。'
    lines = ['冻结配置下的历史确认实验报告', '', overall, '', f"实际配置冻结时间（UTC）：{confirmation['frozen_at_utc']}。允许用于开发选择的历史信息截止：{confirmation['selection_information_cutoff']}。", '冻结时间是本项目实际执行时间，历史截止则规定选参允许使用的信息范围；二者不能混作在 2020 年已经完成的前瞻预注册。', f"确认信号不得早于 {confirmation['first_signal_not_before']}，再按信号、下一观测期执行、再下一观测期收益的时序开始评价；实际确认起点晚于名义 2021 年初。", '', '主要比较：全部差值均为 FULL 减 A0；J、净收益及损失 ES 的单位为每日基点。ES 差为负表示 FULL 的尾部损失更低。', primary[['panel', 'observations', 'first_target', 'last_target', 'delta_J_daily_bp', 'delta_J_ci95_lower_bp', 'delta_J_ci95_upper_bp', 'p_raw', 'p_holm_two_panels', 'delta_mean_net_daily_bp', 'delta_loss_ES95_daily_bp', 'delta_mean_FZ_descriptive']].to_string(index=False, float_format=lambda x: f'{x:.6f}'), '']
    for row in primary.itertuples(index=False):
        lines.append(f'{row.panel}：首个信号为 {row.first_signal}，共同目标期为 {row.first_target} 至 {row.last_target}，共 {row.observations} 期；名义测试起点为 {row.nominal_test_start}。ΔJ={row.delta_J_daily_bp:+.6f}，95% 区间 [{row.delta_J_ci95_lower_bp:.6f}, {row.delta_J_ci95_upper_bp:.6f}]，Holm p={row.p_holm_two_panels:.6f}。')
        lines.append(f'收益分量 Δ均值={row.delta_mean_net_daily_bp:+.6f}，95% 区间 [{row.delta_mean_ci95_lower_bp:.6f}, {row.delta_mean_ci95_upper_bp:.6f}]；尾部损失分量 ΔES={row.delta_loss_ES95_daily_bp:+.6f}，95% 区间 [{row.delta_ES_ci95_lower_bp:.6f}, {row.delta_ES_ci95_upper_bp:.6f}]。−κΔES 对 ΔJ 的贡献为 {row.ES_contribution_to_delta_J_bp:+.6f}。')
        if row.max_graph_edges == 0:
            lines.append(f'{row.panel} 实际评价信号日的图全部为空图；该面板 FULL 与 A0 的差异不能归因于跨资产图消息。FULL 与 A0 均有 92 个名义参数，但空图使 FULL 的两个 8 维消息块及两项入边强度共 18 维图输入恒为零；A0 对应输入仍包含本节点的无参数变换及自身状态。因此，名义参数数相同不表示有效容量完全相同，两者的表现差异不能解释为跨资产边的贡献。')
        else:
            lines.append(f'{row.panel} 实际评价信号日中 {row.graph_nonempty_signal_fraction:.2%} 使用非空图，平均 {row.mean_graph_edges:.4f} 条边、范围 [{row.min_graph_edges}, {row.max_graph_edges}]；机制判断结合下列既定消融。')
        lines.append('')
    if stage == 'full':
        for panel, result in panel_results.items():
            strategies, decisions, fz, calibration = (result[key] for key in ['strategies', 'decisions', 'FZ', 'calibration'])
            lines.extend([f'{panel} 全部策略与消融', strategies[['model', 'net_mean_daily_bp', 'loss_es95_daily_bp', 'J_daily_bp', 'mean_FZ', 'separate_run', 'source_model']].to_string(index=False, float_format=lambda x: f'{x:.6f}', na_rep='—'), '', f'次要决策族包含 {int(decisions.distinct_hypotheses_in_family.iloc[0])} 个不同结果来源的比较；FZ 族包含 {int(fz.distinct_hypotheses_in_family.iloc[0])} 个；联合校准族包含 {int(calibration.distinct_hypotheses_in_family.iloc[0])} 个。三族在本面板内分别作 Holm 校正，主要 FULL−A0 决策检验不混入次要族。', '次要决策差值为 FULL 减对照，正值有利于 FULL；FZ 差值同方向、负值有利于 FULL。', decisions[['comparison', 'delta_J_daily_bp', 'delta_J_ci95_lower_bp', 'delta_J_ci95_upper_bp', 'p_holm_decision', 'source_model', 'in_Holm_family']].to_string(index=False, float_format=lambda x: f'{x:.6f}'), fz[['comparison', 'delta_mean_FZ', 'delta_FZ_ci95_lower', 'delta_FZ_ci95_upper', 'p_holm_FZ']].to_string(index=False, float_format=lambda x: f'{x:.6f}'), ''])
            a4 = strategies.loc[strategies.variant == 'A4']
            distinct_a4 = a4.drop_duplicates(['source_directory', 'source_model'])
            lines.append(f'A4 共保留 {len(a4)} 个非恒等节点置换标签，对应 {len(distinct_a4)} 个实际结果来源；J 范围 [{a4.J_daily_bp.min():.6f}, {a4.J_daily_bp.max():.6f}]，FZ 范围 [{a4.mean_FZ.min():.8f}, {a4.mean_FZ.max():.8f}]。separate_run=False 的标签引用完全相同历史图输入的既有预测与交易记录，不构成额外独立实验。等价标签共用一个次要假设与校准结果；与 FULL 相同来源的比较效应精确为零、p=1，不进入次要 Holm 族。')
            lines.extend(['校准诊断（覆盖与独立性为未校正 LR p；联合校准单独按不同来源作 Holm）：', calibration[['model', 'hit_rate', 'p_uc_raw', 'p_ind_raw', 'mean_hit_moment', 'mean_ES_moment_percentage_points', 'joint_W', 'p_joint_holm']].to_string(index=False, float_format=lambda x: f'{x:.6f}'), ''])
    else:
        lines.extend(['本报告当前只汇总两个面板的 FULL/A0 主要比较。FZ 差为描述性结果；基线、消融、预测比较与校准在 --stage full 中独立汇总。', ''])
    options = bootstrap_options(config)
    lines.extend(['统计与来源', f"配对平稳区块 bootstrap 共 {options['repetitions']} 次，平均区块长度 {options['block_length']}，种子 {options['seed']}。", '完整日期行同步抽取所有策略，逐次重新计算 J 的均值及精确分数尾质量 ES。95% 区间为未校正 percentile 区间；双侧 p=(1+#{|Δ*−Δhat|≥|Δhat|})/(B+1)。主要结论仅按两个面板的 FULL−A0 p 作 Holm 判断。', 'FZ 采用共同等权毛收益参考组合。联合校准使用 I−α 与 e−q+I(q−y)/α，收益转换为百分点；以 bootstrap 均值协方差构造 W，使用同一协方差及以观测均值为中心的 bootstrap W* 计算 p。这是本研究指定的 bootstrap 无条件联合校准方案，不将其称为某篇原论文已命名的具体检验。', f"冻结配置：{(ROOT / 'configs/frozen_protocol.json').relative_to(ROOT).as_posix()}", f'逐日数据来源：{OUTPUT.relative_to(ROOT).as_posix()}/各面板/graph、baselines、m4；消融来源映射见各面板/ablations/summary.csv。', '所有比较使用完全一致的 target_date 序列；脚本发现日期缺失或不一致时直接报错，不通过删行改变比较样本。', '', '复现命令（工作目录 .）：', 'python run.py -m scripts.run_confirmation --panel repod --stage all', 'python run.py -m scripts.run_confirmation --panel japan --stage all', f'python run.py -m scripts.report_confirmation --stage {stage}', '', '方法来源：', 'Politis & Romano (1994), The Stationary Bootstrap. https://doi.org/10.1080/01621459.1994.10476870', 'Holm (1979), A Simple Sequentially Rejective Multiple Test Procedure. https://doi.org/10.2307/4615733', 'Kupiec (1995), Techniques for Verifying the Accuracy of Risk Measurement Models. https://fedinprint.org/item/fedgfe/34596/original', 'Christoffersen (1998), Evaluating Interval Forecasts. https://users.ssc.wisc.edu/~bhansen/718/Christoffersen1998.pdf', "Fissler & Ziegel (2016), Higher order elicitability and Osband's principle. https://doi.org/10.1214/16-AOS1439"])
    (OUTPUT / 'report.txt').write_text('\n'.join(lines) + '\n', encoding='utf-8')

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--stage', choices=['primary', 'full'], default='primary')
    args = parser.parse_args()
    config = json.loads((ROOT / 'configs/frozen_protocol.json').read_text(encoding='utf-8'))
    if not config['confirmation_frozen']:
        raise ValueError('Confirmation reporting requires the frozen protocol.')
    primary = primary_comparison(config)
    panel_results = {panel: full_panel_report(config, panel) for panel in PANELS} if args.stage == 'full' else {}
    write_report(config, primary, panel_results, args.stage)
    print(primary[['panel', 'observations', 'delta_J_daily_bp', 'p_holm_two_panels']].to_string(index=False))
if __name__ == '__main__':
    main()
