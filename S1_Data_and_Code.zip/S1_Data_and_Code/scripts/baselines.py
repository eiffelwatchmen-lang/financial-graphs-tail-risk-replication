"""Daily allocation baselines with a signal / execution / return lag of 0 / 1 / 2."""
import numpy as np
import pandas as pd
from scipy.optimize import brentq, linprog, minimize

def tail_es(losses, alpha=0.05):
    """Empirical upper-tail ES with exactly alpha of the empirical probability."""
    ordered = np.sort(np.asarray(losses, dtype=float))[::-1]
    mass = alpha * len(ordered)
    whole = int(np.floor(mass))
    fraction = mass - whole
    total = ordered[:whole].sum()
    if fraction > 0:
        total += fraction * ordered[whole]
    return float(total / mass)

def self_financing_cost(previous, target, rates):
    """Cost as a fraction of pretrade wealth; zero asset holdings mean cash."""
    previous = np.asarray(previous, dtype=float)
    target = np.asarray(target, dtype=float)
    rates = np.asarray(rates, dtype=float)
    return brentq(lambda cost: cost - rates @ np.abs((1 - cost) * target - previous), 0.0, 1.0, xtol=1e-14)

def capped_inverse_vol(window, cap=0.6):
    inverse_vol = 1 / np.asarray(window, dtype=float).std(axis=0, ddof=1)
    weights = np.zeros(len(inverse_vol))
    free = np.ones(len(inverse_vol), dtype=bool)
    budget = 1.0
    while free.any():
        indices = np.flatnonzero(free)
        proposed = budget * inverse_vol[free] / inverse_vol[free].sum()
        capped = proposed > cap
        if not capped.any():
            weights[indices] = proposed
            break
        weights[indices[capped]] = cap
        free[indices[capped]] = False
        budget -= cap * capped.sum()
    return weights

def minimum_variance(window, cap=0.6, shrink=0.2):
    covariance = np.cov(np.asarray(window, dtype=float), rowvar=False, ddof=1)
    covariance = (1 - shrink) * covariance + shrink * np.diag(np.diag(covariance))
    count = len(covariance)
    result = minimize(lambda weights: weights @ covariance @ weights, np.full(count, 1 / count), jac=lambda weights: 2 * covariance @ weights, method='SLSQP', bounds=[(0, cap)] * count, constraints={'type': 'eq', 'fun': lambda weights: weights.sum() - 1, 'jac': lambda weights: np.ones(count)}, options={'ftol': 1e-12, 'maxiter': 200})
    if not result.success:
        raise RuntimeError(f'Minimum-variance optimization failed: {result.message}')
    return result.x

def historical_cvar(window, mu, previous, rates, alpha=0.05, kappa=0.05, cap=0.6):
    """Mean-CVaR LP using additive estimated costs at the signal date."""
    scenarios = np.asarray(window, dtype=float)
    mu = np.asarray(mu, dtype=float)
    previous = np.asarray(previous, dtype=float)
    rates = np.asarray(rates, dtype=float)
    sample_count, asset_count = scenarios.shape
    variable_count = 2 * asset_count + sample_count + 1
    tail_start = asset_count + 1
    turnover_start = tail_start + sample_count
    objective = np.zeros(variable_count)
    objective[:asset_count] = -mu
    objective[asset_count] = kappa
    objective[tail_start:turnover_start] = kappa / (alpha * sample_count)
    objective[turnover_start:] = (1 + kappa) * rates
    inequality = np.zeros((sample_count + 2 * asset_count, variable_count))
    inequality[:sample_count, :asset_count] = -scenarios
    inequality[:sample_count, asset_count] = -1
    inequality[:sample_count, tail_start:turnover_start] = -np.eye(sample_count)
    for asset in range(asset_count):
        buy_row = sample_count + asset
        sell_row = sample_count + asset_count + asset
        inequality[buy_row, asset] = 1
        inequality[sell_row, asset] = -1
        inequality[buy_row, turnover_start + asset] = -1
        inequality[sell_row, turnover_start + asset] = -1
    rhs = np.concatenate((np.zeros(sample_count), previous, -previous))
    equality = np.zeros((1, variable_count))
    equality[0, :asset_count] = 1
    result = linprog(objective, A_ub=inequality, b_ub=rhs, A_eq=equality, b_eq=[1.0], bounds=[(0, cap)] * asset_count + [(None, None)] + [(0, None)] * (sample_count + asset_count), method='highs')
    if not result.success:
        raise RuntimeError(f'Historical-CVaR optimization failed: {result.message}')
    return result.x[:asset_count]

def backtest(returns, model, start, end, *, rates, cap=0.6, alpha=0.05, kappa=0.05, shrink=0.2, strategy=None, execution_lag=1, trading_frequency='daily', initial_target=None):
    """Return one record per target day in [start, end].

    At each close: receive returns and drift holdings, execute the due signal,
    then form a new signal using the now-known posttrade holdings. An execution
    cost belongs to the immediately following holding-period return. The first
    execution buys equal weights from cash for every strategy. Wealth records
    are measured immediately before each target day's new execution.

    A supplied strategy receives (signal day index, known post-execution
    weights); its caller ensures predictions are available for the chosen dates.
    Orders execute after execution_lag observed dates, and their first return
    follows one date later. Pending orders are not treated as held positions.
    Weekly signals use the first observed date of each ISO week, following the
    initial cash purchase. Non-execution days retain daily returns and drift.
    initial_target optionally replaces the first equal-weight cash purchase.
    """
    history_required = 1 if strategy is not None else {'M0': 1, 'M1': 20, 'M2': 504, 'M3': 504}[model]
    dates = returns.index
    values = returns.to_numpy(dtype=float)
    rates = np.asarray(rates, dtype=float)
    assets = list(returns.columns)
    asset_count = len(assets)
    selected = np.flatnonzero((dates >= pd.Timestamp(start)) & (dates <= pd.Timestamp(end)))
    first_target, last_target = (int(selected[0]), int(selected[-1]))
    target_lag = execution_lag + 1
    first_signal = first_target - target_lag
    if first_signal < history_required - 1:
        raise ValueError(f'{model} needs {history_required} returns before the first signal')
    weights = np.zeros(asset_count)
    pending = {}
    active = None
    wealth = 1.0
    records = []
    for day in range(first_signal, last_target + 1):
        gross_return = float(weights @ values[day])
        pretrade = weights * (1 + values[day]) / (1 + gross_return)
        if active is not None:
            net_return = (1 - active['cost']) * (1 + gross_return) - 1
            wealth *= 1 + net_return
            active.update(gross_return=gross_return, net_return=net_return, wealth=wealth)
            records.append(active)
            active = None
        if day in pending:
            order = pending.pop(day)
            target = order['weights']
            cost = self_financing_cost(pretrade, target, rates)
            amounts = (1 - cost) * target - pretrade
            active = {'model': model, 'signal_date': order['signal_date'], 'execution_date': dates[day], 'target_date': dates[day + 1], 'cost': cost, 'turnover': float(np.abs(amounts).sum())}
            for asset, name in enumerate(assets):
                active[f'signal_{name}'] = order['signal_weights'][asset]
                active[f'pretrade_{name}'] = pretrade[asset]
                active[f'target_{name}'] = target[asset]
                active[f'trade_{name}'] = amounts[asset]
            if trading_frequency == 'weekly':
                active['trade_executed'] = True
                last_execution_date = dates[day]
            weights = target.copy()
        else:
            weights = pretrade
            if trading_frequency == 'weekly' and first_target <= day + 1 <= last_target:
                active = {'model': model, 'signal_date': order['signal_date'], 'execution_date': last_execution_date, 'target_date': dates[day + 1], 'cost': 0.0, 'turnover': 0.0}
                for asset, name in enumerate(assets):
                    active[f'signal_{name}'] = order['signal_weights'][asset]
                    active[f'pretrade_{name}'] = weights[asset]
                    active[f'target_{name}'] = weights[asset]
                    active[f'trade_{name}'] = 0.0
                active['trade_executed'] = False
        signal_due = trading_frequency == 'daily' or day == first_signal or dates[day].isocalendar()[:2] != dates[day - 1].isocalendar()[:2]
        if day <= last_target - target_lag and signal_due:
            if day == first_signal:
                target = np.full(asset_count, 1 / asset_count) if initial_target is None else np.asarray(initial_target, dtype=float)
            elif model == 'M0':
                target = np.full(asset_count, 1 / asset_count)
            elif strategy is not None:
                target = strategy(day, weights)
            elif model == 'M1':
                target = capped_inverse_vol(values[day - 19:day + 1], cap)
            elif model == 'M2':
                target = minimum_variance(values[day - 503:day + 1], cap, shrink)
            else:
                mu = 0.25 * values[day - 251:day + 1].mean(axis=0)
                target = historical_cvar(values[day - 503:day + 1], mu, weights, rates, alpha, kappa, cap)
            pending[day + execution_lag] = {'signal_date': dates[day], 'signal_weights': weights.copy(), 'weights': target}
    return pd.DataFrame.from_records(records)

def summarize(records, kappa, alpha):
    net = records.net_return.to_numpy()
    wealth = records.wealth.to_numpy()
    path = np.r_[1.0, wealth]
    es = tail_es(-net, alpha)
    return {'model': records.model.iloc[0], 'first_target': str(records.target_date.iloc[0].date()), 'last_target': str(records.target_date.iloc[-1].date()), 'observations': len(net), 'net_mean_daily_bp': 10000 * net.mean(), 'loss_es95_daily_bp': 10000 * es, 'J_daily_bp': 10000 * (net.mean() - kappa * es), 'net_cagr_252': wealth[-1] ** (252 / len(net)) - 1, 'net_volatility_annual_252': net.std(ddof=1) * np.sqrt(252), 'max_drawdown': np.min(path / np.maximum.accumulate(path) - 1), 'mean_traded_fraction': records.turnover.mean(), 'sum_cost_fractions': records.cost.sum(), 'total_cost_per_initial_wealth': float(records.cost @ np.r_[1.0, wealth[:-1]]), 'terminal_wealth': wealth[-1]}
