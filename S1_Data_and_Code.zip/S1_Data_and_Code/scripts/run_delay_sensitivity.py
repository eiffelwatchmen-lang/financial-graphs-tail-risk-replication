"""Replay FULL/A0 for the original protocol's one-extra-period execution delay."""
import argparse
import json
from pathlib import Path
from scripts.run_graph_development import build_graphs, replay_forecasts, run_portfolios, score_forecasts
ROOT = Path(__file__).resolve().parents[1]
FROZEN_PROTOCOL = ROOT / 'configs/frozen_protocol.json'
OUTPUT = ROOT / 'outputs/confirmation/delay_sensitivity'

def delay_config():
    """Create an in-memory timing branch; the frozen source file is untouched."""
    config = json.loads(FROZEN_PROTOCOL.read_text(encoding='utf-8'))
    config['stage'] = 'additional_execution_delay_sensitivity'
    config['timing']['execution_lag'] = 2
    config['timing']['target_lag'] = 3
    config['graph']['target'] = '-return_at_s_plus_3 / vol_60_at_s'
    config['confirmation']['expected_first_targets'] = {'repod': '2021-01-06', 'japan': '2021-01-07'}
    config['confirmation']['expected_observations'] = {'repod': 875, 'japan': 1220}
    return config

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--panel', choices=['repod', 'japan'], required=True)
    parser.add_argument('--stage', choices=['graphs', 'forecasts', 'scores', 'portfolios', 'all'], default='all')
    args = parser.parse_args()
    config = delay_config()
    directory = OUTPUT / args.panel
    directory.mkdir(parents=True, exist_ok=True)
    graph_directory = directory / 'graph'
    branch_settings = {'branch': 'original_protocol_additional_one_observed_period_execution_delay', 'panel': args.panel, 'frozen_protocol_source': FROZEN_PROTOCOL.relative_to(ROOT).as_posix(), 'original_timing': {'execution_lag': 1, 'target_lag': 2}, 'branch_timing': {'execution_lag': 2, 'target_lag': 3}, 'models': ['FULL', 'A0'], 'hyperparameter_reselection': False, 'replay_rule': 'Refit graphs and marginal forecasts from historical start with s+3 labels; rebuild mature PIT history before joint scenarios and allocation.', 'lag2_forecasts_or_PIT_reused': False, 'freeze_timestamp_provenance': 'Inherited timestamp describes the source protocol freeze; no additional confirmation freeze is asserted for this sensitivity branch.', 'protocol': config}
    (directory / 'branch_settings.json').write_text(json.dumps(branch_settings, ensure_ascii=False, indent=2), encoding='utf-8')
    options = {'panel_name': args.panel, 'phase': 'test'}
    if args.stage in ['graphs', 'all']:
        build_graphs(config, config['graph']['selected_lambda1'], config['graph']['selected_lambda2'], graph_directory, **options)
    if args.stage in ['forecasts', 'all']:
        replay_forecasts(config, graph_directory, models=('FULL', 'A0'), **options)
    if args.stage in ['scores', 'all']:
        score_forecasts(config, graph_directory, models=('FULL', 'A0'), **options)
    if args.stage in ['portfolios', 'all']:
        run_portfolios(config, graph_directory, models=('FULL', 'A0'), **options)
if __name__ == '__main__':
    main()
