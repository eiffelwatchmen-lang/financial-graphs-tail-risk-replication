"""Download the specified source files and prepare unfilled simple-return panels."""
from datetime import datetime
import json
from pathlib import Path
from urllib.request import urlopen
from zoneinfo import ZoneInfo
import numpy as np
import pandas as pd
ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / 'data' / 'raw'
PROCESSED = ROOT / 'data' / 'processed'
MANIFEST = ROOT / 'data' / 'manifest.json'
AUDIT = ROOT / 'outputs' / 'data_audit.json'
NAV_FIELD = 'ETF Net Asset Value (per Share) (Dividend-included)'
JAPAN_CODES = ['1306', '1343', '2510', '1328']
SOURCES = {'repod.xlsx': {'url': 'https://repod.icm.edu.pl/api/access/datafile/81381?format=original', 'source_version': 'RepOD DOI 10.18150/AN5NET, V2.0, released 2026-08-16T14:22:40Z, file 81381 (format=original); version verified through official dataset API.', 'license_note': 'Repository data file: CC BY 4.0; cite dataset DOI and associated paper. https://repod.icm.edu.pl/dataset.xhtml?persistentId=doi:10.18150/AN5NET'}, 'repod_readme.txt': {'url': 'https://repod.icm.edu.pl/api/access/datafile/81382', 'source_version': 'RepOD DOI 10.18150/AN5NET, V2.0, released 2026-08-16T14:22:40Z, file 81382; version verified through official dataset API.', 'license_note': 'Repository README file and README text both specify CC0; the Excel file has a separate CC BY 4.0 license.'}, **{f'ETF_{code}.csv': {'url': f'https://www.nomura-am.co.jp/fund/etf/history/ETF_{code}.csv', 'source_version': 'Official NEXT FUNDS history snapshot; see downloaded_at for vintage.', 'license_note': 'Public official download; no CC redistribution license established. Keep raw files local; distribute source URL and downloader.'} for code in JAPAN_CODES}}

def download_sources():
    RAW.mkdir(parents=True, exist_ok=True)
    manifest = json.loads(MANIFEST.read_text(encoding='utf-8')) if MANIFEST.exists() else {}
    for filename, source in SOURCES.items():
        path = RAW / filename
        if path.exists():
            print(f'Retained existing source: {filename}')
            continue
        with urlopen(source['url'], timeout=90) as response:
            content = response.read()
        path.write_bytes(content)
        manifest[filename] = {**source, 'downloaded_at': datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(timespec='seconds'), 'bytes': len(content)}
        MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        print(f'Downloaded {filename}: {len(content):,} bytes', flush=True)

def source_audit(frame, field):
    return {'rows': len(frame), 'first_date': frame.index.min().date().isoformat(), 'last_date': frame.index.max().date().isoformat(), 'duplicate_dates': int(frame.index.duplicated().sum()), 'missing_dates': int(frame.index.isna().sum()), 'missing_by_field': {name: int(n) for name, n in frame.isna().sum().items()}, 'selected_field': field, 'selected_field_nonpositive': int((frame[field] <= 0).sum())}

def write_panel(name, prices):
    prices = prices.sort_index()
    prices.index.name = 'date'
    assert prices.index.is_unique and prices.index.notna().all()
    assert np.isfinite(prices.to_numpy()).all() and (prices > 0).all().all()
    returns = prices.pct_change(fill_method=None).iloc[1:]
    assert np.isfinite(returns.to_numpy()).all() and (returns > -1).all().all()
    folder = PROCESSED / name
    folder.mkdir(parents=True, exist_ok=True)
    prices.to_csv(folder / 'prices.csv', date_format='%Y-%m-%d', float_format='%.15g')
    returns.to_csv(folder / 'returns.csv', date_format='%Y-%m-%d', float_format='%.15g')
    extremes = {}
    for asset in prices:
        records = []
        for date in returns[asset].abs().nlargest(5).index:
            pos = prices.index.get_loc(date)
            previous_date = prices.index[pos - 1]
            records.append({'date': date.date().isoformat(), 'previous_date': previous_date.date().isoformat(), 'calendar_day_gap': (date - previous_date).days, 'previous_price': float(prices.iloc[pos - 1][asset]), 'price': float(prices.loc[date, asset]), 'simple_return': float(returns.loc[date, asset])})
        extremes[asset] = records
    year_counts = {str(year): {'prices': int((prices.index.year == year).sum()), 'returns': int((returns.index.year == year).sum())} for year in sorted(set(prices.index.year))}
    date_gaps = prices.index.to_series().diff().dt.days
    gaps = date_gaps.dropna().value_counts().sort_index()
    summary = {'assets': prices.columns.tolist(), 'price_dates': len(prices), 'return_dates': len(returns), 'first_price_date': prices.index[0].date().isoformat(), 'first_return_date': returns.index[0].date().isoformat(), 'last_date': prices.index[-1].date().isoformat(), 'missing_prices': int(prices.isna().sum().sum()), 'missing_returns': int(returns.isna().sum().sum()), 'calendar_day_gap_counts': {str(int(k)): int(v) for k, v in gaps.items()}, 'calendar_gaps_over_four_days': [{'previous_date': prices.index[prices.index.get_loc(date) - 1].date().isoformat(), 'date': date.date().isoformat(), 'calendar_day_gap': int(days)} for date, days in date_gaps[date_gaps > 4].items()], 'observations_by_year': year_counts, 'top_five_absolute_returns': extremes}
    print(f'Prepared {name}: {len(prices)} price dates, {len(returns)} return dates')
    return summary

def prepare_repod():
    workbook = pd.read_excel(RAW / 'repod.xlsx', sheet_name=None)
    series, audit = ({}, {})
    for asset, sheet, field in [('USO', 'Uso', 'CloseUso'), ('GLD', 'Gld', 'CloseGld'), ('BTC', 'Btc', 'CloseBtc')]:
        frame = workbook[sheet].set_index('Date')
        frame.index = pd.to_datetime(frame.index)
        audit[asset] = source_audit(frame, field)
        assert frame.index.is_unique and frame.index.notna().all()
        series[asset] = frame[field].dropna()
    prices = pd.concat(series, axis=1, join='inner')
    summary = write_panel('repod', prices)
    summary.update({'currency': 'USD', 'price_definition': 'Published CloseUso, CloseGld, CloseBtc; price-return allocation proxy.', 'raw_sources': audit, 'excluded_sheet': {'name': 'Spy', 'reason': 'SPY/SPYG identity conflict; excluded before strategy evaluation.'}, 'other_sheets': {name: {'rows': len(frame), 'columns': frame.columns.tolist(), 'duplicate_dates': int(frame['Date'].duplicated().sum()), 'missing_cells': int(frame.isna().sum().sum())} for name, frame in workbook.items() if name not in ['Uso', 'Gld', 'Btc']}, 'dates_removed_by_calendar_intersection': {asset: len(value) - len(prices) for asset, value in series.items()}, 'period_price_date_counts': {'initialization_2016_2018': int((prices.index <= '2018-12-31').sum()), '2019_2020': int(((prices.index >= '2019-01-01') & (prices.index <= '2020-12-31')).sum()), 'test_2021_onward': int((prices.index >= '2021-01-01').sum())}, 'uso_reverse_split': {'event': 'One-for-eight reverse split after close 2020-04-28; post-split trading 2020-04-29.', 'primary_source': 'https://www.sec.gov/Archives/edgar/data/1327068/000117120020000310/i20281_uso-8k.htm', 'close_2020_04_28': float(prices.loc['2020-04-28', 'USO']), 'close_2020_04_29': float(prices.loc['2020-04-29', 'USO']), 'return_across_split': float(prices.loc['2020-04-29', 'USO'] / prices.loc['2020-04-28', 'USO'] - 1), 'decision': 'Published series has no mechanical eightfold discontinuity at this split. Retain source values without another adjustment.'}, 'btc_calendar': 'Returns span successive RepOD observations, including weekends and US market holidays; no inserted dates.', 'source_calendar_gap': 'All five source sheets omit 2018-01-11 and 2018-01-12. The 2018-01-10 to 2018-01-16 return spans six calendar days; no replacement observations are created.'})
    return summary

def prepare_japan():
    series, audit = ({}, {})
    for code in JAPAN_CODES:
        path = RAW / f'ETF_{code}.csv'
        frame = pd.read_csv(path, encoding='cp932', skiprows=4)
        frame['Date'] = pd.to_datetime(frame['Date'].astype(str), format='%Y%m%d')
        frame = frame.set_index('Date').sort_index()
        audit[code] = source_audit(frame, NAV_FIELD)
        assert frame.index.is_unique and frame.index.notna().all()
        nav_returns = frame[NAV_FIELD].pct_change(fill_method=None)
        differences = (nav_returns - frame['Total Return']).dropna()
        assert differences.abs().max() < 1.2e-11
        audit[code].update({'encoding': 'cp932', 'header_skiprows': 4, 'header_notes': path.read_text(encoding='cp932').splitlines()[:2], 'total_return_compared_observations': len(differences), 'nav_return_vs_total_return_max_abs_difference': float(differences.abs().max()), 'after_2025_cutoff_excluded': int((frame.index > '2025-12-31').sum())})
        series[code] = frame.loc[:'2025-12-31', NAV_FIELD].dropna()
    prices = pd.concat(series, axis=1, join='inner')
    summary = write_panel('japan', prices)
    summary.update({'currency': 'JPY', 'price_definition': 'Official dividend-included per-share NAV; allocation proxy, not exchange execution prices.', 'raw_sources': audit, 'cutoff': '2025-12-31', 'dates_removed_after_cutoff_by_calendar_intersection': {asset: len(value) - len(prices) for asset, value in series.items()}, 'period_price_date_counts': {'initialization_through_2020': int((prices.index <= '2020-12-31').sum()), 'test_2021_2025': int((prices.index >= '2021-01-01').sum())}, 'split_handling': 'Retain official already-adjusted NAV. The 1306 file declares adjustment for its April 1, 2026 split; no second adjustment.'})
    return summary

def prepare_data():
    summary = {'generated_at': datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(timespec='seconds'), 'scope': 'Source and data quality diagnostics only; no strategy performance was calculated.', 'processing': 'Common available dates within each panel; simple adjacent-observation returns; no filling, winsorization or additional price adjustment.', 'repod': prepare_repod(), 'japan': prepare_japan()}
    AUDIT.parent.mkdir(parents=True, exist_ok=True)
    AUDIT.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
if __name__ == '__main__':
    download_sources()
    prepare_data()
