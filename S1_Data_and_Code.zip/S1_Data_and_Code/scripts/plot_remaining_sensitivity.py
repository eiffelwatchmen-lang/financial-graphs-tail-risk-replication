"""Plot completed supplementary decisions and the five-seed stability range."""
import argparse
import json
from scripts.plot_confirmation_figures import FIGURES, OUTPUT, PANELS, PANEL_NAMES, horizontal_interval, save_figure, plt, pd, Image
COMMON = ['panel', 'setting', 'observations', 'delta_J_daily_bp', 'delta_J_ci95_lower_bp', 'delta_J_ci95_upper_bp', 'p_raw', 'inference_family', 'p_adjusted']

def decision_figure():
    primary = pd.read_csv(OUTPUT / 'primary_comparison.csv')
    primary['setting'] = 'original'
    primary['inference_family'] = 'two_primary_panels'
    primary['p_adjusted'] = primary.p_holm_two_panels
    tail = pd.read_csv(OUTPUT / 'tail_execution_sensitivity/comparison_summary.csv')
    tail['inference_family'] = tail.Holm_family
    tail['p_adjusted'] = tail.p_holm_supplementary_family
    risk = pd.read_csv(OUTPUT / 'risk_matching/comparison_summary.csv').rename(columns={'ci95_lower_bp': 'delta_J_ci95_lower_bp', 'ci95_upper_bp': 'delta_J_ci95_upper_bp'})
    risk['setting'] = 'risk_cap'
    risk['inference_family'] = 'two_risk_cap_panels'
    risk['p_adjusted'] = risk.p_holm_two_panels_supplementary
    reduced = pd.read_csv(OUTPUT / 'no_gold_sensitivity/comparison_summary.csv')
    reduced['panel'], reduced['setting'] = ('japan', 'no_gold')
    reduced['inference_family'] = 'single_reduced_universe'
    reduced['p_adjusted'] = reduced.p_raw
    data = pd.concat([frame[COMMON] for frame in [primary, tail, risk, reduced]], ignore_index=True)
    settings = ['original', 'tail_0p025', 'tail_0p01', 'weekly', 'risk_cap', 'no_gold']
    names = ['Original (α = 5%)', 'α = 2.5%', 'α = 1%', 'Weekly trading', 'EWMA risk cap', 'Without gold']
    figure, axes = plt.subplots(1, 2, figsize=(7.3, 4.8), sharex=True)
    for column, panel in enumerate(PANELS):
        axis = axes[column]
        labels, positions = ([], [])
        panel_settings = settings if panel == 'japan' else settings[:-1]
        for index, setting in enumerate(panel_settings):
            row = data.loc[(data.panel == panel) & (data.setting == setting)].iloc[0]
            position = 5 - index
            original = setting == 'original'
            horizontal_interval(axis, row, position, '#444444' if original else '#0072B2', marker='D' if original else 'o')
            labels.append(f'{names[index]}\nN = {int(row.observations):,}')
            positions.append(position)
        axis.set_yticks(positions, labels)
        axis.set_ylim(-0.5, 5.5)
        axis.axvline(0, color='#777777', linewidth=0.9, linestyle='--')
        axis.grid(axis='x', color='#E5E5E5', linewidth=0.6)
        axis.set_xlabel('ΔJ = FULL − A0 (bp/day)')
        axis.set_title(f'({chr(97 + column)}) {PANEL_NAMES[panel]}', loc='left')
    figure.tight_layout(w_pad=1.8)
    save_figure(figure, 'remaining_decision_delta_J', data, "Figure 5. Supplementary FULL−A0 decision comparisons. J is mean net return minus 0.05 times realized loss ES at each row's tail probability; the original, weekly, EWMA and reduced-universe rows use a 5% tail. Tail settings reoptimize the portfolios at the displayed probability. Weekly signals are generated on the first observed date of each ISO week, followed by next-observation execution and daily holding returns. The EWMA row applies a common ex-ante annualized risk cap of 17.55314253%, calibrated using development data; Japan never triggers this cap and reproduces its original path. The no-gold row re-estimates both models after removing fund 1328. Intervals are unadjusted 95% percentile intervals from 5,000 paired stationary bootstrap replicates with mean block length 20. Distinct supplementary test families and adjusted p values are retained in the underlying CSV; changes between settings are descriptive. Sources: primary_comparison.csv and each branch's comparison_summary.csv.")

def seed_figure():
    data = pd.read_csv(OUTPUT / 'seed_sensitivity/comparison_summary.csv')
    figure, axes = plt.subplots(1, 2, figsize=(7.3, 3.2), sharey=True)
    for column, panel in enumerate(PANELS):
        subset = data.loc[data.panel == panel].sort_values('seed')
        axis = axes[column]
        for position, (_, row) in enumerate(subset.iterrows()):
            original = row.seed == 20261012
            axis.scatter(position, row.delta_J_daily_bp, color='#444444' if original else '#0072B2', marker='D' if original else 'o', s=45, zorder=3)
        axis.set_xticks(range(len(subset)), [str(int(seed))[-2:] for seed in subset.seed])
        axis.set_xlabel('Seed (202610xx)')
        axis.axhline(0, color='#777777', linewidth=0.9, linestyle='--')
        axis.grid(axis='y', color='#E5E5E5', linewidth=0.6)
        axis.set_title(f'({chr(97 + column)}) {PANEL_NAMES[panel]}', loc='left')
        axis.margins(x=0.15)
    axes[0].set_ylabel('ΔJ = FULL − A0 (bp/day)')
    figure.tight_layout(w_pad=1.7)
    save_figure(figure, 'seed_stability_delta_J', data, 'Figure 6. FULL−A0 decision differences across all five specified random seeds. The black diamond is the original seed 20261012; blue circles show seeds 20261013–20261016. Every additional seed repeats the graph stability bootstrap, monthly predictor training, historical PIT dependence, joint scenarios and allocation. Within each seed, FULL and A0 share signal-date base random draws. All seeds retain the frozen model and decision settings. This display describes algorithmic stability; seed ranges are not sampling confidence intervals, and no additional significance tests or best-seed selection are performed. Source: seed_sensitivity/comparison_summary.csv.')

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--stage', choices=['decision', 'seeds', 'all'], default='all')
    args = parser.parse_args()
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 9, 'axes.titlesize': 9, 'axes.labelsize': 9, 'xtick.labelsize': 8, 'ytick.labelsize': 8, 'axes.spines.top': False, 'axes.spines.right': False, 'pdf.fonttype': 42, 'ps.fonttype': 42, 'svg.fonttype': 'none', 'savefig.facecolor': 'white'})
    if args.stage in ['decision', 'all']:
        decision_figure()
    if args.stage in ['seeds', 'all']:
        seed_figure()
    exports = []
    for stem in ['remaining_decision_delta_J', 'seed_stability_delta_J']:
        path = FIGURES / f'{stem}.tif'
        if path.exists():
            with Image.open(path) as tif:
                exports.append({'file': path.name, 'width_pixels': tif.width, 'height_pixels': tif.height, 'dpi': [float(x) for x in tif.info['dpi']], 'mode': tif.mode, 'compression': tif.info['compression'], 'bytes': path.stat().st_size})
    (FIGURES / 'supplementary_export_record.json').write_text(json.dumps({'font': 'DejaVu Sans', 'font_sizes_pt': [8, 9], 'files': exports}, indent=2), encoding='utf-8')
if __name__ == '__main__':
    main()
