"""Replay the four prespecified additional seeds and report descriptive ranges."""
import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
from contextlib import redirect_stderr, redirect_stdout
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import time
os.environ['OPENBLAS_NUM_THREADS'] = '1'
os.environ['OMP_NUM_THREADS'] = '1'
import pandas as pd
from scripts.run_graph_development import build_graphs, replay_forecasts, run_portfolios, score_forecasts
ROOT = Path(__file__).resolve().parents[1]
FROZEN = ROOT / 'configs/frozen_protocol.json'
OUTPUT = ROOT / 'outputs/confirmation/seed_sensitivity'
SEEDS = (20261013, 20261014, 20261015, 20261016)
PANELS = ('repod', 'japan')

def run_one(seed, panel):
    config = json.loads(FROZEN.read_text(encoding='utf-8'))
    config['seed'] = seed
    config['stage'] = 'additional_seed_stability'
    directory = OUTPUT / f'seed_{seed}' / panel
    directory.mkdir(parents=True, exist_ok=True)
    graph_directory = directory / 'graph'
    started = datetime.now(timezone.utc).isoformat()
    tick = time.perf_counter()
    print(f'START seed={seed} panel={panel} {started}', flush=True)
    with (directory / 'run.log').open('w', encoding='utf-8', buffering=1) as log:
        with redirect_stdout(log), redirect_stderr(log):
            print(f'seed={seed} panel={panel} started_at_utc={started}', flush=True)
            options = {'panel_name': panel, 'phase': 'test'}
            build_graphs(config, config['graph']['selected_lambda1'], config['graph']['selected_lambda2'], graph_directory, **options)
            replay_forecasts(config, graph_directory, models=('FULL', 'A0'), **options)
            score_forecasts(config, graph_directory, models=('FULL', 'A0'), **options)
            run_portfolios(config, graph_directory, models=('FULL', 'A0'), **options)
    finished = {'seed': seed, 'panel': panel, 'started_at_utc': started, 'completed_at_utc': datetime.now(timezone.utc).isoformat(), 'elapsed_seconds': time.perf_counter() - tick, 'models': ['FULL', 'A0'], 'frozen_protocol_source': FROZEN.relative_to(ROOT).as_posix(), 'graph_forecast_and_portfolio_replayed': True}
    (directory / 'completion.json').write_text(json.dumps(finished, indent=2) + '\n', encoding='utf-8')
    return finished

def report():
    original_seed = json.loads(FROZEN.read_text(encoding='utf-8'))['seed']
    rows = []
    for seed in (original_seed, *SEEDS):
        for panel in PANELS:
            directory = ROOT / 'outputs/confirmation' / panel / 'graph' if seed == original_seed else OUTPUT / f'seed_{seed}' / panel / 'graph'
            portfolio = pd.read_csv(directory / 'portfolio_summary.csv').set_index('model')
            prediction = pd.read_csv(directory / 'prediction_summary.csv').set_index('model')
            graph_updates = pd.read_csv(directory / 'graph_updates.csv')
            scores = pd.read_csv(directory / 'FULL_scores.csv')
            rows.append({'seed': seed, 'panel': panel, 'original_seed': seed == original_seed, 'observations': int(portfolio.loc['FULL', 'observations']), 'first_target': portfolio.loc['FULL', 'first_target'], 'last_target': portfolio.loc['FULL', 'last_target'], 'FULL_J_daily_bp': portfolio.loc['FULL', 'J_daily_bp'], 'A0_J_daily_bp': portfolio.loc['A0', 'J_daily_bp'], 'delta_J_daily_bp': portfolio.loc['FULL', 'J_daily_bp'] - portfolio.loc['A0', 'J_daily_bp'], 'FULL_mean_FZ': prediction.loc['FULL', 'mean_fz'], 'A0_mean_FZ': prediction.loc['A0', 'mean_fz'], 'delta_mean_FZ': prediction.loc['FULL', 'mean_fz'] - prediction.loc['A0', 'mean_fz'], 'monthly_graph_updates': len(graph_updates), 'monthly_graph_edges_mean': graph_updates.edges.mean(), 'monthly_graph_edges_max': graph_updates.edges.max(), 'test_graph_edges_mean': scores.graph_edges.mean(), 'test_graph_edges_max': scores.graph_edges.max(), 'test_nonempty_graph_fraction': scores.graph_edges.gt(0).mean(), 'source_directory': directory.relative_to(ROOT).as_posix()})
    comparisons = pd.DataFrame(rows)
    comparisons.to_csv(OUTPUT / 'comparison_summary.csv', index=False)
    metrics = ['FULL_J_daily_bp', 'A0_J_daily_bp', 'delta_J_daily_bp', 'FULL_mean_FZ', 'A0_mean_FZ', 'delta_mean_FZ', 'test_graph_edges_mean', 'test_graph_edges_max']
    ranges = []
    for panel in PANELS:
        subset = comparisons.loc[comparisons.panel == panel]
        row = {'panel': panel, 'seed_count': len(subset)}
        for metric in metrics:
            row[metric + '_min'] = subset[metric].min()
            row[metric + '_max'] = subset[metric].max()
        ranges.append(row)
    range_table = pd.DataFrame(ranges)
    range_table.to_csv(OUTPUT / 'stability_ranges.csv', index=False)
    lines = ['预设随机种子稳定性范围', '', '原方案规定主种子 20261012，并追加 20261013—20261016，仅报告稳定性范围。本分支的具体执行记录建立于主要结果完成之后，保留原冻结协议及主检验。', '追加种子同时作用于图的稳定性 bootstrap、各月网络初始化与训练抽样、信号日联合情景。同种子的 FULL/A0 共享信号日期基础随机数，每个追加种子均完整重估历史图、条件分布、成熟 PIT 与组合路径。各路径从现金等权建仓，沿用原时序、日期范围、选定正则化、训练预算、成本、尾部概率及风险偏好。', '', '全部种子结果：J 与 ΔJ 的单位为基点/日；FZ 为原评分单位，差值均为 FULL 减 A0。', comparisons[['seed', 'panel', 'observations', 'first_target', 'last_target', 'FULL_J_daily_bp', 'A0_J_daily_bp', 'delta_J_daily_bp', 'FULL_mean_FZ', 'A0_mean_FZ', 'delta_mean_FZ', 'monthly_graph_edges_max', 'test_graph_edges_mean', 'test_graph_edges_max']].to_string(index=False, float_format=lambda value: f'{value:.8f}'), '', '五个种子的完整最小值—最大值范围：', range_table.to_string(index=False, float_format=lambda value: f'{value:.8f}'), '', '这些范围描述既定随机设置下的稳定性，不构成新增显著性检验，也不用于选择表现最好的种子。主种子结果直接引用已完成的确认档案；追加种子的图、训练、预测、评分和交易记录保存在各自目录。', f'冻结协议来源：{FROZEN.relative_to(ROOT).as_posix()}', f"设计记录、实际时间和完整协议副本：{(OUTPUT / 'design.json').relative_to(ROOT).as_posix()}", '复现：python run.py -m scripts.run_seed_sensitivity --stage run', '仅重建描述报告：python run.py -m scripts.run_seed_sensitivity --stage report']
    (OUTPUT / 'report.txt').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(comparisons[['seed', 'panel', 'delta_J_daily_bp', 'FULL_mean_FZ', 'A0_mean_FZ']].to_string(index=False), flush=True)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--stage', choices=('run', 'report'), default='run')
    parser.add_argument('--workers', type=int, default=2)
    parser.add_argument('--resume', action='store_true')
    args = parser.parse_args()
    if args.stage == 'run':
        OUTPUT.mkdir(parents=True, exist_ok=True)
        config = json.loads(FROZEN.read_text(encoding='utf-8'))
        design = {'branch': 'prespecified_additional_seed_stability', 'recorded_at_utc': datetime.now(timezone.utc).isoformat(), 'execution_details_recorded_after_primary_results': True, 'original_protocol_wording': '主种子 20261012；另用 20261013—20261016，仅报告稳定性范围', 'frozen_protocol_source': FROZEN.relative_to(ROOT).as_posix(), 'frozen_protocol': config, 'additional_seeds': list(SEEDS), 'panels': list(PANELS), 'models': ['FULL', 'A0'], 'seed_scope': ['graph_bootstrap', 'monthly_network_initialization_and_batches', 'daily_copula_scenarios'], 'common_random_numbers': 'FULL/A0 share seed plus signal date within each seed and panel', 'full_historical_replay': True, 'reuse_original_forecasts': False, 'additional_portfolio_paths': 16, 'maximum_worker_processes': args.workers, 'OPENBLAS_NUM_THREADS': 1, 'OMP_NUM_THREADS': 1, 'inference': 'Five-seed descriptive ranges only; original primary tests unchanged'}
        if not args.resume:
            (OUTPUT / 'design.json').write_text(json.dumps(design, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        tasks = [(seed, panel) for seed in SEEDS for panel in PANELS if not args.resume or not (OUTPUT / f'seed_{seed}' / panel / 'completion.json').is_file()]
        print(f'RUN workers={args.workers} resume={args.resume} remaining_tasks={len(tasks)}', flush=True)
        with ProcessPoolExecutor(max_workers=args.workers) as executor:
            jobs = [executor.submit(run_one, seed, panel) for seed, panel in tasks]
            for job in as_completed(jobs):
                result = job.result()
                print(f"DONE seed={result['seed']} panel={result['panel']} {result['elapsed_seconds']:.1f}s", flush=True)
    report()
if __name__ == '__main__':
    main()
