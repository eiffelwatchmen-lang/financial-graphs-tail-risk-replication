"""Summarize the extra-execution-delay branch and its original-path context."""
import json
import numpy as np
import pandas as pd
from scripts.baselines import tail_es
from scripts.report_confirmation import OUTPUT, PANELS, ROOT, read_records
from scripts.statistical_inference import holm_adjust, paired_j_bootstrap

def add_strategy_metrics(row, prefix, records, alpha, kappa):
    mean = records.net_return.mean()
    es = tail_es(-records.net_return.to_numpy(), alpha)
    row[f'{prefix}_mean_net_daily_bp'] = 10000 * mean
    row[f'{prefix}_loss_ES95_daily_bp'] = 10000 * es
    row[f'{prefix}_J_daily_bp'] = 10000 * (mean - kappa * es)

def main():
    config = json.loads((ROOT / 'configs/frozen_protocol.json').read_text(encoding='utf-8'))
    directory = OUTPUT / 'delay_sensitivity'
    alpha, kappa = (config['portfolio']['tail_probability'], config['portfolio']['kappa'])
    options = {'repetitions': config['inference']['bootstrap_repetitions'], 'block_length': config['inference']['block_length'], 'seed': config['seed']}
    rows = []
    for panel in PANELS:
        delayed_directory = directory / panel / 'graph'
        full = read_records(delayed_directory, 'FULL', 'ledger')
        a0 = read_records(delayed_directory, 'A0', 'ledger', full.target_date)
        full_scores = read_records(delayed_directory, 'FULL', 'scores', full.target_date)
        a0_scores = read_records(delayed_directory, 'A0', 'scores', full.target_date)
        result = paired_j_bootstrap(np.column_stack((full.net_return, a0.net_return)), [(0, 1)], alpha=alpha, kappa=kappa, **options)
        row = {'panel': panel, 'comparison': 'FULL-A0', 'observations': len(full), 'first_signal': str(full.signal_date.iloc[0].date()), 'first_execution': str(pd.Timestamp(full.execution_date.iloc[0]).date()), 'first_target': str(full.target_date.iloc[0].date()), 'last_target': str(full.target_date.iloc[-1].date()), 'execution_lag': 2, 'target_lag': 3, 'tail_probability': alpha, 'kappa': kappa, 'bootstrap_repetitions': options['repetitions'], 'block_length': options['block_length'], 'seed': options['seed'], 'delta_J_daily_bp': 10000 * result['point_difference'][0], 'delta_J_ci95_lower_bp': 10000 * result['ci_lower'][0], 'delta_J_ci95_upper_bp': 10000 * result['ci_upper'][0], 'p_raw': result['p_value'][0], 'FULL_mean_FZ': full_scores.fz.mean(), 'A0_mean_FZ': a0_scores.fz.mean(), 'delta_mean_FZ_descriptive': full_scores.fz.mean() - a0_scores.fz.mean(), 'delayed_source_directory': delayed_directory.relative_to(ROOT).as_posix()}
        add_strategy_metrics(row, 'FULL', full, alpha, kappa)
        add_strategy_metrics(row, 'A0', a0, alpha, kappa)
        original_directory = OUTPUT / panel / 'graph'
        original_full = read_records(original_directory, 'FULL', 'ledger')
        original_a0 = read_records(original_directory, 'A0', 'ledger', original_full.target_date)
        selected = original_full.target_date.isin(full.target_date)
        common_full, common_a0 = (original_full.loc[selected], original_a0.loc[selected])
        row.update({'original_first_execution': str(pd.Timestamp(original_full.execution_date.iloc[0]).date()), 'original_first_target': str(original_full.target_date.iloc[0].date()), 'common_observations': len(common_full), 'common_first_target': str(common_full.target_date.iloc[0].date()), 'common_last_target': str(common_full.target_date.iloc[-1].date()), 'original_source_directory': original_directory.relative_to(ROOT).as_posix()})
        add_strategy_metrics(row, 'original_common_FULL', common_full, alpha, kappa)
        add_strategy_metrics(row, 'original_common_A0', common_a0, alpha, kappa)
        row['original_common_delta_J_daily_bp_descriptive'] = row['original_common_FULL_J_daily_bp'] - row['original_common_A0_J_daily_bp']
        rows.append(row)
    table = pd.DataFrame(rows)
    table['p_holm_two_panels_supplementary'] = holm_adjust(table.p_raw.to_numpy())
    table.to_csv(directory / 'comparison_summary.csv', index=False)
    lines = ['额外一期执行延迟：补充分析', '', '信号 s 在 s+2 执行，预测并评价 r(s+3) 的单期收益。分支使用固定的已选超参数，从历史起重新估计图、FULL/A0 条件分布及成熟 PIT copula；PIT 仅在 s+3 标签到期后进入档案。', '两个模型使用相同均值、情景数与信号日随机种子，按延迟执行规则重新优化与交易。新路径在各面板首次执行日从现金购入等权组合，成本按实际成交核算并归入其后的单期收益。', f'J=净收益均值−{kappa}×损失 ES，尾部概率 {alpha:.0%}，经验 ES 保留精确 5% 尾部质量。J、净收益均值及损失 ES 的单位为每日基点；ΔJ 为 FULL 减 A0。', f"配对平稳区块 bootstrap {options['repetitions']} 次，平均区块长度 {options['block_length']}，种子 {options['seed']}。每次同步抽取两策略日期行并重新估计均值、ES 和 J；95% 区间采用 percentile 法，双侧中心化 p=(1+#{{|Δ*−Δhat|≥|Δhat|}})/(B+1)。", '两个面板的延迟分支 p 构成独立的补充 Holm 家族，原主要检验保持不变。', '', table[['panel', 'observations', 'first_signal', 'first_execution', 'first_target', 'last_target', 'FULL_J_daily_bp', 'A0_J_daily_bp', 'delta_J_daily_bp', 'delta_J_ci95_lower_bp', 'delta_J_ci95_upper_bp', 'p_raw', 'p_holm_two_panels_supplementary']].to_string(index=False, float_format=lambda value: f'{value:.6f}'), '', '延迟分支的净收益、尾部损失与共同等权组合预测评分（FZ 为原评分单位，差值为描述性结果）：', table[['panel', 'FULL_mean_net_daily_bp', 'A0_mean_net_daily_bp', 'FULL_loss_ES95_daily_bp', 'A0_loss_ES95_daily_bp', 'FULL_mean_FZ', 'A0_mean_FZ', 'delta_mean_FZ_descriptive']].to_string(index=False, float_format=lambda value: f'{value:.6f}'), '', '原时序路径在共同目标日期上的描述：原模型 s+1 执行并预测 r(s+2)。下列结果只筛取既有交易档案的共同 target_date，保留此前形成的持仓、交易成本及连续运行路径。', table[['panel', 'common_observations', 'common_first_target', 'common_last_target', 'original_first_execution', 'original_first_target', 'original_common_FULL_mean_net_daily_bp', 'original_common_A0_mean_net_daily_bp', 'original_common_FULL_loss_ES95_daily_bp', 'original_common_A0_loss_ES95_daily_bp', 'original_common_FULL_J_daily_bp', 'original_common_A0_J_daily_bp', 'original_common_delta_J_daily_bp_descriptive']].to_string(index=False, float_format=lambda value: f'{value:.6f}'), '', '延迟路径的首次建仓日和首次持有收益日较原路径后移；共同日期上的原路径延续先前持仓。跨时序描述差异包含对应预测目标及初始化路径的共同影响，不能单独解释为延迟一天的纯效应。', f"冻结主配置：{(ROOT / 'configs/frozen_protocol.json').relative_to(ROOT).as_posix()}。", '延迟分支配置及预测来源：delay_sensitivity/{panel}/branch_settings.json 与 {panel}/graph/settings.json。', '复现：python run.py -m scripts.report_delay_sensitivity']
    (directory / 'report.txt').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(table[['panel', 'observations', 'delta_J_daily_bp', 'delta_J_ci95_lower_bp', 'delta_J_ci95_upper_bp', 'p_holm_two_panels_supplementary']].to_string(index=False))
if __name__ == '__main__':
    main()
