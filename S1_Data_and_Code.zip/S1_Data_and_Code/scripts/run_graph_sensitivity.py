"""Reestimate the three planned graph sensitivities and retain result provenance."""
import argparse
from copy import deepcopy
from datetime import datetime, timezone
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scripts.baselines import tail_es
from scripts.report_confirmation import read_records
from scripts.run_graph_development import build_graphs, load_panel, replay_forecasts, run_portfolios, score_forecasts
from scripts.statistical_inference import holm_adjust, paired_j_bootstrap
ROOT = Path(__file__).resolve().parents[1]
CONFIRMATION = ROOT / 'outputs/confirmation'
OUTPUT = CONFIRMATION / 'graph_sensitivity'
PANELS = ('repod', 'japan')
SETTINGS = {'quantile_0p95': ('quantile', 0.95), 'window_756': ('max_samples', 756), 'bootstrap_100': ('bootstrap_repetitions', 100)}

def record_design():
    config = json.loads((ROOT / 'configs/frozen_protocol.json').read_text(encoding='utf-8'))
    protocols = {}
    for setting, (parameter, value) in SETTINGS.items():
        branch = deepcopy(config)
        branch['stage'] = 'graph_sensitivity_after_primary_results'
        branch['graph'][parameter] = value
        protocols[setting] = branch
    design = {'design_recorded_at_utc': datetime.now(timezone.utc).isoformat(), 'status': 'Implementation recorded after primary results were known; the three settings were present in the original experiment plan.', 'frozen_protocol_source': (ROOT / 'configs/frozen_protocol.json').relative_to(ROOT).as_posix(), 'source_protocol_frozen_at_utc': config['confirmation']['frozen_at_utc'], 'historical_selection_information_cutoff': config['confirmation']['selection_information_cutoff'], 'new_confirmation_freeze': False, 'fixed_lambda1': config['graph']['selected_lambda1'], 'fixed_lambda2': config['graph']['selected_lambda2'], 'hyperparameter_reselection': False, 'window_756_rule': 'Replay from at least 252 mature rows, expanding to 756; evaluate no earlier than the first monthly graph with 756 mature rows, plus target_lag observed panel dates, and the original executable confirmation start.', 'portfolio_path_rule': 'Run or reuse the continuous portfolio path from the original confirmation initialization; slice the evaluation window without resetting holdings or wealth.', 'equivalence_rule': 'Exact elementwise equality of complete historical adjacency arrays, with identical graph availability and monthly training dates, reuses original FULL/A0 forecasts and portfolios.', 'inference_rule': 'List all six labels. Reuse original primary inference when paired return sources and dates are unchanged. For new graph sources or date subsets, stationary bootstrap 5000, mean block 20, seed 20261012; Holm across distinct new paired sources and dates only, then map aliases back.', 'maximum_cpu_processes': 2, 'threads_per_process': 1, 'protocols': protocols}
    OUTPUT.mkdir(parents=True, exist_ok=True)
    (OUTPUT / 'design.json').write_text(json.dumps(design, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f"Graph sensitivity design recorded: {design['design_recorded_at_utc']}", flush=True)

def evaluate_branch(setting, panel, config, directory):
    graph_directory = directory / 'graph'
    primary_directory = CONFIRMATION / panel / 'graph'
    branch_graph = np.load(graph_directory / 'graphs.npz')
    primary_graph = np.load(primary_directory / 'graphs.npz')
    for name in ['graph_cutoff', 'update_indices']:
        if not np.array_equal(branch_graph[name], primary_graph[name]):
            raise ValueError(f'Graph availability or monthly training dates changed: {setting}/{panel}/{name}')
    equivalent = np.array_equal(branch_graph['adjacency'], primary_graph['adjacency'])
    full_source = primary_directory if equivalent else graph_directory
    provenance = {'setting': setting, 'panel': panel, 'adjacency_exact_equal_entire_history': equivalent, 'same_graph_availability_and_training_dates': True, 'FULL_separately_trained': not equivalent, 'A0_separately_trained': False, 'FULL_source_directory': full_source.relative_to(ROOT).as_posix(), 'A0_source_directory': primary_directory.relative_to(ROOT).as_posix(), 'A0_reuse_reason': 'Same features, training dates, seed and budget; A0 does not use graph values.', 'equivalent_results_are_independent_runs': False}
    (directory / 'equivalence.json').write_text(json.dumps(provenance, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f'{setting}/{panel}: whole-history adjacency equivalent={equivalent}', flush=True)
    if not equivalent:
        options = {'panel_name': panel, 'phase': 'test', 'models': ('FULL',)}
        replay_forecasts(config, graph_directory, **options)
        score_forecasts(config, graph_directory, **options)
        run_portfolios(config, graph_directory, **options)
    dates, _, _, _, _ = load_panel(config, panel, 'test')
    updates = pd.read_csv(graph_directory / 'graph_updates.csv', parse_dates=['update_date'])
    original = {model: read_records(primary_directory, model, 'ledger') for model in ['FULL', 'A0']}
    first_target = original['FULL'].target_date.iloc[0]
    full_window_update = None
    first_full_window_target = None
    if setting == 'window_756':
        full_window_update = updates.loc[updates.samples.eq(756), 'update_date'].iloc[0]
        first_full_window_target = dates[dates.get_loc(full_window_update) + config['timing']['target_lag']]
        first_target = max(first_target, first_full_window_target)
    reference_dates = original['FULL'].loc[original['FULL'].target_date.ge(first_target), 'target_date'].reset_index(drop=True)
    evaluation = directory / 'evaluation'
    evaluation.mkdir(parents=True, exist_ok=True)
    sources = {'FULL': full_source, 'A0': primary_directory}
    for model in ['FULL', 'A0']:
        reference = original[model].loc[original[model].target_date.ge(first_target)].reset_index(drop=True)
        if not reference.target_date.equals(reference_dates):
            raise ValueError(f'Original paired target dates differ: {panel}/{model}')
        reference.to_csv(evaluation / f'primary_{model}_ledger.csv', index=False)
        for kind in ['ledger', 'scores']:
            frame = read_records(sources[model], model, kind, original['FULL'].target_date)
            frame = frame.loc[frame.target_date.ge(first_target)].reset_index(drop=True)
            if not frame.target_date.equals(reference_dates):
                raise ValueError(f'Sensitivity target dates differ: {setting}/{panel}/{model}/{kind}')
            frame.to_csv(evaluation / f'{model}_{kind}.csv', index=False)
    signal_dates = read_records(evaluation, 'FULL', 'scores', reference_dates).signal_date
    signal_indices = dates.get_indexer(signal_dates)
    evaluation_edges = np.count_nonzero(branch_graph['adjacency'][signal_indices], axis=(1, 2))
    cross_start = 1 + len(config['graph']['own_controls'])
    metadata = {**provenance, 'graph_updates': len(updates), 'nonempty_graph_updates': int(updates.edges.gt(0).sum()), 'maximum_monthly_edges': int(updates.edges.max()), 'maximum_absolute_point_cross_coefficient': float(np.abs(branch_graph['coefficients_standardized'][..., cross_start:]).max()), 'first_update_with_756_mature_rows': str(full_window_update.date()) if full_window_update is not None else None, 'first_executable_target_with_756_mature_rows': str(first_full_window_target.date()) if first_full_window_target is not None else None, 'original_path_first_target': str(original['FULL'].target_date.iloc[0].date()), 'first_target': str(reference_dates.iloc[0].date()), 'last_target': str(reference_dates.iloc[-1].date()), 'observations': len(reference_dates), 'mean_evaluation_graph_edges': float(evaluation_edges.mean()), 'maximum_evaluation_graph_edges': int(evaluation_edges.max()), 'same_evaluation_dates_as_primary': reference_dates.equals(original['FULL'].target_date), 'evaluation_is_continuous_path_slice': True, 'holdings_or_wealth_reset_at_slice_start': False, 'retained_wealth_units': 'Original continuous path wealth; do not treat sliced terminal wealth as a new unit-capital portfolio.'}
    (directory / 'evaluation.json').write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f"{setting}/{panel}: evaluation {metadata['first_target']} to {metadata['last_target']}, N={len(reference_dates)}, monthly max edges={metadata['maximum_monthly_edges']}", flush=True)

def run_panel(panel, setting, stage):
    design = json.loads((OUTPUT / 'design.json').read_text(encoding='utf-8'))
    chosen = SETTINGS if setting == 'all' else [setting]
    for name in chosen:
        config = design['protocols'][name]
        directory = OUTPUT / name / panel
        directory.mkdir(parents=True, exist_ok=True)
        settings = {'setting': name, 'panel': panel, 'design_recorded_at_utc': design['design_recorded_at_utc'], 'implementation_after_primary_results': True, 'design_source': (OUTPUT / 'design.json').relative_to(ROOT).as_posix(), 'protocol': config}
        (directory / 'branch_settings.json').write_text(json.dumps(settings, ensure_ascii=False, indent=2), encoding='utf-8')
        if stage in ['graphs', 'all']:
            print(f'{name}/{panel}: rebuilding all monthly graphs', flush=True)
            build_graphs(config, config['graph']['selected_lambda1'], config['graph']['selected_lambda2'], directory / 'graph', panel_name=panel, phase='test')
        if stage in ['evaluate', 'all']:
            evaluate_branch(name, panel, config, directory)

def report():
    design = json.loads((OUTPUT / 'design.json').read_text(encoding='utf-8'))
    primary = pd.read_csv(CONFIRMATION / 'primary_comparison.csv').set_index('panel')
    rows, cache = ([], {})
    for setting in SETTINGS:
        config = design['protocols'][setting]
        for panel in PANELS:
            directory = OUTPUT / setting / panel
            metadata = json.loads((directory / 'evaluation.json').read_text(encoding='utf-8'))
            frames = {}
            for model in ['FULL', 'A0']:
                for kind in ['ledger', 'scores']:
                    source = read_records(Path(metadata[f'{model}_source_directory']), model, kind)
                    frames[model, kind] = source.loc[source.target_date.ge(metadata['first_target'])].reset_index(drop=True)
            full, a0 = (frames['FULL', 'ledger'], frames['A0', 'ledger'])
            full_scores, a0_scores = (frames['FULL', 'scores'], frames['A0', 'scores'])
            for frame in frames.values():
                if not frame.target_date.equals(full.target_date):
                    raise ValueError(f'Statistical source target dates differ: {setting}/{panel}')
            key = (metadata['FULL_source_directory'], metadata['A0_source_directory'], metadata['first_target'], metadata['last_target'])
            original_comparison = metadata['adjacency_exact_equal_entire_history'] and metadata['same_evaluation_dates_as_primary']
            if key not in cache:
                if original_comparison:
                    record = primary.loc[panel]
                    stats = {name: float(record[name]) for name in ['FULL_J_daily_bp', 'A0_J_daily_bp', 'delta_J_daily_bp', 'delta_J_ci95_lower_bp', 'delta_J_ci95_upper_bp', 'p_raw', 'delta_mean_net_daily_bp', 'delta_loss_ES95_daily_bp']}
                    stats['p_holm_primary_reference'] = float(record.p_holm_two_panels)
                else:
                    result = paired_j_bootstrap(np.column_stack((full.net_return, a0.net_return)), [(0, 1)], alpha=config['portfolio']['tail_probability'], kappa=config['portfolio']['kappa'], repetitions=5000, block_length=20, seed=20261012)
                    stats = {'FULL_J_daily_bp': 10000 * result['J'][0], 'A0_J_daily_bp': 10000 * result['J'][1], 'delta_J_daily_bp': 10000 * result['point_difference'][0], 'delta_J_ci95_lower_bp': 10000 * result['ci_lower'][0], 'delta_J_ci95_upper_bp': 10000 * result['ci_upper'][0], 'p_raw': result['p_value'][0], 'delta_mean_net_daily_bp': 10000 * result['mean_difference'][0], 'delta_loss_ES95_daily_bp': 10000 * result['loss_es_difference'][0], 'p_holm_primary_reference': None}
                stats['comparison_source_id'] = f'comparison_{len(cache) + 1}'
                stats['in_supplementary_Holm_family'] = not original_comparison
                cache[key] = stats
            references, reference_values = ({}, {})
            for model in ['FULL', 'A0']:
                source = read_records(CONFIRMATION / panel / 'graph', model, 'ledger')
                references[model] = source.loc[source.target_date.ge(metadata['first_target'])].reset_index(drop=True)
                if not references[model].target_date.equals(full.target_date):
                    raise ValueError(f'Same-date primary reference differs: {setting}/{panel}/{model}')
                net = references[model].net_return.to_numpy()
                reference_values[model] = 10000 * (net.mean() - config['portfolio']['kappa'] * tail_es(-net, config['portfolio']['tail_probability']))
            rows.append({**metadata, **cache[key], 'FULL_mean_FZ': float(full_scores.fz.mean()), 'A0_mean_FZ': float(a0_scores.fz.mean()), 'delta_mean_FZ_descriptive': float(full_scores.fz.mean() - a0_scores.fz.mean()), 'FULL_returns_equal_primary_same_dates': np.array_equal(full.net_return, references['FULL'].net_return), 'A0_returns_equal_primary_same_dates': np.array_equal(a0.net_return, references['A0'].net_return), 'primary_same_dates_FULL_J_daily_bp': reference_values['FULL'], 'primary_same_dates_A0_J_daily_bp': reference_values['A0'], 'primary_same_dates_delta_J_daily_bp': reference_values['FULL'] - reference_values['A0'], 'evaluation_source': (directory / 'evaluation.json').relative_to(ROOT).as_posix()})
    table = pd.DataFrame(rows)
    members = table.loc[table.in_supplementary_Holm_family].drop_duplicates('comparison_source_id')
    adjusted = holm_adjust(members.p_raw.to_numpy())
    p_mapping = dict(zip(members.comparison_source_id, adjusted))
    table['p_holm_supplementary'] = table.comparison_source_id.map(p_mapping)
    table['distinct_supplementary_hypotheses'] = len(members)
    table.to_csv(OUTPUT / 'comparison_summary.csv', index=False)
    columns = ['setting', 'panel', 'observations', 'first_target', 'nonempty_graph_updates', 'adjacency_exact_equal_entire_history', 'comparison_source_id', 'delta_J_daily_bp', 'delta_J_ci95_lower_bp', 'delta_J_ci95_upper_bp', 'p_raw', 'p_holm_primary_reference', 'p_holm_supplementary']
    lines = ['图参数稳健性补充报告', '', '完整展示原方案中的分位数 0.95、最大历史窗口 756、图 bootstrap 100 次，分别在两个面板执行；每项只改变一个图设置，固定 λ1=0.08、λ2=0.005 与其他训练和配置规则，不重新选参。', f"具体设计记录时间为 {design['design_recorded_at_utc']}，实施时已知主结果；该时间不是新的事前确认冻结。原配置冻结时间为 {design['source_protocol_frozen_at_utc']}，历史选参信息截止为 {design['historical_selection_information_cutoff']}。", f'六个标签共引用 {table.comparison_source_id.nunique()} 个不同的策略来源与日期组合；其中 {len(members)} 个新增比较进入独立补充 Holm 族。相同来源和相同日期不构成独立重复证据。原主比较直接引用原 p 值和两面板 Holm p，不重新校正或替换原主要检验。', '', table[columns].to_string(index=False, float_format=lambda value: f'{value:.8f}'), '', '窗口 756 从至少 252 个成熟样本起扩展重放。报告起点为首个实际用满 756 样本的月度图更新日后的第二个面板观测日，与原确认可执行起点取较晚者。预测及 PIT 使用完整历史；交易记录截取原确认起点以来的连续持仓路径，不在子样本起点重新建仓。各分支 evaluation.json 保留实际满窗图日、可执行目标日、最终起止日期及样本数。', '每项均先重新估计所有月度图。只有完整历史邻接数组逐元素完全相同，且图可用日期、预测器训练日程相同，才引用主 FULL 结果；A0 在相同特征、训练日、种子和预算下不受图值影响，引用主 A0。图系数及 bootstrap 仍保留各分支真实估计产物，来源映射见 equivalence.json。', '']
    for row in table.itertuples(index=False):
        lines.append(f'{row.setting}/{row.panel}：{row.graph_updates} 次月度图更新，{row.nonempty_graph_updates} 次非空，最大 {row.maximum_monthly_edges} 条边；评价 {row.first_target} 至 {row.last_target} 共 {row.observations} 期。')
    if table.nonempty_graph_updates.eq(0).all():
        lines.append('六个分支的全部历史估计图均为空。改变这三项图设置未产生可用的跨资产边；FULL 与 A0 的差异不能据此解释为跨资产风险传导贡献。')
    lines.extend(['', '新增比较按完整日期同步配对平稳区块 bootstrap 5000 次、平均区块 20、种子 20261012；每次重新计算 J=平均净收益−0.05×精确分数尾质量 ES95。区间为未校正 95% percentile，原 p 为中心化双侧加一修正，Holm 只作用于不同来源及不同日期的新增比较。', '所有来源、相同日期的原主账本副本和截取账本均保存在各分支 evaluation 目录；副本用于日期与来源核对，不表示独立实验。', '复现命令（最多两个面板进程并行，每个进程内部依次运行三项）：', 'python run.py -m scripts.run_graph_sensitivity --stage design', 'python run.py -m scripts.run_graph_sensitivity --panel repod --stage all', 'python run.py -m scripts.run_graph_sensitivity --panel japan --stage all', 'python run.py -m scripts.run_graph_sensitivity --stage report', '方法来源：Politis & Romano (1994), https://doi.org/10.1080/01621459.1994.10476870；Holm (1979), https://doi.org/10.2307/4615733。'])
    (OUTPUT / 'report.txt').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(table[columns].to_string(index=False, float_format=lambda value: f'{value:.8f}'))

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--panel', choices=PANELS)
    parser.add_argument('--setting', choices=[*SETTINGS, 'all'], default='all')
    parser.add_argument('--stage', choices=['design', 'graphs', 'evaluate', 'all', 'report'], default='all')
    args = parser.parse_args()
    if args.stage == 'design':
        record_design()
    elif args.stage == 'report':
        report()
    else:
        if args.panel is None:
            parser.error('--panel is required for graph estimation and evaluation')
        run_panel(args.panel, args.setting, args.stage)
if __name__ == '__main__':
    main()
