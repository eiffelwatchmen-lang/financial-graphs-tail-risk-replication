"""Mature-PIT t copula, common-reference tail scores, and sparse allocation LP."""
import numpy as np
from scipy import sparse
from scipy.optimize import linprog
from scipy.special import expit
from scipy.stats import t
from scripts.tail_distribution import ppf

def pit_correlation(pit_history, df=5, shrink=0.2, window=252):
    """Shrink the correlation of the latest complete, mature OOS PIT vectors.

    The caller supplies only PIT vectors whose target returns were observed at
    the signal date, with at least ``window`` such vectors available.
    """
    uniforms = np.clip(np.asarray(pit_history, dtype=float)[-window:], 0.0001, 0.9999)
    scores = t.ppf(uniforms, df)
    correlation = np.corrcoef(scores, rowvar=False)
    return (1 - shrink) * correlation + shrink * np.eye(scores.shape[1])

def copula_base_random(seed, scenario_count=10000, asset_count=3, df=5):
    """Draw once per signal date and share this pair across models/candidates."""
    rng = np.random.default_rng(seed)
    normals = rng.standard_normal((scenario_count, asset_count))
    chi_squares = rng.chisquare(df, size=scenario_count)
    return (normals, chi_squares)

def joint_scenarios(pit_history, loc, scale, df, base_random):
    """Sample truncated-t return margins through the fixed-df-5 t copula."""
    correlation = pit_correlation(pit_history)
    normals, chi_squares = base_random
    copula_scores = normals @ np.linalg.cholesky(correlation).T / np.sqrt(chi_squares[:, None] / 5)
    uniforms = t.cdf(copula_scores, df=5)
    return ppf(uniforms, loc, scale, df)

def equal_weight_var_es(scenarios, alpha=0.05):
    """Lower VaR and ES of equal-weight gross returns in decimal return units.

    VaR is the empirical inverse CDF. ES integrates exactly ``alpha`` of the
    empirical probability, including the fractional boundary observation.
    """
    ordered = np.sort(np.asarray(scenarios, dtype=float).mean(axis=1))
    mass = alpha * len(ordered)
    whole = int(np.floor(mass))
    fraction = mass - whole
    total = ordered[:whole].sum()
    if fraction > 0:
        total += fraction * ordered[whole]
    quantile = ordered[int(np.ceil(mass)) - 1]
    return (float(quantile), float(total / mass))

def fz_score(y, q, e, alpha=0.05):
    """Logistic/softplus FZ score; decimal return inputs become percentage points.

    All models must use the same equal-weight gross realized return ``y``.
    Lower scores are better, including when the lower-tail ES is positive.
    """
    y, q, e = (100 * np.asarray(value, dtype=float) for value in (y, q, e))
    return expit(e) * (e - q + (y <= q) * (q - y) / alpha) - np.logaddexp(0, e)

def solve_mean_cvar(scenarios, mu, knownweights, rates, alpha=0.05, kappa=0.05, cap=0.6):
    """Long-only mean-CVaR LP with additive estimated turnover costs.

    ``knownweights`` are the signal date's post-execution holdings. The shared
    mean forecast ``mu`` is supplied independently of the model's scenarios.
    Storage is linear in scenario count; scenario slacks use a sparse identity.
    """
    scenarios = np.asarray(scenarios, dtype=float)
    mu = np.asarray(mu, dtype=float)
    knownweights = np.asarray(knownweights, dtype=float)
    rates = np.asarray(rates, dtype=float)
    sample_count, asset_count = scenarios.shape
    variable_count = 2 * asset_count + sample_count + 1
    tail_start = asset_count + 1
    turnover_start = tail_start + sample_count
    objective = np.zeros(variable_count)
    objective[:asset_count] = -mu
    objective[asset_count] = kappa
    objective[tail_start:turnover_start] = kappa / (alpha * sample_count)
    objective[turnover_start:] = (1 + kappa) * rates
    asset_identity = sparse.eye(asset_count, format='csr')
    tail_constraints = sparse.hstack((sparse.csr_matrix(-scenarios), sparse.csr_matrix(-np.ones((sample_count, 1))), -sparse.eye(sample_count, format='csr'), sparse.csr_matrix((sample_count, asset_count))), format='csr')
    turnover_zeros = sparse.csr_matrix((asset_count, sample_count + 1))
    buy_constraints = sparse.hstack((asset_identity, turnover_zeros, -asset_identity), format='csr')
    sell_constraints = sparse.hstack((-asset_identity, turnover_zeros, -asset_identity), format='csr')
    inequality = sparse.vstack((tail_constraints, buy_constraints, sell_constraints), format='csr')
    rhs = np.concatenate((np.zeros(sample_count), knownweights, -knownweights))
    equality = sparse.csr_matrix((np.ones(asset_count), (np.zeros(asset_count, dtype=int), np.arange(asset_count))), shape=(1, variable_count))
    result = linprog(objective, A_ub=inequality, b_ub=rhs, A_eq=equality, b_eq=[1.0], bounds=[(0, cap)] * asset_count + [(None, None)] + [(0, None)] * (sample_count + asset_count), method='highs')
    if not result.success:
        raise RuntimeError(f'Mean-CVaR optimization failed: {result.message}')
    return result.x[:asset_count]
