"""Replay the predefined development period, then select graph penalties."""
import argparse
import itertools
import json
from pathlib import Path
import time
import numpy as np
import pandas as pd
from scripts.graph_predictor import predict, train
from scripts.joint_risk import copula_base_random, equal_weight_var_es, fz_score, joint_scenarios, solve_mean_cvar
from scripts.prepare_features import price_features
from scripts.tail_distribution import cdf, lower_tail_es, ppf
from scripts.tail_graph import fit_month
ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / 'outputs/development_graph'

def candidate_directory(lambda1, lambda2):
    return OUTPUT / f'l1_{lambda1:g}_l2_{lambda2:g}'.replace('.', 'p')

def load_panel(config, panel_name='repod', phase='validation'):
    panel = config['panels'][panel_name]
    prices = pd.read_csv(ROOT / f'data/processed/{panel_name}/prices.csv', index_col='date', parse_dates=True)
    prices = prices.loc[:panel[f'{phase}_end'], panel['assets']]
    feature_frame = price_features(prices).reindex(prices.index)
    features = np.stack([feature_frame.xs(asset, axis=1, level='asset')[config['features']['names']].to_numpy() for asset in panel['assets']], axis=1)
    returns = prices.pct_change(fill_method=None)
    predictor = config['predictor']
    locations = predictor['mean_multiplier'] * returns.rolling(predictor['mean_window']).mean().to_numpy()
    schedule = pd.read_csv(ROOT / f'outputs/{panel_name}_availability.csv', parse_dates=['date'])
    update_dates = set(schedule.loc[schedule.graph_refit, 'date'])
    updates = [i for i, date in enumerate(prices.index[:-config['timing']['target_lag']]) if date in update_dates]
    return (prices.index, returns, features, locations, updates)

def load_development(config):
    return load_panel(config)

def build_graphs(config, lambda1, lambda2, directory, *, panel_name='repod', phase='validation'):
    dates, returns, features, _, updates = load_panel(config, panel_name, phase)
    directory.mkdir(parents=True, exist_ok=True)
    adjacency = np.zeros((len(dates), features.shape[1], features.shape[1]))
    graph_cutoff = np.full(len(dates), -1)
    saved = {key: [] for key in ['coefficients_standardized', 'coefficients_raw', 'feature_mean', 'feature_scale', 'sign_stability']}
    previous = None
    logs = []
    begin = time.perf_counter()
    for j, cutoff in enumerate(updates):
        tick = time.perf_counter()
        seed = config['seed'] + int(dates[cutoff].strftime('%Y%m%d'))
        fitted = fit_month(features, returns.to_numpy(), cutoff, previous, lambda1, lambda2, config, seed)
        next_cutoff = updates[j + 1] if j + 1 < len(updates) else len(dates)
        adjacency[cutoff:next_cutoff] = fitted['adjacency']
        graph_cutoff[cutoff:next_cutoff] = cutoff
        for key in saved:
            saved[key].append(fitted[key])
        logs.append({'update_date': dates[cutoff], 'first_signal': dates[fitted['signal_indices'][0]], 'last_signal': dates[fitted['signal_indices'][-1]], 'last_mature_target': dates[fitted['target_indices'][-1]], 'samples': fitted['n_samples'], 'bootstrap_seed': seed, 'edges': int(np.count_nonzero(fitted['adjacency'])), 'seconds': time.perf_counter() - tick})
        previous = fitted
        if (j + 1) % 10 == 0 or j + 1 == len(updates):
            print(f'{directory.name}: graphs {j + 1}/{len(updates)}, {time.perf_counter() - begin:.1f}s', flush=True)
    np.savez_compressed(directory / 'graphs.npz', adjacency=adjacency, graph_cutoff=graph_cutoff, update_indices=updates, **{key: np.stack(value) for key, value in saved.items()})
    pd.DataFrame(logs).to_csv(directory / 'graph_updates.csv', index=False)
    (directory / 'settings.json').write_text(json.dumps({'lambda1': lambda1, 'lambda2': lambda2, 'panel': panel_name, 'phase': phase, 'protocol': config}, ensure_ascii=False, indent=2), encoding='utf-8')

def replay_forecasts(config, directory, models=('FULL', 'A0'), *, panel_name='repod', phase='validation'):
    dates, returns, features, locations, _ = load_panel(config, panel_name, phase)
    graph_archive = np.load(directory / 'graphs.npz')
    graphs = graph_archive['adjacency']
    graph_cutoff = graph_archive['graph_cutoff']
    updates = set(graph_archive['update_indices'].tolist())
    first_graph = int(np.flatnonzero(graph_cutoff >= 0)[0])
    lag = config['timing']['target_lag']
    training = config['predictor']
    values = returns.to_numpy()
    for model in models:
        network = 'A0' if model == 'A0' else 'FULL'
        scales = np.full_like(values, np.nan)
        degrees = np.full(len(dates), np.nan)
        model_cutoff = np.full(len(dates), -1)
        fitted = None
        checkpoints, logs = ([], [])
        begin = time.perf_counter()
        for signal in range(first_graph, len(dates) - lag):
            samples = np.arange(max(first_graph, signal - lag - training['max_samples'] + 1), signal - lag + 1)
            if signal in updates and len(samples) >= training['min_samples']:
                fitted = train(features[samples], graphs[samples], locations[samples], values[samples + lag], network, training, config['seed'])
                last_fit = signal
                checkpoints.append((signal, fitted['theta'], fitted['feature_mean'], fitted['feature_scale']))
                logs.append({'model': model, 'update_date': dates[signal], 'first_training_signal': dates[samples[0]], 'last_training_signal': dates[samples[-1]], 'last_training_target': dates[samples[-1] + lag], 'samples': len(samples), 'parameters': 92, 'optimizer_steps': fitted['optimizer_steps'], 'training_nll': fitted['training_nll']})
                if len(checkpoints) % 8 == 0:
                    print(f'{directory.name} {model}: {len(checkpoints)} monthly fits, {time.perf_counter() - begin:.1f}s', flush=True)
            if fitted is not None:
                predicted_scale, df = predict(fitted, features[signal:signal + 1], graphs[signal:signal + 1], network)
                scales[signal] = predicted_scale[0]
                degrees[signal] = df
                model_cutoff[signal] = last_fit
        valid = np.flatnonzero(np.isfinite(degrees))
        pit = np.full_like(values, np.nan)
        pit[valid] = cdf(values[valid + lag], locations[valid], scales[valid], degrees[valid, None])
        q = ppf(config['portfolio']['tail_probability'], locations[valid], scales[valid], degrees[valid, None])
        es = lower_tail_es(config['portfolio']['tail_probability'], locations[valid], scales[valid], degrees[valid, None])
        rows = []
        for row, signal in enumerate(valid):
            for asset, name in enumerate(returns.columns):
                rows.append({'signal_date': dates[signal], 'target_date': dates[signal + lag], 'asset': name, 'model_fit_date': dates[model_cutoff[signal]], 'graph_fit_date': dates[graph_cutoff[signal]], 'location': locations[signal, asset], 'scale': scales[signal, asset], 'df': degrees[signal], 'var05_return': q[row, asset], 'es05_return': es[row, asset], 'realized_return': values[signal + lag, asset], 'pit': pit[signal, asset]})
        pd.DataFrame(rows).to_csv(directory / f'{model}_forecasts.csv', index=False)
        pd.DataFrame(logs).to_csv(directory / f'{model}_training.csv', index=False)
        np.savez_compressed(directory / f'{model}_forecasts.npz', scales=scales, df=degrees, location=locations, pit=pit, signal_indices=valid, model_cutoff=model_cutoff, checkpoint_indices=np.array([x[0] for x in checkpoints]), theta=np.stack([x[1] for x in checkpoints]), feature_mean=np.stack([x[2] for x in checkpoints]), feature_scale=np.stack([x[3] for x in checkpoints]))
        print(f'{directory.name} {model}: saved {len(valid)} OOS forecast vectors in {time.perf_counter() - begin:.1f}s', flush=True)

def scenarios_at(signal, dates, forecast, config):
    mature = forecast['signal_indices'][forecast['signal_indices'] + config['timing']['target_lag'] <= signal]
    history = forecast['pit'][mature[-config['copula']['pit_samples']:]]
    seed = config['seed'] + int(dates[signal].strftime('%Y%m%d'))
    base = copula_base_random(seed, config['copula']['scenarios'], forecast['scales'].shape[1])
    return joint_scenarios(history, forecast['location'][signal], forecast['scales'][signal], forecast['df'][signal], base)

def score_forecasts(config, directory, models=('FULL', 'A0'), *, panel_name='repod', phase='validation'):
    dates, returns, _, _, _ = load_panel(config, panel_name, phase)
    panel = config['panels'][panel_name]
    lag = config['timing']['target_lag']
    settings = json.loads((directory / 'settings.json').read_text(encoding='utf-8'))
    graphs = np.load(directory / 'graphs.npz')['adjacency']
    summaries = []
    for model in models:
        forecast = np.load(directory / f'{model}_forecasts.npz')
        rows = []
        begin = time.perf_counter()
        for signal in forecast['signal_indices']:
            target = signal + lag
            mature_n = int((forecast['signal_indices'] + lag <= signal).sum())
            if dates[target] < pd.Timestamp(panel[f'{phase}_start']) or mature_n < config['copula']['pit_samples']:
                continue
            if phase == 'test' and dates[signal] < pd.Timestamp(config['confirmation']['first_signal_not_before']):
                continue
            scenarios = scenarios_at(signal, dates, forecast, config)
            q, es = equal_weight_var_es(scenarios, config['portfolio']['tail_probability'])
            y = float(returns.iloc[target].mean())
            rows.append({'signal_date': dates[signal], 'target_date': dates[target], 'mature_pit_vectors': mature_n, 'last_pit_target': dates[forecast['signal_indices'][forecast['signal_indices'] + lag <= signal][-1] + lag], 'equal_weight_gross_return': y, 'var05_return': q, 'es05_return': es, 'fz': float(fz_score(y, q, es, config['portfolio']['tail_probability'])), 'var_breach': int(y <= q), 'graph_edges': int(np.count_nonzero(graphs[signal]))})
            if len(rows) % 100 == 0:
                print(f'{directory.name} {model}: scored {len(rows)} signals, {time.perf_counter() - begin:.1f}s', flush=True)
        scores = pd.DataFrame(rows)
        scores.to_csv(directory / f'{model}_scores.csv', index=False)
        all_pit = forecast['pit'][dates.get_indexer(scores.signal_date)]
        summary = {'model': model, 'lambda1': settings['lambda1'], 'lambda2': settings['lambda2'], 'observations': len(scores), 'mean_fz': scores.fz.mean(), 'var_coverage': scores.var_breach.mean(), 'mean_graph_edges': scores.graph_edges.mean(), 'pit_boundary_fraction': float(((all_pit < 0.0001) | (all_pit > 0.9999)).mean()), 'elapsed_seconds': time.perf_counter() - begin}
        summaries.append(summary)
        print(f"{directory.name} {model}: mean FZ {summary['mean_fz']:.8f}", flush=True)
    pd.DataFrame(summaries).to_csv(directory / 'prediction_summary.csv', index=False)

def run_portfolios(config, directory, models=('FULL', 'A0'), *, panel_name='repod', phase='validation'):
    from scripts.baselines import backtest, summarize
    dates, returns, _, _, _ = load_panel(config, panel_name, phase)
    panel, settings = (config['panels'][panel_name], config['portfolio'])
    results = []
    for model in models:
        forecast = np.load(directory / f'{model}_forecasts.npz')
        scores = pd.read_csv(directory / f'{model}_scores.csv', parse_dates=['target_date'])
        start, end = (scores.target_date.min(), scores.target_date.max())
        begin = time.perf_counter()
        count = 0

        def strategy(signal, knownweights):
            nonlocal count
            scenarios = scenarios_at(signal, dates, forecast, config)
            weights = solve_mean_cvar(scenarios, forecast['location'][signal], knownweights, panel['cost_rates'], settings['tail_probability'], settings['kappa'], settings['weight_cap'])
            count += 1
            if count % 100 == 0:
                print(f'{directory.name} {model}: optimized {count} signals, {time.perf_counter() - begin:.1f}s', flush=True)
            return weights
        ledger = backtest(returns, model, start, end, rates=panel['cost_rates'], cap=settings['weight_cap'], strategy=strategy, execution_lag=config['timing']['execution_lag'])
        ledger.to_csv(directory / f'{model}_ledger.csv', index=False)
        result = summarize(ledger, settings['kappa'], settings['tail_probability'])
        result['elapsed_seconds'] = time.perf_counter() - begin
        results.append(result)
        print(f"{directory.name} {model}: {phase} J={result['J_daily_bp']:.4f} bp/day", flush=True)
    pd.DataFrame(results).to_csv(directory / 'portfolio_summary.csv', index=False)

def select_candidate(config):
    rows = []
    for lambda1, lambda2 in itertools.product(config['graph']['lambda1_candidates'], config['graph']['lambda2_candidates']):
        directory = candidate_directory(lambda1, lambda2)
        row = pd.read_csv(directory / 'prediction_summary.csv').query("model == 'FULL'").iloc[0].to_dict()
        row['candidate'] = directory.name
        rows.append(row)
    result = pd.DataFrame(rows).sort_values(['mean_fz', 'mean_graph_edges', 'lambda1', 'lambda2'])
    result.to_csv(OUTPUT / 'candidate_scores.csv', index=False)
    winner = result.iloc[0].to_dict()
    winner['selection_rule'] = 'Minimum development equal-weight gross-return FZ; ties use fewer mean active edges.'
    chosen = OUTPUT / winner['candidate']
    chosen_graphs = np.load(chosen / 'graphs.npz')
    winner['all_monthly_graphs_empty'] = bool(np.count_nonzero(chosen_graphs['adjacency']) == 0)
    a0 = pd.read_csv(chosen / 'prediction_summary.csv').query("model == 'A0'").iloc[0]
    winner['a0_mean_fz'] = float(a0.mean_fz)
    winner['full_minus_a0_mean_fz'] = float(winner['mean_fz'] - a0.mean_fz)
    winner['confirmation_frozen'] = False
    (OUTPUT / 'selected_candidate.json').write_text(json.dumps(winner, ensure_ascii=False, indent=2), encoding='utf-8')
    print(result[['candidate', 'mean_fz', 'mean_graph_edges']].to_string(index=False), flush=True)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--stage', choices=['graphs', 'forecasts', 'scores', 'portfolios', 'pipeline', 'grid', 'select'], default='pipeline')
    parser.add_argument('--lambda1', type=float, default=0.02)
    parser.add_argument('--lambda2', type=float, default=0.005)
    args = parser.parse_args()
    config = json.loads((ROOT / 'configs/protocol.json').read_text(encoding='utf-8'))
    candidates = list(itertools.product(config['graph']['lambda1_candidates'], config['graph']['lambda2_candidates'])) if args.stage == 'grid' else [(args.lambda1, args.lambda2)]
    for lambda1, lambda2 in candidates:
        directory = candidate_directory(lambda1, lambda2)
        if args.stage in ['graphs', 'pipeline', 'grid']:
            build_graphs(config, lambda1, lambda2, directory)
        if args.stage in ['forecasts', 'pipeline', 'grid']:
            replay_forecasts(config, directory)
        if args.stage in ['scores', 'pipeline', 'grid']:
            score_forecasts(config, directory)
        if args.stage == 'portfolios':
            run_portfolios(config, directory)
    if args.stage in ['grid', 'select']:
        select_candidate(config)
if __name__ == '__main__':
    main()
