"""Monthly sparse tail-risk graphs with synchronized stationary bootstrap.

The target is -r[s+2] / vol60[s], so its scale is already fixed by historical
volatility. Only explanatory variables are standardized. Temporal penalties
use last month's point estimate expressed in the current training scaler;
neither sparsity nor temporal smoothing penalizes the intercept.
"""
import numpy as np
from scipy import sparse
from scipy.optimize import linprog

def standardized_to_raw(coefficients, mean, scale):
    """Express a standardized linear predictor in original feature units."""
    slopes = coefficients[..., 1:] / scale
    intercept = coefficients[..., 0] - np.sum(slopes * mean, axis=-1)
    return np.concatenate((intercept[..., None], slopes), axis=-1)

def raw_to_standardized(coefficients, mean, scale):
    """Change predictor coordinates without changing its fitted values."""
    intercept = coefficients[..., 0] + np.sum(coefficients[..., 1:] * mean, axis=-1)
    slopes = coefficients[..., 1:] * scale
    return np.concatenate((intercept[..., None], slopes), axis=-1)

def stationary_bootstrap_indices(n_samples, repetitions, mean_block, rng):
    """Draw circular stationary-bootstrap rows, shared by every asset."""
    indices = np.empty((repetitions, n_samples), dtype=np.int64)
    indices[:, 0] = rng.integers(n_samples, size=repetitions)
    restart = rng.random((repetitions, n_samples - 1)) < 1.0 / mean_block
    new_starts = rng.integers(n_samples, size=(repetitions, n_samples - 1))
    for row in range(1, n_samples):
        indices[:, row] = np.where(restart[:, row - 1], new_starts[:, row - 1], (indices[:, row - 1] + 1) % n_samples)
    return indices

def quantile_regression(design, target, quantile, lambda1, lambda2, previous=None):
    """Solve mean pinball loss plus L1 sparsity and L1 temporal smoothing."""
    n, p = design.shape
    n_slopes = p - 1
    temporal = previous is not None
    n_variables = p + 2 * n + n_slopes * (1 + temporal)
    objective = np.zeros(n_variables)
    objective[p:p + n] = quantile / n
    objective[p + n:p + 2 * n] = (1 - quantile) / n
    objective[p + 2 * n:p + 2 * n + n_slopes] = lambda1
    if temporal:
        objective[-n_slopes:] = lambda2
    equality = sparse.hstack((sparse.csr_matrix(design), sparse.eye(n), -sparse.eye(n), sparse.csr_matrix((n, n_slopes * (1 + temporal)))), format='csr')
    slope_selector = sparse.hstack((sparse.csr_matrix((n_slopes, 1)), sparse.eye(n_slopes)), format='csr')
    residual_zeros = sparse.csr_matrix((n_slopes, 2 * n))
    penalty_identity = sparse.eye(n_slopes)
    tail_zeros = sparse.csr_matrix((n_slopes, n_slopes * temporal))
    constraints = [sparse.hstack((slope_selector, residual_zeros, -penalty_identity, tail_zeros)), sparse.hstack((-slope_selector, residual_zeros, -penalty_identity, tail_zeros))]
    bounds_rhs = [np.zeros(2 * n_slopes)]
    if temporal:
        penalty_zeros = sparse.csr_matrix((n_slopes, n_slopes))
        constraints.extend((sparse.hstack((slope_selector, residual_zeros, penalty_zeros, -penalty_identity)), sparse.hstack((-slope_selector, residual_zeros, penalty_zeros, -penalty_identity))))
        bounds_rhs.extend((previous[1:], -previous[1:]))
    solution = linprog(objective, A_ub=sparse.vstack(constraints, format='csr'), b_ub=np.concatenate(bounds_rhs), A_eq=equality, b_eq=target, bounds=[(None, None)] * p + [(0, None)] * (n_variables - p), method='highs')
    if not solution.success:
        raise RuntimeError(f'Tail-graph quantile regression failed: {solution.message}')
    return solution.x[:p]

def fit_month(features, returns, cutoff, previous_fit, lambda1, lambda2, config, seed):
    """Fit one graph using only targets observed by ``cutoff``.

    Arrays share the complete price-date axis. Features have shape [T,N,F]
    in config.features.names order; returns have shape [T,N]. Leading feature
    warmup rows may contain NaN. Coefficient columns are intercept, own
    controls, then the other assets' downside shocks in asset-index order.
    adjacency[target, source] retains each stabilized cross coefficient's sign.
    """
    graph = config['graph']
    feature_names = config['features']['names']
    lag = config['timing']['target_lag']
    signal_indices = np.arange(cutoff - lag + 1)
    complete = np.isfinite(features[signal_indices]).all(axis=(1, 2)) & np.isfinite(returns[signal_indices + lag]).all(axis=1)
    signal_indices = signal_indices[complete][-graph['max_samples']:]
    n_samples = len(signal_indices)
    if n_samples < graph['min_samples']:
        raise ValueError(f"Graph needs {graph['min_samples']} mature rows; found {n_samples}.")
    n_assets = features.shape[1]
    controls = [feature_names.index(name) for name in graph['own_controls']]
    shock = feature_names.index(graph['cross_predictor'])
    vol60 = feature_names.index('vol_60')
    sample = features[signal_indices]
    source_assets = np.array([[source for source in range(n_assets) if source != target] for target in range(n_assets)])
    predictors = np.stack([np.column_stack((sample[:, target, controls], sample[:, sources, shock])) for target, sources in enumerate(source_assets)])
    mean = predictors.mean(axis=1)
    scale = predictors.std(axis=1, ddof=0)
    scale[scale == 0] = 1.0
    standardized = (predictors - mean[:, None, :]) / scale[:, None, :]
    design = np.concatenate((np.ones((n_assets, n_samples, 1)), standardized), axis=2)
    targets = (-returns[signal_indices + lag] / np.maximum(sample[:, :, vol60], config['features']['scale_floor'])).T
    previous = None if previous_fit is None else raw_to_standardized(previous_fit['coefficients_raw'], mean, scale)
    coefficients = np.stack([quantile_regression(design[target], targets[target], graph['quantile'], lambda1, lambda2, None if previous is None else previous[target]) for target in range(n_assets)])
    indices = stationary_bootstrap_indices(n_samples, graph['bootstrap_repetitions'], graph['block_length'], np.random.default_rng(seed))
    bootstrap_coefficients = np.empty((len(indices), *coefficients.shape))
    for repetition, rows in enumerate(indices):
        for target in range(n_assets):
            bootstrap_coefficients[repetition, target] = quantile_regression(design[target, rows], targets[target, rows], graph['quantile'], lambda1, lambda2, None if previous is None else previous[target])
    cross_start = 1 + len(controls)
    cross = coefficients[:, cross_start:]
    bootstrap_cross = bootstrap_coefficients[:, :, cross_start:]
    tolerance = graph['zero_tolerance']
    same_nonzero_sign = (np.sign(bootstrap_cross) == np.sign(cross)[None, :, :]) & (np.abs(bootstrap_cross) > tolerance) & (np.abs(cross)[None, :, :] > tolerance)
    stability = same_nonzero_sign.mean(axis=0)
    adjacency = np.zeros((n_assets, n_assets))
    sign_stability = np.zeros_like(adjacency)
    for target, sources in enumerate(source_assets):
        adjacency[target, sources] = cross[target] * stability[target]
        sign_stability[target, sources] = stability[target]
    return {'coefficients_standardized': coefficients, 'coefficients_raw': standardized_to_raw(coefficients, mean, scale), 'feature_mean': mean, 'feature_scale': scale, 'previous_coefficients_standardized': previous, 'adjacency': adjacency, 'sign_stability': sign_stability, 'source_assets': source_assets, 'signal_indices': signal_indices, 'target_indices': signal_indices + lag, 'cutoff': int(cutoff), 'n_samples': n_samples, 'lambda1': lambda1, 'lambda2': lambda2, 'temporal_penalty_active': previous is not None, 'bootstrap_indices': indices, 'bootstrap_coefficients_standardized': bootstrap_coefficients, 'bootstrap_seed': seed, 'bootstrap_repetitions': graph['bootstrap_repetitions'], 'bootstrap_mean_block': graph['block_length']}
