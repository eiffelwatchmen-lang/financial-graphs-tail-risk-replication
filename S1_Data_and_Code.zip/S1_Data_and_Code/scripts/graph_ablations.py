"""Graph mechanism ablations preserving the original signal-date history."""
from itertools import permutations
import numpy as np
import pandas as pd

def nonidentity_permutations(asset_count):
    """Enumerate each distinct nonidentity node permutation exactly once."""
    identity = tuple(range(asset_count))
    return [order for order in permutations(identity) if order != identity]

def transform_graphs(archive, dates, variant, static_cutoffs, permutation=None, zero_tolerance=1e-06, own_control_count=3):
    """Return (adjacency, actual estimation cutoff indices) for an ablation.

    Matrices use [target, source]. A1 cutoffs are calendar dates within the
    supplied history or in its future; each freezes the latest graph available
    by that date without changing earlier graphs. A4 transforms only adjacency,
    leaving asset features in their original order.
    """
    original = archive['adjacency']
    adjacency = original.copy()
    cutoff_index = archive['graph_cutoff'].copy()
    if variant == 'FULL':
        return (adjacency, cutoff_index)
    if variant == 'A1':
        dates = pd.DatetimeIndex(dates)
        for cutoff in sorted((pd.Timestamp(value) for value in static_cutoffs)):
            if cutoff > dates[-1]:
                continue
            anchor = int(dates.searchsorted(cutoff, side='right') - 1)
            adjacency[anchor:] = original[anchor]
            cutoff_index[anchor:] = archive['graph_cutoff'][anchor]
    elif variant == 'A2':
        adjacency = (original + original.swapaxes(1, 2)) / 2
    elif variant == 'A3':
        adjacency = np.zeros_like(original)
        updates = archive['update_indices']
        asset_count = original.shape[1]
        cross = archive['coefficients_standardized'][..., 1 + own_control_count:]
        cross = np.where(np.abs(cross) > zero_tolerance, cross, 0.0)
        for month, start in enumerate(updates):
            end = updates[month + 1] if month + 1 < len(updates) else len(original)
            point_graph = np.zeros((asset_count, asset_count))
            for target in range(asset_count):
                sources = [source for source in range(asset_count) if source != target]
                point_graph[target, sources] = cross[month, target]
            adjacency[start:end] = point_graph
    elif variant == 'A4':
        order = np.asarray(permutation)
        adjacency = original[:, order][:, :, order]
    else:
        raise ValueError(f'Unknown graph ablation: {variant}')
    return (adjacency, cutoff_index)
