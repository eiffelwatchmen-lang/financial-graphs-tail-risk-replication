"""Run the frozen experiment separately in each confirmation panel."""
import argparse
import json
from pathlib import Path
import time
import pandas as pd
from scripts.baselines import backtest, summarize
from scripts.joint_risk import equal_weight_var_es, fz_score
from scripts.run_graph_development import build_graphs, load_panel, replay_forecasts, score_forecasts, run_portfolios
from scripts import run_m4_development as m4
ROOT = Path(__file__).resolve().parents[1]

def run_baselines(config, panel_name, directory):
    panel, portfolio = (config['panels'][panel_name], config['portfolio'])
    dates, returns, _, _, _ = load_panel(config, panel_name, 'test')
    reference = pd.read_csv(directory / 'graph/FULL_scores.csv', parse_dates=['target_date'])
    start, end = (reference.target_date.min(), reference.target_date.max())
    output = directory / 'baselines'
    output.mkdir(parents=True, exist_ok=True)
    results = []
    for model in ['M0', 'M1', 'M2', 'M3']:
        begin = time.perf_counter()
        ledger = backtest(returns, model, start, end, rates=panel['cost_rates'], cap=portfolio['weight_cap'], alpha=portfolio['tail_probability'], kappa=portfolio['kappa'], shrink=portfolio['m2_diagonal_shrinkage'])
        ledger.to_csv(output / f'{model}_ledger.csv', index=False)
        result = summarize(ledger, portfolio['kappa'], portfolio['tail_probability'])
        result['elapsed_seconds'] = time.perf_counter() - begin
        results.append(result)
        print(f'{panel_name} {model}: {len(ledger)} test targets', flush=True)
    pd.DataFrame(results).to_csv(output / 'portfolio_summary.csv', index=False)
    rows = []
    window, alpha = (portfolio['m3_history_window'], portfolio['tail_probability'])
    for record in ledger.itertuples():
        signal = dates.get_loc(record.signal_date)
        q, es = equal_weight_var_es(returns.iloc[signal - window + 1:signal + 1].to_numpy(), alpha)
        y = float(returns.loc[record.target_date].mean())
        rows.append({'signal_date': record.signal_date, 'target_date': record.target_date, 'equal_weight_gross_return': y, 'var05_return': q, 'es05_return': es, 'fz': float(fz_score(y, q, es, alpha)), 'var_breach': int(y <= q)})
    scores = pd.DataFrame(rows)
    scores.to_csv(output / 'M3_scores.csv', index=False)
    pd.DataFrame([{'model': 'M3', 'observations': len(scores), 'mean_fz': scores.fz.mean(), 'var_coverage': scores.var_breach.mean()}]).to_csv(output / 'prediction_summary.csv', index=False)
    options = {'panel_name': panel_name, 'phase': 'test'}
    m4.replay_forecasts(config, directory / 'm4', **options)
    m4.score_forecasts(config, directory / 'm4', **options)
    m4.run_portfolio(config, directory / 'm4', **options)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--panel', choices=['repod', 'japan'], required=True)
    parser.add_argument('--stage', choices=['graphs', 'forecasts', 'scores', 'portfolios', 'baselines', 'ablations', 'main', 'all'], default='all')
    args = parser.parse_args()
    config = json.loads((ROOT / 'configs/frozen_protocol.json').read_text(encoding='utf-8'))
    directory = ROOT / 'outputs/confirmation' / args.panel
    graph_directory = directory / 'graph'
    options = {'panel_name': args.panel, 'phase': 'test'}
    if args.stage in ['graphs', 'main', 'all']:
        build_graphs(config, config['graph']['selected_lambda1'], config['graph']['selected_lambda2'], graph_directory, **options)
    if args.stage in ['forecasts', 'main', 'all']:
        replay_forecasts(config, graph_directory, **options)
    if args.stage in ['scores', 'main', 'all']:
        score_forecasts(config, graph_directory, **options)
    if args.stage in ['portfolios', 'main', 'all']:
        run_portfolios(config, graph_directory, **options)
    if args.stage in ['baselines', 'main', 'all']:
        run_baselines(config, args.panel, directory)
    if args.stage in ['ablations', 'all']:
        from scripts.run_graph_ablations import run_ablations
        run_ablations(config, graph_directory, directory / 'ablations', **options)
if __name__ == '__main__':
    main()
