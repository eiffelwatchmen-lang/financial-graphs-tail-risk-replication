"""Replay the fixed t-GARCH/DCC baseline on development data only."""
import argparse
import json
from pathlib import Path
import time
import numpy as np
import pandas as pd
from scipy.stats import t
from scripts.baselines import backtest, summarize
from scripts.dcc import fit_dcc, forecast_correlation
from scripts.garch_t import fit_garch, forecast_variance
from scripts.joint_risk import copula_base_random, equal_weight_var_es, fz_score, solve_mean_cvar
from scripts.run_graph_development import load_panel
from scripts.tail_distribution import cdf, lower_tail_es, ppf
ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / 'outputs/development_m4'

def replay_forecasts(config, directory, *, panel_name='repod', phase='validation'):
    dates, returns, _, locations, updates = load_panel(config, panel_name, phase)
    values = returns.to_numpy()
    lag = config['timing']['target_lag']
    residuals = np.full_like(values, np.nan)
    residuals[lag:] = values[lag:] - locations[:-lag]
    first_residual = int(np.flatnonzero(np.isfinite(residuals).all(axis=1))[0])
    settings = config['m4']
    update_set = set(updates)
    directory.mkdir(parents=True, exist_ok=True)
    (directory / 'settings.json').write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding='utf-8')
    scales, degrees, variance1, variance2 = [np.full_like(values, np.nan) for _ in range(4)]
    correlations = np.full((len(dates), values.shape[1], values.shape[1]), np.nan)
    model_cutoff = np.full(len(dates), -1)
    checkpoints, garch_logs, dcc_logs = ([], [], [])
    fitted = False
    begin = time.perf_counter()
    for signal in range(first_residual, len(dates) - lag):
        samples = np.arange(max(first_residual, signal - settings['max_samples'] + 1), signal + 1)
        if signal in update_set and len(samples) >= settings['min_samples']:
            models = [fit_garch(residuals[samples, asset]) for asset in range(values.shape[1])]
            params = np.stack([model['params'] for model in models])
            history_variance = np.column_stack([model['variance'] for model in models])
            standardized = residuals[samples] / np.sqrt(history_variance)
            dcc = fit_dcc(standardized)
            h_current = history_variance[-1].copy()
            q_current = dcc['q_last'].copy()
            qbar = dcc['qbar']
            dcc_params = dcc['params']
            last_fit = signal
            fitted = True
            checkpoints.append((signal, params.copy(), dcc_params.copy(), qbar.copy()))
            for asset, model in enumerate(models):
                garch_logs.append({'update_date': dates[signal], 'asset': returns.columns[asset], 'first_training_target': dates[samples[0]], 'last_training_target': dates[samples[-1]], 'samples': len(samples), 'omega': params[asset, 0], 'alpha': params[asset, 1], 'beta': params[asset, 2], 'df': params[asset, 3], 'nll': model['nll'], 'iterations': model['iterations']})
            dcc_logs.append({'update_date': dates[signal], 'samples': len(samples), 'a': dcc_params[0], 'b': dcc_params[1], 'nll': dcc['nll'], 'iterations': dcc['iterations']})
            print(f'M4: fitted {len(checkpoints)} months through {dates[signal].date()}, {time.perf_counter() - begin:.1f}s', flush=True)
        elif fitted:
            z_previous = residuals[signal - 1] / np.sqrt(h_current)
            a, b = dcc_params
            q_current = (1 - a - b) * qbar + a * np.outer(z_previous, z_previous) + b * q_current
            h_current = params[:, 0] + params[:, 1] * residuals[signal - 1] ** 2 + params[:, 2] * h_current
        if fitted:
            h1, h2 = np.array([forecast_variance(params[asset], h_current[asset], residuals[signal, asset]) for asset in range(values.shape[1])]).T
            _, correlation2 = forecast_correlation(dcc_params, qbar, q_current, residuals[signal] / np.sqrt(h_current))
            degrees[signal] = params[:, 3]
            scales[signal] = np.sqrt(h2 * (degrees[signal] - 2) / degrees[signal])
            variance1[signal], variance2[signal] = (h1, h2)
            correlations[signal] = correlation2
            model_cutoff[signal] = last_fit
    valid = np.flatnonzero(model_cutoff >= 0)
    pit = np.full_like(values, np.nan)
    pit[valid] = cdf(values[valid + lag], locations[valid], scales[valid], degrees[valid])
    alpha = config['portfolio']['tail_probability']
    quantiles = ppf(alpha, locations[valid], scales[valid], degrees[valid])
    expected_shortfall = lower_tail_es(alpha, locations[valid], scales[valid], degrees[valid])
    rows = []
    for row, signal in enumerate(valid):
        for asset, name in enumerate(returns.columns):
            rows.append({'signal_date': dates[signal], 'target_date': dates[signal + lag], 'asset': name, 'model_fit_date': dates[model_cutoff[signal]], 'location': locations[signal, asset], 'scale': scales[signal, asset], 'df': degrees[signal, asset], 'underlying_variance_h1': variance1[signal, asset], 'underlying_variance_h2': variance2[signal, asset], 'var05_return': quantiles[row, asset], 'es05_return': expected_shortfall[row, asset], 'realized_return': values[signal + lag, asset], 'pit': pit[signal, asset]})
    pd.DataFrame(rows).to_csv(directory / 'M4_forecasts.csv', index=False)
    pd.DataFrame(garch_logs).to_csv(directory / 'M4_garch_training.csv', index=False)
    pd.DataFrame(dcc_logs).to_csv(directory / 'M4_dcc_training.csv', index=False)
    np.savez_compressed(directory / 'M4_forecasts.npz', scales=scales, df=degrees, location=locations, pit=pit, variance_h1=variance1, variance_h2=variance2, correlations=correlations, signal_indices=valid, model_cutoff=model_cutoff, checkpoint_indices=np.array([item[0] for item in checkpoints]), garch_params=np.stack([item[1] for item in checkpoints]), dcc_params=np.stack([item[2] for item in checkpoints]), dcc_qbar=np.stack([item[3] for item in checkpoints]))
    print(f'M4: saved {len(valid)} OOS forecast vectors', flush=True)

def scenarios_at(signal, dates, forecast, config):
    seed = config['seed'] + int(dates[signal].strftime('%Y%m%d'))
    copula_df = config['m4']['copula_df']
    normals, chi_squares = copula_base_random(seed, config['copula']['scenarios'], forecast['scales'].shape[1], copula_df)
    scores = normals @ np.linalg.cholesky(forecast['correlations'][signal]).T / np.sqrt(chi_squares[:, None] / copula_df)
    uniforms = t.cdf(scores, copula_df)
    return ppf(uniforms, forecast['location'][signal], forecast['scales'][signal], forecast['df'][signal])

def score_forecasts(config, directory, *, panel_name='repod', phase='validation'):
    dates, returns, _, _, _ = load_panel(config, panel_name, phase)
    panel, portfolio = (config['panels'][panel_name], config['portfolio'])
    lag = config['timing']['target_lag']
    forecast = np.load(directory / 'M4_forecasts.npz')
    rows = []
    begin = time.perf_counter()
    for signal in forecast['signal_indices']:
        target = signal + lag
        if dates[target] < pd.Timestamp(panel[f'{phase}_start']):
            continue
        if phase == 'test' and dates[signal] < pd.Timestamp(config['confirmation']['first_signal_not_before']):
            continue
        scenarios = scenarios_at(signal, dates, forecast, config)
        q, es = equal_weight_var_es(scenarios, portfolio['tail_probability'])
        y = float(returns.iloc[target].mean())
        rows.append({'signal_date': dates[signal], 'target_date': dates[target], 'equal_weight_gross_return': y, 'var05_return': q, 'es05_return': es, 'fz': float(fz_score(y, q, es, portfolio['tail_probability'])), 'var_breach': int(y <= q)})
        if len(rows) % 100 == 0:
            print(f'M4: scored {len(rows)} signals, {time.perf_counter() - begin:.1f}s', flush=True)
    scores = pd.DataFrame(rows)
    scores.to_csv(directory / 'M4_scores.csv', index=False)
    observed_pit = forecast['pit'][dates.get_indexer(scores.signal_date)]
    summary = {'model': 'M4', 'observations': len(scores), 'mean_fz': scores.fz.mean(), 'var_coverage': scores.var_breach.mean(), 'pit_boundary_fraction': float(((observed_pit < 0.0001) | (observed_pit > 0.9999)).mean()), 'elapsed_seconds': time.perf_counter() - begin}
    pd.DataFrame([summary]).to_csv(directory / 'prediction_summary.csv', index=False)
    print(f"M4: mean FZ {summary['mean_fz']:.8f}", flush=True)

def run_portfolio(config, directory, *, panel_name='repod', phase='validation'):
    dates, returns, _, _, _ = load_panel(config, panel_name, phase)
    panel, portfolio = (config['panels'][panel_name], config['portfolio'])
    forecast = np.load(directory / 'M4_forecasts.npz')
    scores = pd.read_csv(directory / 'M4_scores.csv', parse_dates=['target_date'])
    begin = time.perf_counter()
    count = 0

    def strategy(signal, knownweights):
        nonlocal count
        scenarios = scenarios_at(signal, dates, forecast, config)
        weights = solve_mean_cvar(scenarios, forecast['location'][signal], knownweights, panel['cost_rates'], portfolio['tail_probability'], portfolio['kappa'], portfolio['weight_cap'])
        count += 1
        if count % 100 == 0:
            print(f'M4: optimized {count} signals, {time.perf_counter() - begin:.1f}s', flush=True)
        return weights
    ledger = backtest(returns, 'M4', scores.target_date.min(), scores.target_date.max(), rates=panel['cost_rates'], cap=portfolio['weight_cap'], strategy=strategy)
    ledger.to_csv(directory / 'M4_ledger.csv', index=False)
    result = summarize(ledger, portfolio['kappa'], portfolio['tail_probability'])
    result['elapsed_seconds'] = time.perf_counter() - begin
    pd.DataFrame([result]).to_csv(directory / 'portfolio_summary.csv', index=False)
    print(f"M4 {panel_name} {phase}: J={result['J_daily_bp']:.6f} bp/day", flush=True)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--stage', choices=['forecasts', 'scores', 'portfolio', 'all'], default='all')
    args = parser.parse_args()
    config = json.loads((ROOT / 'configs/protocol.json').read_text(encoding='utf-8'))
    if args.stage in ['forecasts', 'all']:
        replay_forecasts(config, OUTPUT)
    if args.stage in ['scores', 'all']:
        score_forecasts(config, OUTPUT)
    if args.stage in ['portfolio', 'all']:
        run_portfolio(config, OUTPUT)
if __name__ == '__main__':
    main()
