"""Plot retained main-model graph structures and archived monthly edge counts."""
import json
import os
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
os.environ['MPLCONFIGDIR'] = str(ROOT / '.cache/matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.dates as mdates
from matplotlib import font_manager
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from PIL import Image
OUTPUT = ROOT / 'outputs/confirmation/figures'
STEM = 'selected_graph_structure'
BLUE = '#0072B2'

def main():
    config = json.loads((ROOT / 'configs/frozen_protocol.json').read_text(encoding='utf-8'))
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 8.5, 'axes.titlesize': 9, 'axes.labelsize': 8.5, 'xtick.labelsize': 8, 'ytick.labelsize': 8, 'pdf.fonttype': 42, 'ps.fonttype': 42, 'svg.fonttype': 'none', 'axes.spines.top': False, 'axes.spines.right': False})
    figure, axes = plt.subplots(2, 2, figsize=(7.4, 5.6), gridspec_kw={'height_ratios': [1, 1.05]})
    data, panel_metadata = ([], {})
    cutoff = pd.Timestamp('2020-12-31')
    for column, (panel, name) in enumerate([('repod', 'RepOD'), ('japan', 'Japan')]):
        source = ROOT / 'outputs/confirmation' / panel / 'graph/graph_updates.csv'
        updates = pd.read_csv(source, parse_dates=['update_date', 'first_signal', 'last_signal', 'last_mature_target'])
        assets = config['panels'][panel]['assets']
        prices = pd.read_csv(ROOT / f'data/processed/{panel}/prices.csv', usecols=['date'], parse_dates=['date'])
        start = prices.date.iloc[0]
        end = pd.Timestamp(config['panels'][panel]['test_end'])
        graph = axes[0, column]
        angle = np.pi / 2 + np.arange(len(assets)) * 2 * np.pi / len(assets)
        x, y = (0.66 * np.cos(angle), 0.66 * np.sin(angle))
        graph.scatter(x, y, s=1100, facecolors='#EAF3F8', edgecolors=BLUE, linewidths=1.2)
        for label, x_coordinate, y_coordinate in zip(assets, x, y):
            graph.text(x_coordinate, y_coordinate, label, ha='center', va='center', fontsize=9)
        graph.set_xlim(-1.18, 1.18)
        graph.set_ylim(-1.02, 1.02)
        graph.set_aspect('equal')
        graph.axis('off')
        graph.set_title(f'({chr(97 + column)}) {name}: selected graph', loc='left', pad=8)
        graph.text(0.5, -0.025, f'All {len(updates)} monthly estimates: no retained edges', transform=graph.transAxes, ha='center', va='top', fontsize=8.5)
        timeline = axes[1, column]
        line_dates = pd.DatetimeIndex([*updates.update_date, end])
        line_edges = np.r_[updates.edges.to_numpy(), updates.edges.iloc[-1]]
        timeline.step(line_dates, line_edges, where='post', color=BLUE, linewidth=1.5, zorder=3)
        timeline.plot(updates.update_date, updates.edges, linestyle='none', marker='o', markersize=2.5, color=BLUE, zorder=4)
        timeline.axvline(cutoff, color='#777777', linestyle='--', linewidth=0.8, zorder=1)
        timeline.text(cutoff, 0.91, 'Selection information cutoff\n2020-12-31', fontsize=8, ha='center', va='top', color='#444444', bbox={'facecolor': 'white', 'edgecolor': 'none', 'pad': 2})
        timeline.set_xlim(start, end)
        timeline.set_ylim(-0.18, 1.08)
        timeline.set_yticks([0, 1])
        timeline.xaxis.set_major_locator(mdates.YearLocator(2))
        timeline.xaxis.set_major_formatter(mdates.DateFormatter('%Y'))
        timeline.set_xlabel('Historical date')
        timeline.set_ylabel('Retained directed edges')
        timeline.set_title(f'({chr(99 + column)}) {name}: monthly edge counts', loc='left', pad=8)
        timeline.grid(axis='y', color='#E5E5E5', linewidth=0.6, zorder=0)
        archived = updates.copy()
        archived.insert(0, 'panel', panel)
        data.append(archived)
        panel_metadata[panel] = {'source': source.relative_to(ROOT).as_posix(), 'assets': assets, 'monthly_estimates': len(updates), 'nonempty_estimates': int((updates.edges > 0).sum()), 'first_monthly_estimate': str(updates.update_date.iloc[0].date()), 'last_monthly_estimate': str(updates.update_date.iloc[-1].date()), 'x_axis_start': str(start.date()), 'x_axis_end': str(end.date())}
    figure.subplots_adjust(left=0.09, right=0.98, top=0.94, bottom=0.1, wspace=0.28, hspace=0.43)
    OUTPUT.mkdir(parents=True, exist_ok=True)
    for extension in ['png', 'pdf', 'svg']:
        figure.savefig(OUTPUT / f'{STEM}.{extension}', dpi=300, facecolor='white')
    plt.close(figure)
    with Image.open(OUTPUT / f'{STEM}.png') as source_image:
        width, height = source_image.size
        source_image.convert('RGB').save(OUTPUT / f'{STEM}.tif', dpi=(300, 300), compression='tiff_lzw')
    pd.concat(data, ignore_index=True).to_csv(OUTPUT / f'{STEM}_data.csv', index=False)
    caption = "Retained graph structures and monthly edge counts for the selected main-model specification. The upper panels show the three RepOD assets (USO, GLD and BTC) and four Japanese funds (1306, 1343, 2510 and 1328). No connections are drawn because all 81 archived monthly graph estimates in each panel contain no retained directed edges under the selected penalties (lambda1 = 0.08, lambda2 = 0.005). The lower panels show the actual archived edge counts, with a point for each monthly estimate; the last estimated graph is carried forward to the panel's specified test end. Each horizontal axis covers the complete panel history, including initialization: no edge count is plotted before the first graph estimate. The vertical dashed line marks 31 December 2020, the historical information cutoff for hyperparameter selection, not the date on which the protocol was frozen. Graph parameters continued to be re-estimated monthly after this cutoff. The display describes the retained graphs produced by this model and configuration; it does not establish the absence of cross-asset dependence. Sources: the two main-panel graph_updates.csv archives."
    (OUTPUT / f'{STEM}_caption.txt').write_text(caption + '\n', encoding='utf-8')
    metadata = {'figure': STEM, 'source_protocol': (ROOT / 'configs/frozen_protocol.json').relative_to(ROOT).as_posix(), 'font_family': 'DejaVu Sans', 'font_size_points': {'text': 8.5, 'titles_and_node_labels': 9, 'ticks_and_cutoff': 8}, 'width_pixels': width, 'height_pixels': height, 'dpi': 300, 'formats': ['png', 'pdf', 'svg', 'tif'], 'tiff_mode': 'RGB', 'tiff_compression': 'LZW', 'historical_selection_information_cutoff': str(cutoff.date()), 'monthly_data_rows': sum((len(frame) for frame in data)), 'panels': panel_metadata, 'drawing': 'No inferred or invented edges; nodes and actual zero retained-edge counts only.', 'caption_numbered': False}
    (OUTPUT / f'{STEM}_export_record.json').write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding='utf-8')
    print(OUTPUT / f'{STEM}.png')
    print(f"{width} x {height} pixels; 300 dpi; {metadata['monthly_data_rows']} monthly data rows")
if __name__ == '__main__':
    main()
