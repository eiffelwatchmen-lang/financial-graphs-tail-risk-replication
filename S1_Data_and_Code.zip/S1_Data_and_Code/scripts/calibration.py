"""VaR coverage/independence and study-specified joint unconditional calibration.

LR coverage follows Kupiec (1995), and first-order hit independence follows
Christoffersen (1998). Joint VaR/ES identification moments motivate the final
test; its stationary-bootstrap Wald calibration is this study's fixed design.
"""
import numpy as np
from scipy.special import xlogy
from scipy.stats import chi2
from scripts.tail_graph import stationary_bootstrap_indices

def var_coverage_independence(y, q, alpha=0.05):
    """Kupiec LRuc and Christoffersen LRind for lower-tail hits y <= q.

    The independence likelihood conditions on the first hit. Count-based
    log likelihoods use xlogy(0,0)=0 for empty transition cells.
    """
    hits = (np.asarray(y) <= np.asarray(q)).astype(int)
    n = len(hits)
    counts = np.array([n - hits.sum(), hits.sum()])
    unrestricted = np.sum(xlogy(counts, counts)) - xlogy(n, n)
    restricted = xlogy(counts[0], 1 - alpha) + xlogy(counts[1], alpha)
    lr_uc = 2 * (unrestricted - restricted)
    transitions = np.bincount(2 * hits[:-1] + hits[1:], minlength=4).reshape(2, 2)
    row_totals = transitions.sum(axis=1)
    column_totals = transitions.sum(axis=0)
    markov = np.sum(xlogy(transitions, transitions)) - np.sum(xlogy(row_totals, row_totals))
    independent = np.sum(xlogy(column_totals, column_totals)) - xlogy(n - 1, n - 1)
    lr_ind = 2 * (markov - independent)
    return {'observations': n, 'hit_count': int(hits.sum()), 'hit_rate': float(hits.mean()), 'expected_hit_rate': alpha, 'lr_uc': float(lr_uc), 'p_uc': float(chi2.sf(lr_uc, 1)), 'lr_ind': float(lr_ind), 'p_ind': float(chi2.sf(lr_ind, 1)), 'transitions': transitions}

def joint_unconditional_calibration(y, q, e, alpha=0.05, repetitions=5000, block_length=20, seed=20261012):
    """Test zero mean joint VaR/ES moments using stationary-bootstrap means.

    Inputs are decimal returns. The two moments are I-alpha and
    e-q+I*(q-y)/alpha, with y, q and e converted to percentage points.
    C is the ddof=1 covariance of bootstrap means, not of individual moments.
    Both observed and centered bootstrap Wald statistics use this same C.
    The resulting p value tests departures in either direction jointly.
    """
    y, q, e = (100 * np.asarray(value, dtype=float) for value in (y, q, e))
    hits = (y <= q).astype(float)
    moments = np.column_stack((hits - alpha, e - q + hits * (q - y) / alpha))
    mean = moments.mean(axis=0)
    rng = np.random.default_rng(seed)
    bootstrap_means = np.empty((repetitions, 2))
    for start in range(0, repetitions, 256):
        stop = min(start + 256, repetitions)
        rows = stationary_bootstrap_indices(len(moments), stop - start, block_length, rng)
        bootstrap_means[start:stop] = moments[rows].mean(axis=1)
    covariance = np.cov(bootstrap_means, rowvar=False, ddof=1)
    statistic = float(mean @ np.linalg.solve(covariance, mean))
    centered = bootstrap_means - mean
    bootstrap_statistics = np.sum(centered * np.linalg.solve(covariance, centered.T).T, axis=1)
    p_value = (1 + np.count_nonzero(bootstrap_statistics >= statistic)) / (repetitions + 1)
    return {'observations': len(moments), 'mean_moments': mean, 'bootstrap_mean_covariance': covariance, 'statistic': statistic, 'p_value': float(p_value), 'bootstrap_statistics': bootstrap_statistics, 'bootstrap_mean_moments': bootstrap_means}
