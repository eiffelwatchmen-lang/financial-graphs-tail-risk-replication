"""Replay the prespecified Japanese panel without its gold fund."""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
from scripts.run_graph_development import build_graphs, replay_forecasts, run_portfolios, score_forecasts
ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / 'outputs/confirmation/no_gold_sensitivity'

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--stage', choices=['graphs', 'forecasts', 'scores', 'portfolios', 'all'], default='all')
    args = parser.parse_args()
    config = json.loads((ROOT / 'configs/frozen_protocol.json').read_text(encoding='utf-8'))
    panel = config['panels']['japan']
    keep = [i for i, asset in enumerate(panel['assets']) if asset != '1328']
    panel['cost_rates'] = [panel['cost_rates'][i] for i in keep]
    panel['assets'] = [panel['assets'][i] for i in keep]
    config['stage'] = 'external_no_gold_sensitivity'
    OUTPUT.mkdir(parents=True, exist_ok=True)
    if args.stage in ['graphs', 'all']:
        design = {'recorded_at_utc': datetime.now(timezone.utc).isoformat(), 'status': 'Original plan specifies removal of external gold; implementation recorded after main results.', 'removed_asset': '1328', 'calendar': 'Retain the original four-asset common calendar to isolate the asset-universe change.', 'replay': 'Re-estimate all historical graphs, both marginal predictors, PIT dependence and portfolios.', 'selection': 'Use frozen hyperparameters without any new selection.', 'initialization': 'Fresh equal-weight purchase from cash across the three retained funds.', 'comparison': 'FULL versus A0 within the reduced panel; universe differences are descriptive.', 'inference': 'One supplementary paired J comparison, 5000 stationary-bootstrap draws, mean block length 20.', 'source_protocol': 'configs/frozen_protocol.json', 'protocol': config}
        (OUTPUT / 'design.json').write_text(json.dumps(design, ensure_ascii=False, indent=2), encoding='utf-8')
    directory = OUTPUT / 'japan/graph'
    options = {'panel_name': 'japan', 'phase': 'test'}
    if args.stage in ['graphs', 'all']:
        build_graphs(config, config['graph']['selected_lambda1'], config['graph']['selected_lambda2'], directory, **options)
    if args.stage in ['forecasts', 'all']:
        replay_forecasts(config, directory, **options)
    if args.stage in ['scores', 'all']:
        score_forecasts(config, directory, **options)
    if args.stage in ['portfolios', 'all']:
        run_portfolios(config, directory, **options)
if __name__ == '__main__':
    main()
