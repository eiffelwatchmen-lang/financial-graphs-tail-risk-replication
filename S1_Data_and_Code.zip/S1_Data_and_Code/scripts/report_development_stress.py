"""Describe calendar-2020 returns from the continuous development strategies."""
from pathlib import Path
import numpy as np
import pandas as pd
from scripts.baselines import tail_es
ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / 'outputs/development'

def main():
    sources = {model: OUTPUT / f'{model}_ledger.csv' for model in ['M0', 'M1', 'M2', 'M3']}
    sources.update({model: ROOT / 'outputs/development_graph/l1_0p08_l2_0p005' / f'{model}_ledger.csv' for model in ['FULL', 'A0']})
    sources['M4'] = ROOT / 'outputs/development_m4/M4_ledger.csv'
    rows = []
    for model, source in sources.items():
        ledger = pd.read_csv(source, parse_dates=['target_date'], float_precision='round_trip')
        year = ledger.loc[ledger.target_date.dt.year.eq(2020)]
        net = year.net_return.to_numpy()
        path = np.r_[1.0, np.cumprod(1 + net)]
        mean, es = (net.mean(), tail_es(-net, 0.05))
        rows.append({'model': model, 'observations': len(year), 'first_target': str(year.target_date.iloc[0].date()), 'last_target': str(year.target_date.iloc[-1].date()), 'net_mean_daily_bp': 10000 * mean, 'loss_es95_daily_bp': 10000 * es, 'J_daily_bp': 10000 * (mean - 0.05 * es), 'max_drawdown_2020': float(np.min(path / np.maximum.accumulate(path) - 1)), 'mean_traded_fraction': year.turnover.mean(), 'alpha': 0.05, 'kappa': 0.05, 'source_ledger': source.relative_to(ROOT).as_posix()})
    table = pd.DataFrame(rows)
    table.to_csv(OUTPUT / '2020_stress_description.csv', index=False)
    columns = ['model', 'observations', 'first_target', 'last_target', 'net_mean_daily_bp', 'loss_es95_daily_bp', 'J_daily_bp', 'max_drawdown_2020', 'mean_traded_fraction']
    text = ['2020 年开发期压力阶段描述', '', '从七个已完成的连续开发策略账本按目标日期截取 2020 年全年。原持仓、交易和逐日成本均保留，不重新建仓、不额外扣除初始化费用，也不重新训练或选择参数。', '日均净收益、损失 ES95 和 J 的单位均为基点/日；α=0.05、κ=0.05。经验 ES 使用最差 5% 的精确分数尾质量。平均换手为原 ledger 的每日绝对成交金额/执行前财富，以比例表示；年内最大回撤也以比例表示。', '年内回撤按 2020 年净收益从 1 连续累计，并将期初 1 纳入历史峰值；不直接将原开发期累计 wealth 当作该子期本金。该归一化只用于描述子期财富路径，不触发任何新交易。', '', table[columns].to_string(index=False, float_format=lambda value: f'{value:.6f}'), '', '2020 年属于开发验证数据；以上仅为原方案规定的压力阶段描述，不构成新增确认性检验。不计算新显著性，不依据该子期表现更改所选参数。', '复现命令：python run.py -m scripts.report_development_stress']
    (OUTPUT / '2020_stress_report.txt').write_text('\n'.join(text) + '\n', encoding='utf-8')
    print(table[columns].to_string(index=False, float_format=lambda value: f'{value:.6f}'))
if __name__ == '__main__':
    main()
