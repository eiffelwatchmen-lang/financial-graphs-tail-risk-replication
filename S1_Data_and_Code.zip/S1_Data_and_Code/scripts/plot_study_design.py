"""Draw the study workflow as native vector geometry with publication exports."""
import json
from scripts.plot_confirmation_figures import ROOT, FIGURES, OUTPUT, Image, pd, plt, save_figure
from matplotlib import font_manager
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch

def main():
    FIGURES.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 8.5, 'pdf.fonttype': 42, 'ps.fonttype': 42, 'svg.fonttype': 'none'})
    figure, axis = plt.subplots(figsize=(7.1, 8.1))
    figure.subplots_adjust(left=0.025, right=0.975, bottom=0.02, top=0.98)
    axis.set(xlim=(0, 1), ylim=(0, 1))
    axis.axis('off')
    nodes = []

    def box(name, x, y, width, height, title, body, color='#52616B', fill='#F7F9FA'):
        axis.add_patch(FancyBboxPatch((x, y), width, height, boxstyle='round,pad=0.006,rounding_size=0.008', linewidth=0.9, edgecolor=color, facecolor=fill))
        axis.text(x + width / 2, y + height - 0.02, title, ha='center', va='center', fontsize=9, fontweight='bold', color=color)
        axis.text(x + width / 2, y + (height - 0.025) / 2, body, ha='center', va='center', fontsize=8.5, linespacing=1.3, color='#202830')
        nodes.append({'stage': name, 'title': title, 'text': body.replace('\n', ' ')})

    def arrow(start, end):
        axis.add_patch(FancyArrowPatch(start, end, arrowstyle='-|>', mutation_scale=8, linewidth=0.85, color='#64727D'))
    box('panels', 0.055, 0.895, 0.89, 0.082, 'Two independently evaluated panels', 'RepOD (USD)                         Japan (JPY)\nSeparate observed-date calendars and local-currency simple returns')
    arrow((0.5, 0.887), (0.5, 0.869))
    box('features', 0.055, 0.78, 0.89, 0.082, 'Seven features from information observed by signal s', 'Returns (1, 5); volatility (20, 60); downside volatility (20)\nDrawdown (60); downside shock')
    axis.plot([0.5, 0.5], [0.774, 0.76], color='#64727D', linewidth=0.85)
    axis.plot([0.2625, 0.7375], [0.76, 0.76], color='#64727D', linewidth=0.85)
    arrow((0.2625, 0.76), (0.2625, 0.744))
    arrow((0.7375, 0.76), (0.7375, 0.744))
    box('FULL', 0.055, 0.619, 0.415, 0.119, 'FULL: graph-informed predictor', 'Monthly signed tail graph (τ = 0.90)\nOwn features + signed graph messages\n92 predictor parameters (nominal)', color='#0072B2', fill='#EFF7FC')
    box('A0', 0.53, 0.619, 0.415, 0.119, 'A0: own-feature predictor', 'Own features and self-transformations\nNo cross-asset graph messages\n92 predictor parameters (nominal)', color='#B45F22', fill='#FCF5EE')
    axis.plot([0.2625, 0.2625, 0.7375, 0.7375], [0.613, 0.601, 0.601, 0.613], color='#64727D', linewidth=0.85)
    arrow((0.5, 0.601), (0.5, 0.585))
    box('marginals', 0.055, 0.491, 0.89, 0.087, 'Marginal forecasts, separately for FULL and A0', 'Student t truncated below −100% simple return\nCommon rolling mean; predicted scale and degrees of freedom')
    arrow((0.5, 0.485), (0.5, 0.464))
    box('joint_distribution', 0.055, 0.365, 0.89, 0.092, 'Joint scenarios from mature forecast errors', '252 mature out-of-sample PIT vectors → t copula (5 degrees of freedom)\n10,000 scenarios using common random numbers\nOnly PIT targets observed by signal s enter the dependence estimate')
    arrow((0.5, 0.359), (0.5, 0.338))
    box('allocation', 0.055, 0.255, 0.89, 0.076, 'Portfolio decision with transaction costs', 'Mean–CVaR optimization: α = 0.05, κ = 0.05\nLong-only weights; 0.60 cap; self-financing realized costs')
    arrow((0.5, 0.249), (0.5, 0.228))
    axis.add_patch(FancyBboxPatch((0.055, 0.132), 0.89, 0.089, boxstyle='round,pad=0.006,rounding_size=0.008', linewidth=0.9, edgecolor='#52616B', facecolor='#F7F9FA'))
    axis.text(0.5, 0.202, "Execution clock in each panel's observed dates", ha='center', va='center', fontsize=9, fontweight='bold', color='#52616B')
    for x, title, text in [(0.205, 's', 'Observe information\nand generate signal'), (0.5, 's + 1', 'Execute target weights\nand pay trading costs'), (0.795, 's + 2', 'Realize r(s + 2)\nsingle-period return')]:
        axis.text(x, 0.178, title, ha='center', va='center', fontsize=9, fontweight='bold')
        axis.text(x, 0.152, text, ha='center', va='center', fontsize=8.5, linespacing=1.2)
    arrow((0.337, 0.166), (0.365, 0.166))
    arrow((0.631, 0.166), (0.659, 0.166))
    nodes.append({'stage': 'execution', 'title': 'Observed-date execution clock', 'text': 'Signal at s; execute at s+1; single-period simple return r(s+2), not a cumulative two-period return.'})
    arrow((0.5, 0.126), (0.5, 0.106))
    box('inference', 0.055, 0.007, 0.89, 0.092, 'Paired primary decision comparison', 'J = mean net return − 0.05 × loss ES95;  ΔJ = J(FULL) − J(A0)\n5,000 paired stationary-bootstrap replicates; mean block length 20\nTwo panel-level primary tests → Holm correction')
    caption = "Study workflow for the primary FULL–A0 comparison. RepOD (USD) and Japan (JPY) retain separate observation calendars and currencies. At each signal date s, seven features are computed from observed information. FULL combines own features with messages from a monthly signed tail-risk graph, whereas A0 uses own features and their within-node transformations. Both predictors have 92 nominal parameters; this count does not imply identical effective capacity when graph inputs are zero. The graph is estimated at quantile 0.90 with fixed sparsity and temporal penalties, using only labels matured by the fit date. The diagram specifies the method and does not depict estimated cross-asset edges. Each model produces Student-t marginal forecasts truncated below −1 in decimal simple-return units. Dependence is estimated from 252 mature out-of-sample probability integral transform (PIT) vectors with a five-degree-of-freedom t copula. Common random numbers generate 10,000 scenarios per decision. Mean–CVaR optimization includes transaction costs, long-only constraints and a 0.60 asset-weight cap. The signal formed at s is executed at s+1; r(s+2) is the following single-period return, not a cumulative two-period return. Realized costs are charged to that holding period's net return. The primary endpoint is J, mean net return minus 0.05 times empirical loss ES95, evaluated with exact fractional tail mass. Paired stationary bootstrap uses 5,000 replicates and mean block length 20; the two panel-level primary p values are corrected with Holm's procedure. Historical parameter selection uses information through 2020-12-31. The protocol was actually recorded as frozen on 2026-10-13 (04:42:54.747030 UTC); this recording date is distinct from the historical information cutoff. The realized evaluation begins on the first executable target after the cutoff and model-readiness requirements, rather than automatically on the nominal calendar start. Source: configs/frozen_protocol.json and the implemented timing, forecasting, allocation and inference modules."
    save_figure(figure, 'study_design', pd.DataFrame(nodes), caption)
    with Image.open(FIGURES / 'study_design.tif') as exported:
        metadata = {'figure_role': 'method_workflow_not_empirical_graph', 'font': 'DejaVu Sans', 'font_sizes_pt': [8.5, 9], 'width_pixels': exported.width, 'height_pixels': exported.height, 'dpi': [float(value) for value in exported.info['dpi']], 'mode': exported.mode, 'compression': exported.info['compression'], 'native_vector_formats': ['pdf', 'svg'], 'raster_formats': ['png', 'tif'], 'pixel_resampling': False, 'caption_numbering': 'Unnumbered; assign during manuscript assembly.', 'protocol_source': (OUTPUT.parents[1] / 'configs/frozen_protocol.json').relative_to(ROOT).as_posix(), 'script_source': (OUTPUT.parents[1] / 'scripts/plot_study_design.py').relative_to(ROOT).as_posix()}
    (FIGURES / 'study_design_export.json').write_text(json.dumps(metadata, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(metadata, indent=2), flush=True)
if __name__ == '__main__':
    main()
