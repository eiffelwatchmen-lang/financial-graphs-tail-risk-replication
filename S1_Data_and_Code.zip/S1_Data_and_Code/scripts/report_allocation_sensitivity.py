"""Summarize all seven allocation settings without changing primary inference."""
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scripts.baselines import summarize
from scripts.report_confirmation import read_records
from scripts.statistical_inference import holm_adjust, paired_j_bootstrap
ROOT = Path(__file__).resolve().parents[1]
CONFIRMATION = ROOT / 'outputs/confirmation'
OUTPUT = CONFIRMATION / 'allocation_sensitivity'
SETTINGS = ('cost_0', 'cost_0p5', 'cost_2', 'cost_4', 'kappa_0p02', 'kappa_0p10', 'kappa_0p20')
PANELS = ('repod', 'japan')

def main():
    primary = pd.read_csv(CONFIRMATION / 'primary_comparison.csv')
    reference_dates = {panel: read_records(CONFIRMATION / panel / 'graph', 'FULL', 'ledger').target_date for panel in PANELS}
    rows = []
    for setting in SETTINGS:
        for panel in PANELS:
            directory = OUTPUT / setting / panel
            settings = json.loads((directory / 'settings.json').read_text(encoding='utf-8'))
            kappa = settings['kappa']
            ledgers = {model: read_records(directory, model, 'ledger', reference_dates[panel]) for model in ['FULL', 'A0']}
            returns = np.column_stack((ledgers['FULL'].net_return, ledgers['A0'].net_return))
            comparison = paired_j_bootstrap(returns, [(0, 1)], alpha=0.05, kappa=kappa, repetitions=5000, block_length=20, seed=20261012)
            row = {'setting': setting, 'panel': panel, 'kappa': kappa, 'cost_multiplier': settings['cost_multiplier'], 'cost_rates': json.dumps(settings['cost_rates']), 'observations': len(returns), 'first_target': str(reference_dates[panel].iloc[0].date()), 'last_target': str(reference_dates[panel].iloc[-1].date()), 'delta_J_daily_bp': 10000 * comparison['point_difference'][0], 'delta_J_ci95_lower_bp': 10000 * comparison['ci_lower'][0], 'delta_J_ci95_upper_bp': 10000 * comparison['ci_upper'][0], 'delta_mean_net_daily_bp': 10000 * comparison['mean_difference'][0], 'delta_loss_ES95_daily_bp': 10000 * comparison['loss_es_difference'][0], 'p_raw': comparison['p_value'][0], 'distribution_retrained': settings['distribution_retrained'], 'allocation_reoptimized': settings['allocation_reoptimized'], 'costs_recomputed_per_trade': settings['costs_recomputed_per_trade'], 'settings_source': (directory / 'settings.json').relative_to(ROOT).as_posix(), 'frozen_forecast_directory': settings['frozen_forecast_directory']}
            for model, ledger in ledgers.items():
                summary = summarize(ledger, kappa, 0.05)
                for metric in ['net_mean_daily_bp', 'loss_es95_daily_bp', 'J_daily_bp', 'mean_traded_fraction', 'sum_cost_fractions', 'total_cost_per_initial_wealth', 'terminal_wealth']:
                    row[f'{model}_{metric}'] = summary[metric]
            rows.append(row)
    table = pd.DataFrame(rows)
    table['p_holm_14_sensitivity'] = holm_adjust(table.p_raw.to_numpy())
    table['Holm_family_size'] = len(table)
    table.to_csv(OUTPUT / 'comparison_summary.csv', index=False)
    decision_columns = ['setting', 'panel', 'kappa', 'cost_multiplier', 'observations', 'FULL_J_daily_bp', 'A0_J_daily_bp', 'delta_J_daily_bp', 'delta_J_ci95_lower_bp', 'delta_J_ci95_upper_bp', 'p_raw', 'p_holm_14_sensitivity']
    component_columns = ['setting', 'panel', 'FULL_net_mean_daily_bp', 'A0_net_mean_daily_bp', 'FULL_loss_es95_daily_bp', 'A0_loss_es95_daily_bp', 'FULL_total_cost_per_initial_wealth', 'A0_total_cost_per_initial_wealth']
    displayed_effect = table.delta_J_daily_bp.round(6)
    positive_significant = displayed_effect.gt(0) & table.p_holm_14_sensitivity.lt(0.05)
    negative_significant = displayed_effect.lt(0) & table.p_holm_14_sensitivity.lt(0.05)
    lines = ['配置成本与风险偏好敏感性报告', '', f'七项设置、两个面板的 14 个新增 FULL−A0 比较全部纳入同一敏感性 Holm 族。其中 {int(positive_significant.sum())} 项为校正后显著正差，{int(negative_significant.sum())} 项为校正后显著负差。', '完整报告各设置，不按最有利结果重新选参；这些比较属于敏感性参考，不修改原先两项主要检验或其结论。', '正、负及近零的计数按 ΔJ 四舍五入至 6 位基点判断，显示值为零计为近零；原始 CSV 数值、bootstrap 结果和 p 值保持原精度。', '', '原主设置：直接引用既有 primary_comparison.csv，未重新检验，也未纳入这 14 项校正族。', primary[['panel', 'observations', 'delta_J_daily_bp', 'delta_J_ci95_lower_bp', 'delta_J_ci95_upper_bp', 'p_raw', 'p_holm_two_panels']].to_string(index=False, float_format=lambda value: f'{value:.6f}'), '', '新增设置的完整比较：差值为 FULL−A0，收益、损失 ES 与 J 的单位为每日基点。', '成本设置使用原费率的 0、0.5、2、4 倍并保持 κ=0.05；风险偏好设置使用 κ=0.02、0.10、0.20 并保持原费率。每项设置均以相同 κ 进行组合优化和事后 J 评价。不同 κ 对应不同决策目标，跨 κ 的 J 高低不用于重新选择主设置。', table[decision_columns].to_string(index=False, float_format=lambda value: f'{value:.6f}'), '', '收益、尾部损失与费用组成：费用为按初始财富计量的实际总费用比例，包含逐次自融资交易费用。', table[component_columns].to_string(index=False, float_format=lambda value: f'{value:.6f}'), '']
    for panel in PANELS:
        panel_table = table.loc[table.panel == panel]
        panel_signs = panel_table.delta_J_daily_bp.round(6)
        lines.append(f'{panel} 七项 ΔJ 的完整范围为 [{panel_table.delta_J_daily_bp.min():.6f}, {panel_table.delta_J_daily_bp.max():.6f}] 基点/日；{int(panel_signs.gt(0).sum())} 项为正，{int(panel_signs.lt(0).sum())} 项为负，{int(panel_signs.eq(0).sum())} 项近零。所有设置均使用 {panel_table.first_target.iloc[0]} 至 {panel_table.last_target.iloc[0]} 共 {int(panel_table.observations.iloc[0])} 个相同目标日。')
    japan_cost4 = table.loc[table.panel.eq('japan') & table.setting.eq('cost_4')].iloc[0]
    lines.extend(['', f'日本 cost_4 单独说明：数值精度下为等权目标，仍每日再平衡并付费。FULL 与 A0 的 ΔJ 按 6 位基点显示为 {japan_cost4.delta_J_daily_bp:.6f}；按初始财富计的实际总费用比例分别为 {japan_cost4.FULL_total_cost_per_initial_wealth:.8f}、{japan_cost4.A0_total_cost_per_initial_wealth:.8f}。两策略保留求解器产生的浮点尾数差异，相关原始估计和 p 值照常存档，不将其解读为实质收益差。'])
    lines.extend(['', '方法与复现', '冻结的 FULL/A0 分布预测不重训；每项成本或 κ 设置重新优化配置，并随持仓漂移重新计算实际交易费用。', '逐日交易记录与原主比较按 target_date 完全对齐，不一致时脚本直接报错。J=平均净收益−κ×损失 ES95，ES 每次使用最差 5% 的精确分数尾质量。', '使用 5000 次配对平稳区块 bootstrap，平均区块长度 20，种子 20261012，完整日期行同步抽取 FULL/A0，逐次重算 J。95% 区间为未校正 percentile 区间；原 p 为中心化双侧 (count+1)/(5000+1)，再对全部 14 个新增比较一次性作 Holm 校正。', f"原主要比较来源：{(CONFIRMATION / 'primary_comparison.csv').relative_to(ROOT).as_posix()}", f'逐项设置与交易记录：{OUTPUT.relative_to(ROOT).as_posix()}/setting/panel/settings.json 与 FULL_ledger.csv、A0_ledger.csv。', '各设置的具体费率、κ、预测来源及重优化记录均保留在 comparison_summary.csv 与原 settings.json 中。', '统计报告复现命令（工作目录 .，全部敏感性交易记录完成后运行）：', 'python run.py -m scripts.report_allocation_sensitivity', '', '方法来源：Politis & Romano (1994), The Stationary Bootstrap. https://doi.org/10.1080/01621459.1994.10476870', 'Holm (1979), A Simple Sequentially Rejective Multiple Test Procedure. https://doi.org/10.2307/4615733'])
    (OUTPUT / 'report.txt').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(table[decision_columns].to_string(index=False, float_format=lambda value: f'{value:.6f}'))
if __name__ == '__main__':
    main()
