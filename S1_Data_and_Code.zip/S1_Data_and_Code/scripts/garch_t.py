"""Univariate GARCH(1,1) with variance-standardized Student-t innovations.

Estimation uses the untruncated likelihood. The common return distribution
layer applies its -1 lower truncation separately when forecasts are emitted.
Recursion and forecast convention follow the arch GARCH/forecasting reference:
https://arch.readthedocs.io/en/latest/univariate/forecasting.html
"""
import numpy as np
from scipy.optimize import minimize
from scipy.signal import lfilter
from scipy.special import digamma, gammaln

def filter_variance(residuals, params, initial_variance):
    """Return h[t] for each residual[t], with h[0] fixed by the caller."""
    omega, alpha, beta, _ = params
    innovations = np.empty(len(residuals))
    innovations[0] = initial_variance
    innovations[1:] = omega + alpha * np.asarray(residuals[:-1]) ** 2
    return lfilter([1.0], [1.0, -beta], innovations)

def mean_nll_gradient(params, residuals, initial_variance):
    """Mean negative log likelihood and its four analytic derivatives.

    The initial variance is fixed, so its parameter derivatives are zero.
    Student-t innovations have unit variance, using df-2 in the density.
    """
    _, _, beta, df = params
    residual_squared = np.asarray(residuals) ** 2
    variance = filter_variance(residuals, params, initial_variance)
    ratio = residual_squared / ((df - 2) * variance)
    log_tail = np.log1p(ratio)
    losses = gammaln(df / 2) - gammaln((df + 1) / 2) + 0.5 * np.log(np.pi * (df - 2) * variance) + 0.5 * (df + 1) * log_tail
    forcing = np.zeros((3, len(residuals)))
    forcing[0, 1:] = 1
    forcing[1, 1:] = residual_squared[:-1]
    forcing[2, 1:] = variance[:-1]
    variance_derivatives = lfilter([1.0], [1.0, -beta], forcing, axis=1)
    tail_fraction = ratio / (1 + ratio)
    dvariance = (1 - (df + 1) * tail_fraction) / (2 * variance)
    ddf = 0.5 * (digamma(df / 2) - digamma((df + 1) / 2)) + 0.5 / (df - 2) + 0.5 * log_tail - 0.5 * (df + 1) / (df - 2) * tail_fraction
    gradient = np.r_[np.mean(variance_derivatives * dvariance, axis=1), ddf.mean()]
    return (float(losses.mean()), gradient)

def fit_garch(residuals):
    """Estimate on training residuals and return variances in decimal units.

    RMS scaling conditions the numerical optimization; omega and h are then
    restored to squared-return units. nll is the total negative log likelihood
    in original return units, including the RMS change-of-variables term.
    """
    residuals = np.asarray(residuals, dtype=float)
    rms = np.sqrt(np.mean(residuals ** 2))
    normalized = residuals / rms
    initial_variance = float(np.mean(normalized ** 2))
    initial = np.array([0.05 * initial_variance, 0.05, 0.9, 8.0])
    result = minimize(mean_nll_gradient, initial, args=(normalized, initial_variance), method='SLSQP', jac=True, bounds=[(1e-10, None), (0, 0.999), (0, 0.999), (3, 30)], constraints={'type': 'ineq', 'fun': lambda params: 0.999 - params[1] - params[2], 'jac': lambda params: np.array([0.0, -1.0, -1.0, 0.0])}, options={'ftol': 1e-10, 'maxiter': 300})
    if not result.success:
        raise RuntimeError(f'Student-t GARCH estimation failed: {result.message}')
    params = result.x.copy()
    params[0] *= rms ** 2
    variance = filter_variance(residuals, params, initial_variance * rms ** 2)
    return {'params': params, 'variance': variance, 'last_variance': float(variance[-1]), 'nll': float(len(residuals) * (result.fun + np.log(rms))), 'iterations': int(result.nit)}

def forecast_variance(params, last_variance, last_residual):
    """Return conditional single-period variances for s+1 and s+2."""
    omega, alpha, beta, _ = params
    h1 = omega + alpha * last_residual ** 2 + beta * last_variance
    h2 = omega + (alpha + beta) * h1
    return (float(h1), float(h2))
