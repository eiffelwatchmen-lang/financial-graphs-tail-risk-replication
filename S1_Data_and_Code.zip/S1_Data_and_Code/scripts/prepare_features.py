"""Price-only features and an information-availability schedule; no model fitting."""
import json
from pathlib import Path
import numpy as np
import pandas as pd
ROOT = Path(__file__).resolve().parents[1]

def price_features(prices, scale_floor=1e-08):
    returns = prices.pct_change(fill_method=None)
    vol60 = returns.rolling(60).std(ddof=1)
    features = {'return_1': returns, 'return_5': prices / prices.shift(5) - 1, 'vol_20': returns.rolling(20).std(ddof=1), 'vol_60': vol60, 'downside_vol_20': np.sqrt(returns.clip(upper=0).pow(2).rolling(20).mean()), 'drawdown_60': prices / prices.rolling(61).max() - 1, 'downside_shock': (-returns / vol60.clip(lower=scale_floor)).clip(lower=0)}
    frame = pd.concat(features, axis=1)
    frame.columns.names = ['feature', 'asset']
    return frame.iloc[60:]

def availability_schedule(dates, config):
    """Count mature samples, with graph and predictor refits at month end."""
    warmup = config['features']['warmup_returns']
    lag = config['timing']['target_lag']
    month_ends = dates.to_series().groupby(dates.to_period('M')).last()
    update_dates = set(month_ends.iloc[:-1])
    first_graph = None
    first_forecast = None
    rows = []
    for t, date in enumerate(dates):
        regression_n = max(0, t - lag - warmup + 1)
        graph_refit = date in update_dates and regression_n >= config['graph']['min_samples']
        if graph_refit and first_graph is None:
            first_graph = t
        node_n = 0 if first_graph is None else max(0, t - lag - first_graph + 1)
        predictor_refit = date in update_dates and node_n >= config['predictor']['min_samples']
        if predictor_refit and first_forecast is None:
            first_forecast = t
        pit_n = 0 if first_forecast is None else max(0, t - lag - first_forecast + 1)
        ready = pit_n >= config['copula']['pit_samples']
        rows.append({'date': date, 'graph_mature_samples': min(regression_n, config['graph']['max_samples']), 'graph_refit': graph_refit, 'predictor_mature_samples': min(node_n, config['predictor']['max_samples']), 'predictor_refit': predictor_refit, 'mature_oos_pit_vectors': min(pit_n, config['copula']['pit_samples']), 'decision_ready_by_sample_count': ready, 'execution_date': dates[t + 1] if t + 1 < len(dates) else pd.NaT, 'target_date': dates[t + lag] if t + lag < len(dates) else pd.NaT})
    return pd.DataFrame(rows)

def main():
    config = json.loads((ROOT / 'configs/protocol.json').read_text(encoding='utf-8'))
    out = ROOT / 'outputs'
    out.mkdir(exist_ok=True)
    summary = {}
    for panel in config['panels']:
        directory = ROOT / 'data/processed' / panel
        prices = pd.read_csv(directory / 'prices.csv', index_col='date', parse_dates=True)
        features = price_features(prices, config['features']['scale_floor'])
        long = features.stack(level='asset').reset_index()
        long.to_csv(directory / 'features.csv', index=False)
        schedule = availability_schedule(prices.index, config)
        schedule.to_csv(out / f'{panel}_availability.csv', index=False)
        first = schedule.loc[schedule.decision_ready_by_sample_count].iloc[0]
        summary[panel] = {'first_complete_feature_date': features.index[0].date().isoformat(), 'first_graph_fit_date': schedule.loc[schedule.graph_refit, 'date'].iloc[0].date().isoformat(), 'first_marginal_forecast_date': schedule.loc[schedule.predictor_refit, 'date'].iloc[0].date().isoformat(), 'earliest_decision_signal_by_sample_count': first.date.date().isoformat(), 'earliest_execution_by_sample_count': first.execution_date.date().isoformat(), 'earliest_target_by_sample_count': first.target_date.date().isoformat(), 'meaning': 'Availability counts only; fitted forecasts and PIT values are not yet generated.'}
    (out / 'readiness_summary.json').write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding='utf-8')
    print(json.dumps(summary, indent=2, ensure_ascii=False))
if __name__ == '__main__':
    main()
