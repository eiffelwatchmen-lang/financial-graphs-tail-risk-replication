"""Prespecified block-length and 2022-subperiod summaries of saved trades."""
import json
import numpy as np
import pandas as pd
from scripts.report_confirmation import OUTPUT, PANELS, ROOT, read_records
from scripts.statistical_inference import holm_adjust, paired_j_bootstrap

def comparison_row(config, panel, full, a0, block_length):
    result = paired_j_bootstrap(np.column_stack((full.net_return, a0.net_return)), [(0, 1)], alpha=config['portfolio']['tail_probability'], kappa=config['portfolio']['kappa'], repetitions=config['inference']['bootstrap_repetitions'], block_length=block_length, seed=config['seed'])
    row = {'panel': panel, 'comparison': 'FULL-A0', 'observations': len(full), 'first_target': str(full.target_date.iloc[0].date()), 'last_target': str(full.target_date.iloc[-1].date()), 'tail_probability': config['portfolio']['tail_probability'], 'kappa': config['portfolio']['kappa'], 'bootstrap_repetitions': config['inference']['bootstrap_repetitions'], 'block_length': block_length, 'seed': config['seed'], 'delta_J_daily_bp': 10000 * result['point_difference'][0], 'delta_J_ci95_lower_bp': 10000 * result['ci_lower'][0], 'delta_J_ci95_upper_bp': 10000 * result['ci_upper'][0], 'p_raw': result['p_value'][0]}
    for index, model in enumerate(('FULL', 'A0')):
        row[f'{model}_mean_net_daily_bp'] = 10000 * result['mean_net_return'][index]
        row[f'{model}_loss_ES95_daily_bp'] = 10000 * result['loss_es'][index]
        row[f'{model}_J_daily_bp'] = 10000 * result['J'][index]
    return row

def main():
    config = json.loads((ROOT / 'configs/frozen_protocol.json').read_text(encoding='utf-8'))
    ledgers = {}
    for panel in PANELS:
        directory = OUTPUT / panel / 'graph'
        full = read_records(directory, 'FULL', 'ledger')
        a0 = read_records(directory, 'A0', 'ledger', full.target_date)
        ledgers[panel] = (full, a0)
    block_rows = []
    for block_length in (10, 40):
        rows = [comparison_row(config, panel, *ledgers[panel], block_length) for panel in PANELS]
        adjusted = holm_adjust([row['p_raw'] for row in rows])
        for row, p_holm in zip(rows, adjusted):
            row['p_holm_two_panels_sensitivity'] = p_holm
        block_rows.extend(rows)
    blocks = pd.DataFrame(block_rows)
    year_rows = []
    for panel, (full, a0) in ledgers.items():
        selected = full.target_date.dt.year.eq(2022)
        row = comparison_row(config, panel, full.loc[selected], a0.loc[selected], config['inference']['block_length'])
        del row['p_raw']
        row['year'] = 2022
        year_rows.append(row)
    year = pd.DataFrame(year_rows)
    directory = OUTPUT / 'sensitivity'
    directory.mkdir(parents=True, exist_ok=True)
    blocks.to_csv(directory / 'block_lengths.csv', index=False)
    year.to_csv(directory / 'year_2022.csv', index=False)
    lines = ['预设补充分析：区块长度与 2022 年子期', '', '两项分析读取已完成的 FULL/A0 交易档案。各面板按共同 target_date 配对净收益，均值、损失 ES 和 J 的单位均为每日基点，ΔJ 为 FULL 减 A0。', f"J=均值−κ×损失 ES；κ={config['portfolio']['kappa']}，尾部概率={config['portfolio']['tail_probability']:.0%}。ES 对最差 5% 的精确经验尾部质量积分，边界观测按分数权重计入。", f"配对平稳区块 bootstrap 为 {config['inference']['bootstrap_repetitions']} 次，种子 {config['seed']}；每次同步重采样两项策略并重新计算均值、ES 和 J，95% 区间使用 percentile 法。", '', '区块长度 10 与 40：完整确认样本。双侧中心化 p=(1+#{|Δ*−Δhat|≥|Δhat|})/(B+1)。每种区块长度内对两个面板的 p 分别作 Holm 校正，校正值仅作为敏感性参考；主要确认检验保留平均区块长度 20 的预设结果。', blocks[['block_length', 'panel', 'observations', 'delta_J_daily_bp', 'delta_J_ci95_lower_bp', 'delta_J_ci95_upper_bp', 'p_raw', 'p_holm_two_panels_sensitivity']].to_string(index=False, float_format=lambda value: f'{value:.6f}'), '', '2022 年子期：按各面板共同 target_date 筛取 2022 年的连续策略净收益，保留原交易成本与持仓路径。区间采用平均区块长度 20；该子期提供均值、ES、J 及 ΔJ 的描述和区间，不形成新的确认性判定。', year[['panel', 'observations', 'first_target', 'last_target', 'FULL_mean_net_daily_bp', 'A0_mean_net_daily_bp', 'FULL_loss_ES95_daily_bp', 'A0_loss_ES95_daily_bp', 'FULL_J_daily_bp', 'A0_J_daily_bp', 'delta_J_daily_bp', 'delta_J_ci95_lower_bp', 'delta_J_ci95_upper_bp']].to_string(index=False, float_format=lambda value: f'{value:.6f}'), '', f"冻结配置：{(ROOT / 'configs/frozen_protocol.json').relative_to(ROOT).as_posix()}", '逐日来源：outputs/confirmation/{repod,japan}/graph/{FULL,A0}_ledger.csv。', '复现：python run.py -m scripts.report_sensitivity']
    (directory / 'report.txt').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(blocks[['block_length', 'panel', 'delta_J_daily_bp', 'p_raw', 'p_holm_two_panels_sensitivity']].to_string(index=False))
    print(year[['panel', 'observations', 'delta_J_daily_bp', 'delta_J_ci95_lower_bp', 'delta_J_ci95_upper_bp']].to_string(index=False))
if __name__ == '__main__':
    main()
