"""Apply one causal EWMA risk cap to archived FULL/A0 target weights."""
from datetime import datetime, timezone
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scripts.baselines import backtest, summarize
from scripts.run_graph_development import load_panel
from scripts.statistical_inference import paired_j_bootstrap, holm_adjust
ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / 'outputs/confirmation/risk_matching'
DECAY = 0.94

def ewma_covariances(returns, decay=DECAY, warmup=60):
    """Sigma[s] includes observations through close s, with zero-mean returns."""
    values = returns.to_numpy()
    covariance = np.full((len(values), values.shape[1], values.shape[1]), np.nan)
    initial = values[1:warmup + 1]
    covariance[warmup] = initial.T @ initial / warmup
    for day in range(warmup + 1, len(values)):
        covariance[day] = decay * covariance[day - 1] + (1 - decay) * np.outer(values[day], values[day])
    return covariance

def read_ledger(path):
    return pd.read_csv(path, parse_dates=['signal_date', 'execution_date', 'target_date'])

def signal_risk(ledger, dates, covariance, assets):
    weights = ledger[[f'target_{asset}' for asset in assets]].to_numpy()
    at_signal = covariance[dates.get_indexer(ledger.signal_date)]
    return np.sqrt(252 * np.einsum('ij,ijk,ik->i', weights, at_signal, weights))

def main():
    config = json.loads((ROOT / 'configs/frozen_protocol.json').read_text(encoding='utf-8'))
    OUTPUT.mkdir(parents=True, exist_ok=True)
    dates, returns, _, _, _ = load_panel(config, 'repod', 'validation')
    covariance = ewma_covariances(returns)
    development = ROOT / 'outputs/development_graph/l1_0p08_l2_0p005'
    calibration_rows = []
    medians = {}
    for model in ['FULL', 'A0']:
        ledger = read_ledger(development / f'{model}_ledger.csv')
        risk = signal_risk(ledger, dates, covariance, config['panels']['repod']['assets'])
        medians[model] = float(np.median(risk))
        calibration_rows.append(pd.DataFrame({'model': model, 'signal_date': ledger.signal_date, 'target_date': ledger.target_date, 'annualized_ex_ante_volatility': risk}))
    target = min(medians.values())
    pd.concat(calibration_rows).to_csv(OUTPUT / 'development_calibration.csv', index=False)
    design = {'recorded_at_utc': datetime.now(timezone.utc).isoformat(), 'status': 'EWMA risk matching was specified in the original plan; decay, initialization and calibration rule are operational choices recorded after main results.', 'target_calibration_data': 'RepOD development FULL/A0 targets, 2019-07-01 through 2020-12-31 only.', 'target_rule': 'The smaller of the two model-specific medians of signal-date annualized EWMA risk.', 'development_medians': medians, 'annual_target_volatility': target, 'target_transfer': 'One identical target applied to both test panels without test-period calibration.', 'ewma_decay': DECAY, 'zero_mean': True, 'initialization': 'Mean outer product of the first 60 observed return vectors.', 'information': 'Covariance at s includes returns through s; target executes at s+1 and first earns r(s+2).', 'position_rule': "Scale the archived risky target by min(1, target/sqrt(252*w' Sigma_s w)).", 'cash': 'Residual is zero-return cash; no leverage; actual self-financing costs are recomputed.', 'initial_purchase': 'The archived initial equal-weight target is also scaled using its signal-date covariance.', 'optimization': 'A risk overlay on archived targets; the underlying optimization is not repeated with scaled holdings.', 'interpretation': 'Common ex-ante risk cap, not exact equality of realized risk or of uncapped low-risk positions.', 'inference': 'Two panel comparisons form a separate supplementary Holm family.', 'method_source': 'https://www.msci.com/documents/10199/5915b101-4206-4ba0-aee2-3449d5c7e95a', 'source_protocol': 'configs/frozen_protocol.json', 'protocol': config}
    (OUTPUT / 'design.json').write_text(json.dumps(design, ensure_ascii=False, indent=2), encoding='utf-8')
    summaries, comparisons = ([], [])
    for panel_name in ['repod', 'japan']:
        dates, returns, _, _, _ = load_panel(config, panel_name, 'test')
        covariance = ewma_covariances(returns)
        panel = config['panels'][panel_name]
        directory = OUTPUT / panel_name
        directory.mkdir(parents=True, exist_ok=True)
        ledgers = []
        for model in ['FULL', 'A0']:
            source = ROOT / f'outputs/confirmation/{panel_name}/graph/{model}_ledger.csv'
            archived = read_ledger(source)
            risk = signal_risk(archived, dates, covariance, panel['assets'])
            multipliers = np.minimum(1.0, target / risk)
            original_targets = archived[[f'target_{asset}' for asset in panel['assets']]].to_numpy()
            targets = pd.DataFrame(original_targets * multipliers[:, None], index=archived.signal_date, columns=panel['assets'])

            def strategy(signal, knownweights):
                return targets.loc[dates[signal]].to_numpy()
            ledger = backtest(returns, model, archived.target_date.iloc[0], archived.target_date.iloc[-1], rates=panel['cost_rates'], strategy=strategy, initial_target=targets.iloc[0].to_numpy())
            ledger['signal_risk_before_annual'] = risk
            ledger['signal_risk_after_annual'] = risk * multipliers
            ledger['risk_multiplier'] = multipliers
            ledger['target_cash'] = 1 - multipliers
            ledger.to_csv(directory / f'{model}_ledger.csv', index=False)
            summary = summarize(ledger, config['portfolio']['kappa'], config['portfolio']['tail_probability'])
            summary.update(panel=panel_name, annual_target_volatility=target, mean_risky_exposure=float(multipliers.mean()), fraction_scaled=float(np.mean(multipliers < 1)), source_ledger=source.relative_to(ROOT).as_posix())
            summaries.append(summary)
            ledgers.append(ledger)
        pd.testing.assert_series_equal(ledgers[0].target_date, ledgers[1].target_date)
        inference = paired_j_bootstrap(np.column_stack([ledger.net_return for ledger in ledgers]), [(0, 1)], alpha=config['portfolio']['tail_probability'], kappa=config['portfolio']['kappa'], repetitions=config['inference']['bootstrap_repetitions'], block_length=config['inference']['block_length'], seed=config['seed'])
        comparisons.append({'panel': panel_name, 'observations': len(ledgers[0]), 'first_target': ledgers[0].target_date.iloc[0].date(), 'last_target': ledgers[0].target_date.iloc[-1].date(), 'annual_target_volatility': target, 'FULL_J_daily_bp': 10000 * inference['J'][0], 'A0_J_daily_bp': 10000 * inference['J'][1], 'delta_J_daily_bp': 10000 * inference['point_difference'][0], 'ci95_lower_bp': 10000 * inference['ci_lower'][0], 'ci95_upper_bp': 10000 * inference['ci_upper'][0], 'p_raw': inference['p_value'][0]})
    table = pd.DataFrame(comparisons)
    table['p_holm_two_panels_supplementary'] = holm_adjust(table.p_raw)
    table.to_csv(OUTPUT / 'comparison_summary.csv', index=False)
    summary_table = pd.DataFrame(summaries)
    summary_table.to_csv(OUTPUT / 'portfolio_summary.csv', index=False)
    report = ['事前风险归一化补充分析', f'共同年化风险上限：{target:.8%}；仅由RepOD开发期两模型各自EWMA预测风险中位数的较小值确定。', 'EWMA衰减0.94，初始60期零均值二阶矩，信号日只使用截至当日的收益。目标权重乘min(1,目标风险/当前预测风险)，其余为零收益现金；重新计算首次建仓和后续交易费用。', '该分析对归档策略目标施加共同风险上限，不使用测试实现波动调整持仓，不保证事后实现风险完全一致。具体实施规则在主结果之后记录，目标校准数据截至2020年末。', table.to_string(index=False, float_format=lambda x: f'{x:.6f}'), '缩仓比例与平均风险资产权重（比例均为0至1）：\n' + summary_table[['panel', 'model', 'fraction_scaled', 'mean_risky_exposure', 'net_volatility_annual_252']].to_string(index=False, float_format=lambda x: f'{x:.6f}'), '两个面板采用5000次配对平稳区块bootstrap，平均区块20，种子20261012；95%百分位区间和中心化双侧p，单独对两项检验作Holm校正。', 'EWMA来源：RiskMetrics Technical Document, Fourth Edition (1996), https://www.msci.com/documents/10199/5915b101-4206-4ba0-aee2-3449d5c7e95a']
    (OUTPUT / 'report.txt').write_text('\n\n'.join(report) + '\n', encoding='utf-8')
    print(table.to_string(index=False), flush=True)
if __name__ == '__main__':
    main()
