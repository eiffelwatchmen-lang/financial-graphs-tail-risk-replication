"""Report tail-probability and weekly-trading sensitivities in separate families."""
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scripts.run_tail_execution_sensitivity import OUTPUT, SETTINGS
from scripts.statistical_inference import holm_adjust, paired_j_bootstrap
ROOT = Path(__file__).resolve().parents[1]

def main():
    rows, model_rows = ([], [])
    for setting, (alpha, frequency) in SETTINGS.items():
        for panel in ['repod', 'japan']:
            directory = OUTPUT / setting / panel
            settings = json.loads((directory / 'settings.json').read_text(encoding='utf-8'))
            main_dates = pd.read_csv(ROOT / 'outputs/confirmation' / panel / 'graph/FULL_ledger.csv', parse_dates=['target_date']).target_date
            ledgers, summaries = ({}, {})
            for model in ['FULL', 'A0']:
                ledger = pd.read_csv(directory / f'{model}_ledger.csv', parse_dates=['target_date'], float_precision='round_trip')
                pd.testing.assert_series_equal(ledger.target_date, main_dates)
                ledgers[model] = ledger
                summaries[model] = json.loads((directory / f'{model}_summary.json').read_text(encoding='utf-8'))
                result = summaries[model]
                model_rows.append({key: value for key, value in result.items() if key not in ['scenario_tail_mass', 'realized_tail_mass']})
            comparison = paired_j_bootstrap(np.column_stack([ledgers[model].net_return for model in ['FULL', 'A0']]), [(0, 1)], alpha=alpha, kappa=settings['kappa'], repetitions=5000, block_length=20, seed=20261012)
            tail = settings['realized_tail_mass']
            scenario_tail = settings['scenario_tail_mass']
            row = {'setting': setting, 'panel': panel, 'alpha': alpha, 'es_confidence_level': 1 - alpha, 'trading_frequency': frequency, 'kappa': settings['kappa'], 'observations': len(main_dates), 'first_target': str(main_dates.iloc[0].date()), 'last_target': str(main_dates.iloc[-1].date()), 'sample_N_alpha': tail['N_alpha'], 'sample_complete_tail_observations': tail['complete_tail_observations'], 'sample_boundary_fraction': tail['boundary_fraction'], 'sample_boundary_worst_rank': tail['boundary_worst_rank'], 'scenario_N_alpha': scenario_tail['N_alpha'], 'scenario_complete_tail_observations': scenario_tail['complete_tail_observations'], 'scenario_boundary_fraction': scenario_tail['boundary_fraction'], 'delta_J_daily_bp': 10000 * comparison['point_difference'][0], 'delta_J_ci95_lower_bp': 10000 * comparison['ci_lower'][0], 'delta_J_ci95_upper_bp': 10000 * comparison['ci_upper'][0], 'delta_mean_net_daily_bp': 10000 * comparison['mean_difference'][0], 'delta_loss_es_daily_bp': 10000 * comparison['loss_es_difference'][0], 'p_raw': comparison['p_value'][0], 'Holm_family': 'weekly' if frequency == 'weekly' else 'tail_probability'}
            for model, result in summaries.items():
                for field in ['J_daily_bp', 'net_mean_daily_bp', 'loss_es_daily_bp', 'mean_traded_fraction', 'total_cost_per_initial_wealth', 'terminal_wealth', 'optimized_signals', 'executions', 'positive_cost_days']:
                    row[f'{model}_{field}'] = result[field]
                row[f'{model}_boundary_loss_daily_bp'] = result['realized_tail_mass']['boundary_loss_daily_bp']
                row[f'{model}_zero_cost_days'] = int((ledgers[model].cost == 0).sum())
            rows.append(row)
    table = pd.DataFrame(rows)
    for family in ['tail_probability', 'weekly']:
        selected = table.Holm_family.eq(family)
        table.loc[selected, 'p_holm_supplementary_family'] = holm_adjust(table.loc[selected, 'p_raw'].to_numpy())
        table.loc[selected, 'Holm_family_size'] = int(selected.sum())
    table.to_csv(OUTPUT / 'comparison_summary.csv', index=False)
    pd.DataFrame(model_rows).to_csv(OUTPUT / 'model_summary.csv', index=False)
    decision_columns = ['setting', 'panel', 'alpha', 'observations', 'FULL_J_daily_bp', 'A0_J_daily_bp', 'delta_J_daily_bp', 'delta_J_ci95_lower_bp', 'delta_J_ci95_upper_bp', 'p_raw', 'p_holm_supplementary_family', 'Holm_family_size']
    tail_columns = ['setting', 'panel', 'observations', 'alpha', 'sample_N_alpha', 'sample_complete_tail_observations', 'sample_boundary_fraction', 'sample_boundary_worst_rank', 'scenario_N_alpha', 'scenario_complete_tail_observations', 'scenario_boundary_fraction']
    components = ['setting', 'panel', 'FULL_net_mean_daily_bp', 'A0_net_mean_daily_bp', 'FULL_loss_es_daily_bp', 'A0_loss_es_daily_bp', 'FULL_total_cost_per_initial_wealth', 'A0_total_cost_per_initial_wealth']
    weekly_columns = ['panel', 'observations', 'FULL_executions', 'A0_executions', 'FULL_optimized_signals', 'A0_optimized_signals', 'FULL_zero_cost_days', 'A0_zero_cost_days', 'FULL_mean_traded_fraction', 'A0_mean_traded_fraction']
    lines = ['尾部概率与周度交易补充实验', '', '本报告完整列出 α=0.025、0.01 与周度交易的 12 条模型路径、6 个 FULL−A0 比较。尾部概率和周度稳健性来自原方案，本轮日历规则与输出细节在主结果已知后写入 design.json；属于补充敏感性分析，不修改冻结主方案、原主检验或原先的参数选择。', '', '所有差值均为 FULL−A0，J、平均净收益与损失 ES 的单位为基点/日。J=平均日净收益−κ×ESα(日损失)，κ=0.05；优化和事后评价使用同一个 α。α=0.025 对应 ES97.5，α=0.01 对应 ES99，周度使用 α=0.05（ES95）。统一 CSV 使用 loss_es_daily_bp 并同时给出 α，不将更深尾部指标误标为 ES95。', table[decision_columns].to_string(index=False, float_format=lambda value: f'{value:.6f}'), '', '收益、损失尾部与实际费用：费用列为实际总费用/初始财富。', table[components].to_string(index=False, float_format=lambda value: f'{value:.6f}'), '', '经验 ES 的精确尾部质量：Nα=完整尾观察数+下一最差观察的分数权重。边界排序从最大损失开始按 1 计数；完整尾观察数并非另行估计的超限次数。10000 个联合情景在 α=.025/.01 下分别使用最差 250/100 个完整情景，无分数边界。日度实际样本的分数权重如下，每个模型边界日的损失值另存 comparison_summary.csv。', table[tail_columns].to_string(index=False, float_format=lambda value: f'{value:.6f}'), '', '周度时序：首笔按原首信号从现金等权建仓，允许周中初始化。此后仅每个 ISO 周首个实际观测日发出信号，次个观测日执行；执行前持仓继续按每日收益漂移。周首判断只比较当日和上一观测日的 ISO 年/周，不依赖未来观测日。每笔费用仅计入执行后的第一个日收益，其余持有日保留收益和漂移并令费用、成交量为零。周度使用原单期预测来改变交易频率，没有重新训练周收益模型。', table.loc[table.setting.eq('weekly'), weekly_columns].to_string(index=False, float_format=lambda value: f'{value:.6f}'), '周度 ledger 的 trade_executed 指示实际执行；持有行 execution_date 保留最近执行日，target_* 为当日持有期起点的漂移权重，不表示当日重新下单。', '', '分布预测、成熟 PIT 和同一信号日的 10000 个随机情景均复用主实验；每个设置重新优化并重新逐笔核算费用。所有分支从现金独立建仓，目标日期与原主结果完全一致，日度 J 包含全部无交易持有日。', '推断沿用配对平稳区块 bootstrap：5000 次、平均区块长度 20、种子 20261012，各次同步重抽整行日期并按相应 α 重新计算 ES 与 J。区间为未校正 95% percentile 区间，原 p 使用中心化双侧 (count+1)/(5000+1)。α 的四项比较构成独立 Holm 族，周度的两项比较另成一个 Holm 族；两族均不并入原主分析。', '', '复现命令（项目目录 .）：', 'python run.py -m scripts.run_tail_execution_sensitivity --all', 'python run.py -m scripts.report_tail_execution_sensitivity', 'Use python run.py for CPU execution; the batch uses at most three worker processes.']
    (OUTPUT / 'report.txt').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(table[decision_columns].to_string(index=False, float_format=lambda value: f'{value:.6f}'))
if __name__ == '__main__':
    main()
