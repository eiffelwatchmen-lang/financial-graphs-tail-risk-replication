"""Replay frozen predictions at changed tail probabilities or weekly trading."""
import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime, timezone
import json
from pathlib import Path
import time
import numpy as np
import pandas as pd
from scripts.baselines import backtest, summarize
from scripts.joint_risk import solve_mean_cvar
from scripts.run_graph_development import load_panel, scenarios_at
ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / 'outputs/confirmation/tail_execution_sensitivity'
FROZEN = ROOT / 'configs/frozen_protocol.json'
SETTINGS = {'tail_0p025': (0.025, 'daily'), 'tail_0p01': (0.01, 'daily'), 'weekly': (0.05, 'weekly')}

def tail_mass(count, alpha):
    mass = count * alpha
    whole = int(np.floor(mass))
    fraction = mass - whole
    return {'N': count, 'alpha': alpha, 'N_alpha': mass, 'complete_tail_observations': whole, 'boundary_fraction': fraction, 'boundary_worst_rank': whole + 1 if fraction > 0 else None}

def write_design():
    OUTPUT.mkdir(parents=True, exist_ok=True)
    design = {'specified_at_utc': datetime.now(timezone.utc).isoformat(), 'main_results_already_observed': True, 'status': 'supplementary_sensitivity_implementation_after_main_results', 'frozen_protocol_source': FROZEN.relative_to(ROOT).as_posix(), 'frozen_protocol_modified': False, 'settings': {name: {'alpha': alpha, 'trading_frequency': frequency} for name, (alpha, frequency) in SETTINGS.items()}, 'panels': ['repod', 'japan'], 'models': ['FULL', 'A0'], 'paths': 12, 'workers': 3, 'cpu_threads_per_worker': 1, 'reoptimization': 'Every eligible signal uses the main frozen forecasts and same date-specific 10000 joint scenarios; distributions are not retrained.', 'weekly_rule': 'Initialize from cash with equal weights on the original first signal even if midweek. Subsequent signals occur only on the first observed date of an ISO year/week, detected from the current and previous observed date. Execute one observed date later and hold with daily drift until the next execution.', 'weekly_prediction_horizon': 'Use the original one-period target forecast at the weekly signal; this changes the trading schedule, not the forecast horizon.', 'ledger_rule': 'Record every original daily target. Each fee is charged only to the first return following its execution. On holding-only rows cost, turnover and trades are zero, execution_date is the latest actual execution, and target weights are the drifted holdings at the start of that daily return.', 'tail_rule': 'J=mean(net return)-kappa*ES_alpha(loss), with alpha used in both optimization and evaluation. The worst floor(N*alpha) observations have full weight and the next observation has weight N*alpha-floor(N*alpha).', 'inference': {'bootstrap_repetitions': 5000, 'mean_block_length': 20, 'seed': 20261012, 'tail_probability_Holm_family_size': 4, 'weekly_Holm_family_size': 2, 'combined_with_primary_family': False}}
    (OUTPUT / 'design.json').write_text(json.dumps(design, ensure_ascii=False, indent=2), encoding='utf-8')

def run_sensitivity(config, panel_name, model, setting, *, target_count=None, output_directory=None):
    alpha, frequency = SETTINGS[setting]
    portfolio = config['portfolio']
    kappa, cap = (portfolio['kappa'], portfolio['weight_cap'])
    rates = np.asarray(config['panels'][panel_name]['cost_rates'])
    source = ROOT / 'outputs/confirmation' / panel_name / 'graph'
    forecast_path = source / f'{model}_forecasts.npz'
    forecast = np.load(forecast_path)
    scores = pd.read_csv(source / f'{model}_scores.csv', parse_dates=['target_date'])
    if target_count is not None:
        scores = scores.iloc[:target_count]
    dates, returns, _, _, _ = load_panel(config, panel_name, 'test')
    start, end = (scores.target_date.iloc[0], scores.target_date.iloc[-1])
    directory = OUTPUT / setting / panel_name if output_directory is None else Path(output_directory)
    directory.mkdir(parents=True, exist_ok=True)
    settings = {'setting': setting, 'panel': panel_name, 'alpha': alpha, 'kappa': kappa, 'trading_frequency': frequency, 'cost_rates': rates.tolist(), 'weight_cap': cap, 'scope': 'supplementary_sensitivity' if target_count is None else 'smoke', 'frozen_forecast_directory': source.relative_to(ROOT).as_posix(), 'frozen_protocol_source': FROZEN.relative_to(ROOT).as_posix(), 'scenario_count': config['copula']['scenarios'], 'seed': config['seed'], 'scenario_tail_mass': tail_mass(config['copula']['scenarios'], alpha), 'realized_tail_mass': tail_mass(len(scores), alpha), 'first_target': str(start.date()), 'last_target': str(end.date()), 'observations': len(scores), 'distribution_retrained': False, 'allocation_reoptimized': True, 'costs_recomputed_per_trade': True, 'initialization': 'fresh_equal_weight_purchase_from_cash_on_original_first_signal', 'execution_lag': 1, 'target_lag': 2, 'common_random_numbers': 'Same main-experiment date seed and complete 10000 joint scenarios.', 'ES_metric': 'loss_es_daily_bp with explicit alpha; confidence level is 1-alpha.'}
    (directory / 'settings.json').write_text(json.dumps(settings, ensure_ascii=False, indent=2), encoding='utf-8')
    begin = time.perf_counter()
    count = 0

    def strategy(signal, knownweights):
        nonlocal count
        scenarios = scenarios_at(signal, dates, forecast, config)
        weights = solve_mean_cvar(scenarios, forecast['location'][signal], knownweights, rates, alpha, kappa, cap)
        count += 1
        if count % 100 == 0:
            print(f'{setting} {panel_name} {model}: optimized {count} signals, {time.perf_counter() - begin:.1f}s', flush=True)
        return weights
    ledger = backtest(returns, model, start, end, rates=rates, cap=cap, alpha=alpha, kappa=kappa, strategy=strategy, trading_frequency=frequency)
    pd.testing.assert_series_equal(ledger.target_date, scores.target_date, check_names=False)
    ledger.to_csv(directory / f'{model}_ledger.csv', index=False)
    result = summarize(ledger, kappa, alpha)
    result['loss_es_daily_bp'] = result.pop('loss_es95_daily_bp')
    realized_tail = tail_mass(len(ledger), alpha)
    if realized_tail['boundary_fraction'] > 0:
        realized_tail['boundary_loss_daily_bp'] = float(10000 * np.sort(-ledger.net_return.to_numpy())[::-1][realized_tail['complete_tail_observations']])
    result.update({'setting': setting, 'panel': panel_name, 'alpha': alpha, 'es_confidence_level': 1 - alpha, 'kappa': kappa, 'trading_frequency': frequency, 'cost_rates': rates.tolist(), 'frozen_forecast_source': forecast_path.relative_to(ROOT).as_posix(), 'optimized_signals': count, 'executions': int(ledger.trade_executed.sum()) if frequency == 'weekly' else len(ledger), 'positive_cost_days': int((ledger.cost > 0).sum()), 'scenario_tail_mass': settings['scenario_tail_mass'], 'realized_tail_mass': realized_tail, 'elapsed_seconds': time.perf_counter() - begin})
    (directory / f'{model}_summary.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f"{setting} {panel_name} {model}: {len(ledger)} daily targets, J={result['J_daily_bp']:.8f} bp/day", flush=True)
    return (ledger, result)

def run_path(task):
    setting, panel, model = task
    config = json.loads(FROZEN.read_text(encoding='utf-8'))
    _, result = run_sensitivity(config, panel, model, setting)
    return result

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--all', action='store_true')
    parser.add_argument('--panel', choices=['repod', 'japan'])
    parser.add_argument('--model', choices=['FULL', 'A0'])
    parser.add_argument('--setting', choices=list(SETTINGS))
    args = parser.parse_args()
    write_design()
    if args.all:
        tasks = [(setting, panel, model) for setting in SETTINGS for panel in ['repod', 'japan'] for model in ['FULL', 'A0']]
        results = []
        with ProcessPoolExecutor(max_workers=3) as pool:
            futures = [pool.submit(run_path, task) for task in tasks]
            for future in as_completed(futures):
                results.append(future.result())
                print(f'Completed {len(results)}/{len(tasks)} paths', flush=True)
        (OUTPUT / 'batch_results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding='utf-8')
    else:
        if args.panel is None or args.model is None or args.setting is None:
            parser.error('supply --all or all of --panel, --model and --setting')
        run_path((args.setting, args.panel, args.model))
if __name__ == '__main__':
    main()
