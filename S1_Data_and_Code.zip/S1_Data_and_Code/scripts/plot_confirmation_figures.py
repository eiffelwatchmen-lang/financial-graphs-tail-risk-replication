"""Export confirmation figures and their plotted data from completed reports."""
import argparse
import json
import os
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
os.environ['MPLCONFIGDIR'] = str(ROOT / '.cache/matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.dates as mdates
from matplotlib import font_manager
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np
import pandas as pd
from PIL import Image
OUTPUT = ROOT / 'outputs/confirmation'
FIGURES = OUTPUT / 'figures'
PANELS = ('repod', 'japan')
PANEL_NAMES = {'repod': 'RepOD (USD)', 'japan': 'Japan (JPY)'}
MODELS = ('M0', 'M1', 'M2', 'M3', 'M4', 'FULL', 'A0')
COLORS = {'M0': '#777777', 'M1': '#44AA99', 'M2': '#CCBB44', 'M3': '#AA4499', 'M4': '#9999CC', 'FULL': '#0072B2', 'A0': '#D55E00'}
EFFECT_COLUMNS = ['panel', 'observations', 'first_target', 'last_target', 'delta_J_daily_bp', 'delta_J_ci95_lower_bp', 'delta_J_ci95_upper_bp', 'p_raw']
INTERVAL_CAPTION = 'Intervals are unadjusted 95% percentile intervals from 5,000 paired stationary-bootstrap replicates with mean block length 20 and seed 20261012. Each replicate recomputes the mean and loss ES using exactly 5% empirical tail mass. Multiplicity-adjusted inference is reported separately in the corresponding statistical report.'

def save_figure(figure, stem, data, caption):
    for extension in ('png', 'pdf', 'svg'):
        figure.savefig(FIGURES / f'{stem}.{extension}', dpi=300, bbox_inches='tight')
    with Image.open(FIGURES / f'{stem}.png') as png:
        png.convert('RGB').save(FIGURES / f'{stem}.tif', dpi=(300, 300), compression='tiff_lzw')
    plt.close(figure)
    data.to_csv(FIGURES / f'{stem}_data.csv', index=False)
    (FIGURES / f'{stem}_caption.txt').write_text(caption + '\n', encoding='utf-8')
    print(FIGURES / f'{stem}.png', flush=True)

def horizontal_interval(axis, row, y, color, marker='o'):
    lower, upper = (row['delta_J_ci95_lower_bp'], row['delta_J_ci95_upper_bp'])
    axis.hlines(y, lower, upper, color=color, linewidth=1.7)
    axis.vlines([lower, upper], y - 0.055, y + 0.055, color=color, linewidth=1.3)
    axis.scatter(row['delta_J_daily_bp'], y, color=color, marker=marker, s=48, zorder=3)

def main_figures():
    figure, axes = plt.subplots(2, 2, figsize=(7.3, 5.8), sharex='col')
    data = []
    for column, panel in enumerate(PANELS):
        for model in MODELS:
            folder = 'graph' if model in ('FULL', 'A0') else 'm4' if model == 'M4' else 'baselines'
            ledger = pd.read_csv(OUTPUT / panel / folder / f'{model}_ledger.csv', parse_dates=['execution_date', 'target_date'])
            dates = pd.DatetimeIndex([ledger.execution_date.iloc[0], *ledger.target_date])
            wealth = np.r_[1.0, ledger.wealth.to_numpy()]
            drawdown = 100 * (wealth / np.maximum.accumulate(wealth) - 1)
            width = 1.3 if model in ('FULL', 'A0') else 0.8
            style = '-' if model in ('FULL', 'A0', 'M0') else '--'
            for row, values in enumerate((wealth, drawdown)):
                axes[row, column].plot(dates, values, label=model, color=COLORS[model], linewidth=width, linestyle=style)
            data.append(pd.DataFrame({'panel': panel, 'model': model, 'date': dates, 'net_wealth': wealth, 'drawdown_percent': drawdown, 'point_type': ['initial_capital', *['holding_period_end'] * len(ledger)]}))
        axes[0, column].set_title(f'({chr(97 + column)}) {PANEL_NAMES[panel]}: net wealth', loc='left')
        axes[1, column].set_title(f'({chr(99 + column)}) {PANEL_NAMES[panel]}: drawdown', loc='left')
        axes[0, column].axhline(1, color='#999999', linewidth=0.7, linestyle=':')
        axes[1, column].axhline(0, color='#999999', linewidth=0.7)
        axes[0, column].set_ylabel('Net wealth (initial capital = 1)')
        axes[1, column].set_ylabel('Drawdown (%)')
        axes[1, column].xaxis.set_major_locator(mdates.YearLocator())
        axes[1, column].xaxis.set_major_formatter(mdates.DateFormatter('%Y'))
        axes[1, column].set_xlabel('Target date')
        for row in range(2):
            axes[row, column].grid(axis='y', color='#E5E5E5', linewidth=0.6)
            axes[row, column].margins(x=0.015)
    handles, labels = axes[0, 0].get_legend_handles_labels()
    figure.legend(handles, labels, loc='upper center', ncol=7, frameon=False, bbox_to_anchor=(0.5, 1.005))
    figure.tight_layout(rect=(0, 0, 1, 0.95), h_pad=1.7, w_pad=2.0)
    save_figure(figure, 'main_wealth_drawdown', pd.concat(data, ignore_index=True), "Figure 1. Net wealth and drawdown of M0–M4, FULL and A0 in the two confirmation panels. Each strategy begins with one unit of cash and an equal-weight purchase; the first realized net return includes the initial purchase cost. All subsequent self-financing transaction costs are included in the archived wealth path. Drawdown is measured against the running peak, including the initial capital of one. The panels retain their own dates and local currencies and are displayed separately. Source: each panel's graph, baselines and m4 ledgers.")
    primary = pd.read_csv(OUTPUT / 'primary_comparison.csv').set_index('panel').loc[list(PANELS)].reset_index()
    figure, axis = plt.subplots(figsize=(6.8, 2.7))
    labels = []
    for position, (_, row) in enumerate(primary.iterrows()):
        horizontal_interval(axis, row, 1 - position, '#0072B2')
        labels.append(f"{PANEL_NAMES[row['panel']]}  (N = {int(row['observations']):,})")
    axis.set_yticks([1, 0], labels)
    axis.set_ylim(-0.45, 1.45)
    axis.axvline(0, color='#666666', linestyle='--', linewidth=0.9)
    axis.grid(axis='x', color='#E5E5E5', linewidth=0.6)
    axis.set_xlabel('ΔJ = FULL − A0 (bp/day)')
    figure.text(0.5, 0.025, 'Positive values favor FULL', ha='center', fontsize=9)
    figure.tight_layout(rect=(0, 0.07, 1, 1))
    save_figure(figure, 'main_delta_J', primary[EFFECT_COLUMNS + ['p_holm_two_panels']], 'Figure 2. Primary FULL−A0 difference in J for each confirmation panel, where J = mean net return − 0.05 × loss ES95. Points show the observed differences in daily basis points; N is the number of paired target dates. Positive values favor FULL. ' + INTERVAL_CAPTION + ' The two panel tests form the primary Holm family. Source: primary_comparison.csv.')

def allocation_figure():
    comparison = pd.read_csv(OUTPUT / 'allocation_sensitivity/comparison_summary.csv')
    primary = pd.read_csv(OUTPUT / 'primary_comparison.csv')
    data = []
    for family, field, baseline_value in (('cost', 'cost_multiplier', 1.0), ('kappa', 'kappa', 0.05)):
        selected = comparison.loc[comparison.setting.str.startswith(family + '_')].copy()
        selected['family'], selected['setting_value'], selected['main_setting'] = (family, selected[field], False)
        reference = primary.copy()
        reference['family'], reference['setting_value'], reference['main_setting'] = (family, baseline_value, True)
        reference['setting'] = 'original_main'
        reference['cost_multiplier'], reference['kappa'] = (1.0, 0.05)
        reference['p_holm_14_sensitivity'] = np.nan
        selected['p_holm_two_panels'] = np.nan
        columns = EFFECT_COLUMNS + ['setting', 'family', 'setting_value', 'main_setting', 'cost_multiplier', 'kappa', 'p_holm_14_sensitivity', 'p_holm_two_panels']
        data.extend((selected[columns], reference[columns]))
    plotted = pd.concat(data, ignore_index=True).sort_values(['panel', 'family', 'setting_value'])
    figure, axes = plt.subplots(2, 2, figsize=(7.3, 5.7), sharey='row')
    for row_index, panel in enumerate(PANELS):
        for column, family in enumerate(('cost', 'kappa')):
            axis = axes[row_index, column]
            subset = plotted.loc[(plotted.panel == panel) & (plotted.family == family)]
            cap_width = 0.035 if family == 'cost' else 0.0017
            for _, row in subset.iterrows():
                color = '#222222' if row.main_setting else '#0072B2'
                x, lower, upper = (row.setting_value, row.delta_J_ci95_lower_bp, row.delta_J_ci95_upper_bp)
                axis.vlines(x, lower, upper, color=color, linewidth=1.4)
                axis.hlines([lower, upper], x - cap_width, x + cap_width, color=color, linewidth=1.2)
                axis.scatter(x, row.delta_J_daily_bp, color=color, marker='D' if row.main_setting else 'o', s=40, zorder=3)
            title = 'transaction costs' if family == 'cost' else 'risk preference'
            axis.set_title(f'({chr(97 + row_index * 2 + column)}) {PANEL_NAMES[panel]}: {title}', loc='left')
            axis.set_xticks([0, 0.5, 1, 2, 4] if family == 'cost' else [0.02, 0.05, 0.1, 0.2])
            axis.set_xlabel('Transaction-cost multiplier' if family == 'cost' else 'Risk-preference coefficient κ')
            axis.axhline(0, color='#666666', linewidth=0.9, linestyle='--')
            axis.grid(axis='y', color='#E5E5E5', linewidth=0.6)
            axis.margins(x=0.07)
        axes[row_index, 0].set_ylabel('ΔJ = FULL − A0 (bp/day)')
    handles = [Line2D([], [], marker='D', color='#222222', linestyle='none', label='Original main setting'), Line2D([], [], marker='o', color='#0072B2', linestyle='none', label='Supplementary setting')]
    figure.legend(handles=handles, loc='upper center', ncol=2, frameon=False, bbox_to_anchor=(0.5, 1.005))
    figure.tight_layout(rect=(0, 0, 1, 0.95), h_pad=1.8, w_pad=1.5)
    save_figure(figure, 'allocation_delta_J', plotted, 'S1 Fig. FULL−A0 differences across supplementary allocation settings. Cost multipliers 0, 0.5, 2 and 4 retain κ = 0.05; κ values 0.02, 0.10 and 0.20 retain the original transaction costs. Black diamonds reproduce the original setting (cost multiplier 1, κ = 0.05). Each sensitivity setting reuses the frozen forecasts and reoptimizes both strategies from the same initial cash condition. The selected κ is used for both allocation and J evaluation. All settings are displayed as separate estimates; cross-setting changes are descriptive, and κ changes the evaluation objective itself. ' + INTERVAL_CAPTION + ' The 14 additional comparisons form one supplementary Holm family; the original main points retain their primary inference. Sources: allocation_sensitivity/comparison_summary.csv and primary_comparison.csv.')

def delay_figure():
    primary = pd.read_csv(OUTPUT / 'primary_comparison.csv')
    delayed = pd.read_csv(OUTPUT / 'delay_sensitivity/comparison_summary.csv')
    primary['timing'], primary['execution_lag'], primary['target_lag'] = ('Original', 1, 2)
    delayed['timing'] = 'Extra delay'
    columns = EFFECT_COLUMNS + ['timing', 'execution_lag', 'target_lag']
    plotted = pd.concat((primary[columns], delayed[columns]), ignore_index=True)
    figure, axes = plt.subplots(1, 2, figsize=(7.3, 3.0), sharex=True)
    for column, panel in enumerate(PANELS):
        axis = axes[column]
        labels = []
        for position, timing in enumerate(('Original', 'Extra delay')):
            row = plotted.loc[(plotted.panel == panel) & (plotted.timing == timing)].iloc[0]
            horizontal_interval(axis, row, 1 - position, '#555555' if position == 0 else '#0072B2', marker='D' if position == 0 else 'o')
            labels.append(f'{timing}\nN = {int(row.observations):,}')
        axis.set_yticks([1, 0], labels)
        axis.set_ylim(-0.45, 1.45)
        axis.axvline(0, color='#666666', linewidth=0.9, linestyle='--')
        axis.grid(axis='x', color='#E5E5E5', linewidth=0.6)
        axis.set_xlabel('ΔJ = FULL − A0 (bp/day)')
        axis.set_title(f'({chr(97 + column)}) {PANEL_NAMES[panel]}', loc='left')
    figure.tight_layout(w_pad=2.2)
    save_figure(figure, 'delay_delta_J', plotted, "Figure 4. Original and additional-execution-delay FULL−A0 differences in J. Original signals execute at s+1 and predict the single-period return r(s+2); delayed signals execute at s+2 and predict r(s+3). The delayed branch re-estimates graphs, conditional distributions and mature PIT dependence from historical data using the fixed hyperparameters. Each row uses its branch's full evaluation sample, with its paired target-date count shown as N. The delayed branch starts a new cash-to-equal-weight path one observation later. Differences between timing branches therefore include forecast-horizon and initialization-path changes and are not isolated causal effects of execution delay. " + INTERVAL_CAPTION + ' Original and delayed tests retain separate two-panel Holm families. Sources: primary_comparison.csv and delay_sensitivity/comparison_summary.csv.')

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--stage', choices=('main', 'allocation', 'delay', 'all'), default='main')
    args = parser.parse_args()
    FIGURES.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 9, 'axes.titlesize': 9, 'axes.labelsize': 9, 'xtick.labelsize': 8, 'ytick.labelsize': 8, 'legend.fontsize': 8, 'axes.spines.top': False, 'axes.spines.right': False, 'pdf.fonttype': 42, 'ps.fonttype': 42, 'svg.fonttype': 'none', 'savefig.facecolor': 'white'})
    for stage, action in (('main', main_figures), ('allocation', allocation_figure), ('delay', delay_figure)):
        if args.stage in (stage, 'all'):
            action()
    stems = ('main_wealth_drawdown', 'main_delta_J', 'allocation_delta_J', 'delay_delta_J')
    captions = [path.read_text(encoding='utf-8').strip() for stem in stems if (path := (FIGURES / f'{stem}_caption.txt')).exists()]
    (FIGURES / 'captions.txt').write_text('\n\n'.join(captions) + '\n', encoding='utf-8')
    exports = []
    for path in sorted(FIGURES.glob('*.tif')):
        with Image.open(path) as tif:
            width, height = tif.size
            assert 789 <= width <= 2250 and height <= 2625
            exports.append({'file': path.name, 'width_pixels': width, 'height_pixels': height, 'dpi': [float(value) for value in tif.info['dpi']], 'color_mode': tif.mode, 'compression': tif.info['compression'], 'pages': tif.n_frames, 'bytes': path.stat().st_size})
    record = {'official_source': 'https://journals.plos.org/plosone/s/figures', 'requirements_checked_on': '2026-10-13', 'font': 'DejaVu Sans', 'font_sizes_pt': [8, 9], 'greek_symbols': 'Unicode text rendered with DejaVu Sans; no mathtext', 'export': 'Native 300-dpi plotting, RGB TIFF without alpha, LZW compression; no pixel resizing', 'requested_limits': {'width_pixels_at_300dpi': [789, 2250], 'max_height_pixels_at_300dpi': 2625, 'maximum_bytes': 10000000}, 'files': exports}
    (FIGURES / 'export_record.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
if __name__ == '__main__':
    main()
