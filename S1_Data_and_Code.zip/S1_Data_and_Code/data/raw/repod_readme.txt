Title: USO_GLD_SPY_BTC_base
Author: Piotr Fiszeder, Rados�aw Pietrzyk
Contact person: Piotr Fiszeder, email: piotr.fiszeder@umk.pl

The file contains data used and analysed in the paper:
Fiszeder, P., & Ma�ecka, M. (2025). Forecasting the oil, gold, equity, and Bitcoin markets using robust multivariate range-based GARCH models.

The file contains open, high, low, close prices, realized variances, and realized covariances for three exchange-traded funds (ETFs): the United States Oil Fund (USO), SPDR Gold Shares (GLD), SPDR Portfolio S&P 500 Growth (SPY), and Bitcoin (BTC).
The data start on July 1, 2016, and end on June 28, 2024.

Keywords: commodities, volatility models, high-low range, outliers, DCC model, value at risk
Language: English.
License: CC0 

