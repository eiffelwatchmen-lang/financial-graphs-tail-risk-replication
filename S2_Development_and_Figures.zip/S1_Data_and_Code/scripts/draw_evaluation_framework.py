"""Draw the manuscript's evaluation framework from a fixed scientific layout.

Usage:
    python draw_evaluation_framework.py --output-dir figures

Requires matplotlib and Pillow. Outputs Fig1.png, Fig1.tif and Fig1.svg.
All text is rendered at 9.0-11.2 pt at the intended 7.4-inch print width.
"""

from argparse import ArgumentParser
from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import FancyArrowPatch, Rectangle
from PIL import Image


WIDTH_IN = 7.4
HEIGHT_IN = 7.0
DPI = 300


def choose_font():
    """Prefer Arial or a standard metric-compatible sans-serif substitute."""
    available = {entry.name for entry in font_manager.fontManager.ttflist}
    for name in ("Arial", "Liberation Sans", "Nimbus Sans", "DejaVu Sans"):
        if name in available:
            return name
    return "sans-serif"


def draw(output_dir):
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    font_name = choose_font()
    plt.rcParams.update(
        {
            "font.family": font_name,
            "font.size": 9.4,
            "text.color": "black",
            "axes.edgecolor": "black",
            "svg.fonttype": "path",
            "svg.hashsalt": "portfolio-evaluation-framework-v1",
            "savefig.facecolor": "white",
        }
    )
    fig = plt.figure(figsize=(WIDTH_IN, HEIGHT_IN), dpi=DPI, facecolor="white")
    ax = fig.add_axes((0, 0, 1, 1))
    ax.set_xlim(0, WIDTH_IN)
    ax.set_ylim(0, HEIGHT_IN)
    ax.set_axis_off()

    def box(x, y, width, height, line_width=0.9):
        patch = Rectangle(
            (x, y), width, height,
            linewidth=line_width, edgecolor="black", facecolor="white",
        )
        ax.add_patch(patch)

    def text(x, y, label, size=9.4, bold=False, align="center"):
        return ax.text(
            x, y, label,
            ha=align, va="center", fontsize=size,
            fontweight="bold" if bold else "normal", linespacing=1.22,
        )

    def arrow(start, end, scale=9.0):
        ax.add_patch(
            FancyArrowPatch(
                start, end, arrowstyle="-|>", mutation_scale=scale,
                linewidth=0.9, color="black", shrinkA=0, shrinkB=0,
            )
        )

    left_x, left_width = 0.25, 4.38
    right_x, right_width = 5.02, 2.13
    left_mid = left_x + left_width / 2
    right_mid = right_x + right_width / 2

    # Source panels retain separate calendars; comparison rules are shared
    # within each panel. The clock is a reference for every processing stage.
    box(0.25, 5.48, 6.90, 1.27, line_width=1.0)
    text(3.70, 6.54, "Common information rules within each panel", 11.2, True)
    text(2.02, 6.28, "USD panel (3 assets)", 10.2, True)
    text(5.38, 6.28, "JPY panel (4 assets)", 10.2, True)
    text(3.70, 6.06, "Separate observed-date calendars; information available through s", 9.4)
    text(1.38, 5.75, "Signal s", 10.2, True)
    text(3.70, 5.75, "Execute s + 1", 10.2, True)
    text(6.02, 5.75, "Target r(s + 2)", 10.2, True)
    arrow((2.08, 5.75), (2.75, 5.75))
    arrow((4.65, 5.75), (5.22, 5.75))

    arrow((left_mid, 5.48), (left_mid, 5.06))
    text(right_mid, 5.24, "Evidence outputs", 10.6, True)
    box(left_x, 4.72, left_width, 0.30)
    text(left_mid, 4.87, "Common node features available at signal s", 9.6)
    arrow((left_mid, 4.72), (left_mid, 4.53))

    # Model comparison. This is deliberately not labelled a pure mechanism
    # ablation or an equal-effective-capacity comparison.
    box(left_x, 3.67, left_width, 0.82)
    ax.plot([left_mid, left_mid], [3.67, 4.49], color="black", linewidth=0.7)
    full_mid = left_x + left_width / 4
    a0_mid = left_x + 3 * left_width / 4
    text(full_mid, 4.29, "FULL", 10.8, True)
    text(full_mid, 4.01, "Monthly signed graph\nmessages + own features", 9.5)
    text(a0_mid, 4.29, "A0", 10.8, True)
    text(a0_mid, 4.01, "Own-asset features\nand transformations", 9.5)

    box(right_x, 3.67, right_width, 1.35, line_width=1.0)
    text(right_mid, 4.79, "Graph structure", 10.6, True)
    text(right_mid, 4.51, "FULL graph histories", 9.2)
    text(right_mid, 4.28, "Exact-input equivalence", 9.2)
    text(right_mid, 4.05, "Distinct result sources", 9.2)
    arrow((left_x + left_width + 0.025, 4.08), (right_x - 0.035, 4.08))

    # Common rules do not imply identical fitted forecasts or copulas.
    arrow((left_mid, 3.67), (left_mid, 3.44))
    box(left_x, 2.28, left_width, 1.12)
    text(left_mid, 3.18, "Common distribution and scenario rules", 10.3, True)
    text(left_mid, 2.93, "Truncated Student-t margins; t copula", 9.5)
    text(left_mid, 2.70, "252 mature PIT vectors; 10,000 scenarios", 9.5)
    text(left_mid, 2.47, "Model-specific forecasts and joint scenarios", 9.3)

    box(right_x, 2.28, right_width, 1.12, line_width=1.0)
    text(right_mid, 3.18, "Tail forecasts", 10.6, True)
    text(right_mid, 2.93, "Equal-weight gross returns", 9.1)
    text(right_mid, 2.70, "Joint VaR-ES score", 9.3)
    text(right_mid, 2.47, "Coverage and calibration", 9.1)
    arrow((left_x + left_width + 0.025, 2.84), (right_x - 0.035, 2.84))

    arrow((left_mid, 2.28), (left_mid, 2.05))
    box(left_x, 0.58, left_width, 1.43)
    text(left_mid, 1.79, "Common allocation and trading rules", 10.3, True)
    text(left_mid, 1.54, "Mean-ES allocation; long-only, asset cap 0.60", 9.4)
    text(left_mid, 1.31, "Common constraints and cost assumptions", 9.4)
    text(left_mid, 1.08, "Separate targets, drift and realized trades", 9.4)
    text(left_mid, 0.83, "Self-financing costs charged once", 9.4)

    box(right_x, 0.58, right_width, 1.43, line_width=1.0)
    text(right_mid, 1.79, "Portfolio decisions", 10.6, True)
    text(right_mid, 1.54, "Strategy-specific net returns", 9.0)
    text(right_mid, 1.29, "J = mean(net return)", 9.4)
    text(right_mid, 1.08, "− 0.05 × loss ES95", 9.4)
    text(right_mid, 0.83, "Paired bootstrap; Holm", 9.2)
    arrow((left_x + left_width + 0.025, 1.30), (right_x - 0.035, 1.30))

    png_path = output_dir / "Fig1.png"
    svg_path = output_dir / "Fig1.svg"
    tiff_path = output_dir / "Fig1.tif"
    fig.savefig(png_path, dpi=DPI, metadata={"Title": "Portfolio evaluation framework"})
    fig.savefig(svg_path, metadata={"Title": "Portfolio evaluation framework", "Date": None})
    plt.close(fig)

    with Image.open(png_path) as raster:
        rgb = raster.convert("RGB")
        rgb.save(png_path, dpi=(DPI, DPI))
        rgb.save(tiff_path, compression="tiff_lzw", dpi=(DPI, DPI))

    print(f"Font: {font_name}")
    print(f"Size: {int(WIDTH_IN * DPI)} x {int(HEIGHT_IN * DPI)} pixels; {DPI} dpi")
    print(f"Outputs: {png_path}, {tiff_path}, {svg_path}")


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=Path("."))
    arguments = parser.parse_args()
    draw(arguments.output_dir)
